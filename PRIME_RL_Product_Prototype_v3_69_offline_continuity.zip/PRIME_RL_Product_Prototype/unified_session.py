"""Opt-in simulation session using one transactional authority store.

Not wired into ROS 2 or physical actuation. The verifier must not consume
nonces outside the unified transaction.
"""
import sqlite3
from session import GovernedSession


class _UnifiedLifecycle:
    def __init__(self, store):
        self.store = store

    def required(self):
        return self.store.status()['revalidation_required']

    def mark_revalidation_required(self):
        self.store.require_revalidation()


class UnifiedGovernedSession(GovernedSession):
    def __init__(self, verifier, ledger, authority_store):
        if verifier.replay_db is not None:
            raise ValueError('unified session requires verifier without separate replay database')
        self.authority_store = authority_store
        super().__init__(verifier, ledger, _UnifiedLifecycle(authority_store))

    def refresh(self, token, now, connected):
        self.permissions = frozenset()
        self.expires_at = None
        self.revalidation_required = True
        self.authority_store.require_revalidation()
        if not connected:
            return False
        result = self.verifier.verify(token, now, consume=False)
        if not result.valid:
            return False
        try:
            self.authority_store.authorize(self.verifier.issuer, self.verifier.audience, result.nonce)
        except sqlite3.IntegrityError:
            return False
        self.permissions = result.permissions
        self.expires_at = result.expires_at
        self.revalidation_required = False
        return True
