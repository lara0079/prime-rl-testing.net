import os
import sqlite3
import tempfile
import unittest
from ledger import Ledger
from metrics import benchmark

class ProductTests(unittest.TestCase):
    def test_persistence_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=os.path.join(tmp,'ledger.db')
            l=Ledger(path);l.append({'decision':'hold'});l.close()
            l=Ledger(path);self.assertTrue(l.verify());self.assertEqual(len(l.events()),1);l.close()
    def test_tampering_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=os.path.join(tmp,'ledger.db')
            l=Ledger(path);l.append({'decision':'hold'});l.append({'decision':'signal'})
            l.db.execute("UPDATE events SET payload='{}' WHERE seq=1");l.db.commit()
            self.assertFalse(l.verify());l.close()
    def test_missing_event_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            l=Ledger(os.path.join(tmp,'ledger.db'))
            l.append({'a':1});l.append({'a':2})
            l.db.execute('DELETE FROM events WHERE seq=1');l.db.commit()
            self.assertFalse(l.verify());l.close()
    def test_metrics(self):
        m=benchmark(800)
        self.assertEqual(m['unexpected_acceptances'],0)
        self.assertEqual(m['expected_outcome_accuracy'],1)
    def test_invalid_iterations(self):
        with self.assertRaises(ValueError):benchmark(0)
if __name__=='__main__':unittest.main()
