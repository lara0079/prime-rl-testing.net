"""Correlated telemetry freshness regression checks (no ROS middleware)."""
import json
import unittest
import uuid
from ros2_advisory_node import evaluate_correlated, evaluate_payload


def telemetry(stamp):
    return json.dumps(dict(stamp_seconds=stamp, gnss_quality=0.9,
                           odometry_quality=0.9, imu_quality=0.9,
                           map_freshness=0.9, battery_fraction=0.9,
                           connected=True))


class PureRuntime:
    def evaluate(self, payload, *, now_seconds):
        return evaluate_payload(payload, now_seconds=now_seconds)


class FreshnessContractTests(unittest.TestCase):
    def correlated(self, stamp, now=100.0):
        request_id = str(uuid.uuid4())
        message = json.dumps({'request_id': request_id, 'telemetry': telemetry(stamp)})
        return request_id, json.loads(evaluate_correlated(PureRuntime(), message, now_seconds=now))

    def test_stale_message_is_rejected_and_correlated(self):
        identifier, response = self.correlated(97.99)
        self.assertEqual(response['request_id'], identifier)
        self.assertEqual(response['reason'], 'stale_or_future_telemetry')
        self.assertFalse(response['accepted'])

    def test_future_message_is_rejected_and_correlated(self):
        identifier, response = self.correlated(100.001)
        self.assertEqual(response['request_id'], identifier)
        self.assertEqual(response['reason'], 'stale_or_future_telemetry')
        self.assertFalse(response['accepted'])

    def test_exact_freshness_boundary_not_marked_stale(self):
        _, response = self.correlated(98.0)
        self.assertNotEqual(response.get('reason'), 'stale_or_future_telemetry')
        self.assertTrue(response['advisory_only'])

    def test_nonfinite_timestamp_is_rejected(self):
        _, response = self.correlated(float('nan'))
        self.assertFalse(response['accepted'])
        self.assertEqual(response['reason'], 'invalid_telemetry')


if __name__ == '__main__':
    unittest.main()
