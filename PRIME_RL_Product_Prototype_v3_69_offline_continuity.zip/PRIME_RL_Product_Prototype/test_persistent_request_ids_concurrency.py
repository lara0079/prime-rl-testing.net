"""Concurrent and crash/restart checks for durable advisory request IDs."""
import concurrent.futures
import os
import subprocess
import sys
import tempfile
import unittest
import uuid
from persistent_request_ids import PersistentRequestIds


class DurableReplayConcurrencyTests(unittest.TestCase):
    def test_same_identifier_claimed_once_across_connections(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'ids.sqlite')
            rid = str(uuid.uuid4())
            def attempt(_):
                store = PersistentRequestIds(path)
                try:
                    return store.claim(rid)
                finally:
                    store.close()
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                results = list(pool.map(attempt, range(24)))
            self.assertEqual(results.count(True), 1)
            self.assertEqual(results.count(False), 23)

    def test_distinct_concurrent_claims_survive_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'ids.sqlite')
            ids = [str(uuid.uuid4()) for _ in range(24)]
            def attempt(rid):
                store = PersistentRequestIds(path)
                try:
                    return store.claim(rid)
                finally:
                    store.close()
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                self.assertTrue(all(pool.map(attempt, ids)))
            store = PersistentRequestIds(path)
            try:
                self.assertTrue(all(not store.claim(rid) for rid in ids))
            finally:
                store.close()

    def test_committed_claim_survives_forced_process_exit(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'ids.sqlite')
            rid = str(uuid.uuid4())
            script = ('import os,sys\n'
                      'from persistent_request_ids import PersistentRequestIds\n'
                      's=PersistentRequestIds(sys.argv[1])\n'
                      'assert s.claim(sys.argv[2])\n'
                      'os._exit(17)\n')
            env = os.environ.copy()
            env['PYTHONPATH'] = os.path.dirname(__file__) + os.pathsep + env.get('PYTHONPATH', '')
            result = subprocess.run([sys.executable, '-c', script, path, rid], env=env, timeout=15, check=False)
            self.assertEqual(result.returncode, 17)
            store = PersistentRequestIds(path)
            try:
                self.assertFalse(store.claim(rid))
            finally:
                store.close()


if __name__ == '__main__':
    unittest.main()
