"""Bind an existing ROS2 evidence report to a local execution manifest.

This is a provenance aid, not attestation of a ROS2 host or proof of live DDS.
"""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from ros2_repeatability import evidence_sha256, validate_evidence_report


def create_manifest(report, *, run_id=None, created_utc=None):
    validate_evidence_report(report)
    identifier = run_id if run_id is not None else str(uuid4())
    if not isinstance(identifier, str) or not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', identifier):
        raise ValueError('invalid UUID4 run identifier')
    stamp = created_utc if created_utc is not None else datetime.now(timezone.utc).isoformat()
    try:
        parsed = datetime.fromisoformat(stamp)
        if parsed.utcoffset() is None:
            raise ValueError('timezone required')
    except (ValueError, TypeError) as exc:
        raise ValueError('invalid timestamp') from exc
    return {'schema': 'prime-rl-ros2-run-manifest-v1', 'run_id': identifier,
            'created_utc': stamp, 'evidence_sha256': evidence_sha256(report),
            'live_dds_verified': report['live_dds_verified']}


def verify_manifest(report, manifest):
    if not isinstance(manifest, dict) or set(manifest) != {'schema', 'run_id', 'created_utc', 'evidence_sha256', 'live_dds_verified'}:
        return False
    if manifest['schema'] != 'prime-rl-ros2-run-manifest-v1' or type(manifest['live_dds_verified']) is not bool:
        return False
    try:
        expected = create_manifest(report, run_id=manifest['run_id'], created_utc=manifest['created_utc'])
    except (ValueError, TypeError, KeyError):
        return False
    import hmac
    return (manifest['live_dds_verified'] == expected['live_dds_verified'] and
            isinstance(manifest['evidence_sha256'], str) and
            hmac.compare_digest(manifest['evidence_sha256'], expected['evidence_sha256']))


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    report = json.loads(args.evidence.read_text(encoding='utf-8'))
    if args.verify:
        valid = verify_manifest(report, json.loads(args.manifest.read_text(encoding='utf-8')))
        print('VALID' if valid else 'INVALID')
        if not valid:
            raise SystemExit(2)
    else:
        if args.manifest.exists():
            parser.error('manifest already exists; refusing overwrite')
        manifest = create_manifest(report)
        with args.manifest.open('x', encoding='utf-8') as handle:
            json.dump(manifest, handle, indent=2, sort_keys=True)
            handle.write('\n')


if __name__ == '__main__':
    main()
