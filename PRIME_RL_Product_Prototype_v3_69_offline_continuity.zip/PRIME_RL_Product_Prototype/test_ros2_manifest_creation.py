"""Evidence creation must reject symlinks, not merely later verification."""
import tempfile
import unittest
from pathlib import Path
from ros2_validation_evidence import build_manifest
from ros2_release_verify import REQUIRED


class ManifestCreationTests(unittest.TestCase):
    def make_tree(self, root):
        for relative in REQUIRED:
            p = root / relative
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(relative, encoding='utf-8')

    def test_regular_source_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make_tree(root)
            report = build_manifest(root, readiness={'ros2_execution_ready': False})
            self.assertEqual(report['validation_status'], 'NOT_EXECUTED')
            self.assertEqual(set(report['artifacts']), REQUIRED)

    def test_symlinked_file_refused_before_hashing(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make_tree(root)
            (root / 'package.xml').unlink()
            (root / 'package.xml').symlink_to('setup.py')
            with self.assertRaisesRegex(ValueError, 'symlinked evidence source'):
                build_manifest(root, readiness={'ros2_execution_ready': False})

    def test_symlinked_launch_directory_refused_before_hashing(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make_tree(root)
            for name in ('scenario.launch.py', 'advisory.launch.py'):
                (root / 'launch' / name).rename(root / name)
            (root / 'launch').rmdir()
            (root / 'launch').symlink_to('.', target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'symlinked evidence source'):
                build_manifest(root, readiness={'ros2_execution_ready': False})
