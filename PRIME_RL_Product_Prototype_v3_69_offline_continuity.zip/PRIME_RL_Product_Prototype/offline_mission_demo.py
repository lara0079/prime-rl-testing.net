"""Real local UDP heartbeat outage + bounded OFFLINE mission in toy kinematics.

Demonstrates supervisor process loss and preauthorized intent progression.
No ROS2, Gazebo, hardware, trusted sensors, or actuator commands.
"""
import argparse
import json
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from authority import sign
from offline_mission_continuity import LocalObservation, OfflineMissionContinuity

DEMO_KEY = b'PRIME-RL-v369-LOCAL-DEMO-NOT-SECRET-key'


def emit(port):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        while True:
            sock.sendto(b'linked-supervisor', ('127.0.0.1', port))
            time.sleep(.1)


def run():
    report = {'name': 'PRIME-RL v3.69 bounded offline continuation',
              'scope': 'local UDP supervisor-process loss and toy 1-D kinematics only',
              'ros2_or_gazebo_executed': False, 'hardware_actuation': False,
              'phases': [], 'confirmed_segments': 0}
    with tempfile.TemporaryDirectory() as d:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as receiver:
            receiver.bind(('127.0.0.1', 0))
            receiver.settimeout(.3)
            port = receiver.getsockname()[1]
            supervisor = None
            gate = OfflineMissionContinuity(Path(d) / 'mission.sqlite', keys={'demo': DEMO_KEY},
                                            issuer='demo-operator', audience='local-robot',
                                            robot_id='toy-robot')
            x = 0.0
            def sample():
                return LocalObservation(time.time() - .05, x, .95, .85)
            def launch():
                return subprocess.Popen([sys.executable, __file__, '--emit', str(port)],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            def hear(timeout=5):
                deadline = time.monotonic()+timeout
                while time.monotonic() < deadline:
                    try:
                        packet, _ = receiver.recvfrom(128)
                        if packet == b'linked-supervisor':
                            return True
                    except socket.timeout:
                        pass
                return False
            def stop(p):
                if p and p.poll() is None:
                    p.terminate()
                    try: p.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        p.kill(); p.wait(timeout=3)
            try:
                supervisor = launch()
                if not hear():
                    raise RuntimeError('OS supervisor process heartbeat never detected')
                report['phases'].append('supervisor_heartbeat_observed')
                now = time.time()
                token = sign({'schema':'prime-rl-offline-plan-v1', 'kid':'demo',
                              'iss':'demo-operator', 'aud':'local-robot',
                              'nbf': now-1, 'exp': now+60, 'nonce':'toy-lease-1',
                              'permissions':['offline:continue'], 'mission_id':'toy-mission',
                              'robot_id':'toy-robot',
                              'plan':[{'step_id':f's{i}', 'target_x':round(.3*i, 2)} for i in range(1, 4)],
                              'offline_limit':15, 'total_limit':1.0, 'step_limit':.4,
                              'lower_x':-1, 'upper_x':1.5,
                              'min_confidence':.7, 'min_battery':.3}, DEMO_KEY)
                staged = gate.stage(token, now=time.time(), connected=True, observation=sample())
                assert staged['accepted']
                report['phases'].append('online_signed_mission_preapproved')
                stop(supervisor)
                supervisor = None
                # Previously queued UDP heartbeats must be drained before loss detection.
                receiver.settimeout(.2)
                while True:
                    try: receiver.recvfrom(128)
                    except socket.timeout: break
                assert not hear(.6), 'supervisor still sending after process stop'
                report['phases'].append('actual_supervisor_process_stopped_and_heartbeats_lost')
                lost = gate.disconnect('toy-mission', now=time.time(), connected=False, observation=sample())
                assert lost['accepted'], lost
                for i in range(3):
                    intent = gate.next_intent('toy-mission',now=time.time(),connected=False,observation=sample())
                    assert intent['accepted'] and intent['advisory_only'], intent
                    assert intent['action']=='bounded_segment'
                    # A toy simulator alone applies intent. The library never touches actuators.
                    target = intent['target_x']
                    assert abs(target - x) <= .4
                    x = target
                    confirm = gate.confirm('toy-mission', intent_id=intent['intent_id'],
                                           now=time.time(), connected=False, observation=sample())
                    assert confirm['accepted'], confirm
                    report['confirmed_segments'] += 1
                report['simulated_position_x'] = x
                assert gate.status('toy-mission')['status'] == 'completed'
                report['phases'].append('three_preapproved_segments_confirmed_while_supervisor_offline')
                supervisor = launch()
                assert hear(), 'supervisor heartbeat was not restored'
                gate.reconnect('toy-mission',now=time.time())
                denied = gate.next_intent('toy-mission',now=time.time(),connected=True,observation=sample())
                assert denied['accepted'] is False
                assert gate.status('toy-mission')['status']=='needs_revalidation'
                report['phases'].append('supervisor_reconnected_new_mission_authority_required')
                report['audit_verified'] = gate.verify_audit()
                report['status'] = 'PASS' if report['audit_verified'] else 'FAIL'
                if report['status'] != 'PASS':
                    raise RuntimeError('audit integrity mismatch')
            finally:
                stop(supervisor)
                gate.close()
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--emit', type=int)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    if args.emit is not None:
        emit(args.emit)
        return
    report = run()
    text = json.dumps(report, indent=2, sort_keys=True) + '\n'
    if args.output:
        args.output.write_text(text, encoding='utf-8')
    print(text, end='')


if __name__=='__main__':
    main()
