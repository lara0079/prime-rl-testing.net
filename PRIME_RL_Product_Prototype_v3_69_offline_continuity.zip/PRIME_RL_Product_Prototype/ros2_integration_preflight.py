"""Fail-closed, read-only integration preflight. Never starts ROS or actuators."""
import argparse
import json
from pathlib import Path
from ros2_readiness import check_environment

REQUIRED = ('package.xml', 'setup.py', 'ros2_advisory_node.py',
            'ros2_live_smoke.py', 'ros2_repeatability.py',
            'launch/advisory.launch.py', 'launch/scenario.launch.py')


def preflight(root=None, *, environment=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parent
    environment = environment if environment is not None else check_environment(package_root=root)
    missing = [name for name in REQUIRED if not (root / name).is_file()]
    checks = environment.get('checks', {})
    required_environment = ('ros2_cli', 'colcon_cli', 'rclpy_importable', 'std_msgs_importable')
    missing_environment = [name for name in required_environment if checks.get(name) is not True]
    # Explicitly no attempt to inspect live topics or assert actuator absence.
    ready = not missing and not missing_environment
    return {'status': 'ready_for_isolated_advisory_smoke' if ready else 'blocked',
            'missing_files': missing, 'missing_environment': missing_environment,
            'actuator_absence_verified': False, 'dds_test_executed': False,
            'gazebo_test_executed': False,
            'note': 'Static readiness only. Independently verify topic graph and disconnect actuators.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args(argv)
    result = preflight(args.root)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['status'] == 'ready_for_isolated_advisory_smoke' else 2


if __name__ == '__main__':
    raise SystemExit(main())
