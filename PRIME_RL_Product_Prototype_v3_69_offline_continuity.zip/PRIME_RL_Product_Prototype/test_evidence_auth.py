import copy
import unittest

from evidence_auth import sign_evidence, verify_evidence
from ros2_repeatability import execute_repetitions


class EvidenceAuthTests(unittest.TestCase):
    def setUp(self):
        self.report = execute_repetitions(2, probe=lambda **kwargs: {
            'status': 'pass', 'timing': {'round_trip_ms': [1.25, 2.5]}})
        self.key = b'a' * 32

    def test_valid_signature_and_wrong_key(self):
        tag = sign_evidence(self.report, self.key)
        self.assertTrue(verify_evidence(self.report, self.key, tag))
        self.assertFalse(verify_evidence(self.report, b'b' * 32, tag))

    def test_consistent_modified_report_is_rejected(self):
        tag = sign_evidence(self.report, self.key)
        altered = copy.deepcopy(self.report)
        altered['runs'][0]['round_trip_ms'][0] = 1.5
        self.assertFalse(verify_evidence(altered, self.key, tag))

    def test_invalid_key_and_tag_fail_closed(self):
        with self.assertRaises(ValueError):
            sign_evidence(self.report, b'weak')
        with self.assertRaises(ValueError):
            verify_evidence(self.report, 'not-bytes', '0' * 64)
        for tag in (None, 'x' * 64, 'A' * 64, ''):
            self.assertFalse(verify_evidence(self.report, self.key, tag))

    def test_structurally_invalid_report_is_rejected(self):
        altered = copy.deepcopy(self.report)
        altered['max_round_trip_ms'] = 999
        with self.assertRaises(ValueError):
            sign_evidence(altered, self.key)
