"""Regression checks for SQLite resource ownership and deterministic shutdown."""
import sqlite3
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from atomic_ledger import AtomicLedger
from ros2_runtime_gate import AdvisoryRuntime


class SQLiteCleanupRegressionTests(unittest.TestCase):
    def test_legacy_ledger_context_manager_closes_connection(self):
        with tempfile.TemporaryDirectory() as folder:
            with Ledger(Path(folder) / 'events.db') as ledger:
                ledger.append({'event': 'test'})
                db = ledger.db
            with self.assertRaises(sqlite3.ProgrammingError):
                db.execute('SELECT 1')

    def test_atomic_ledger_context_manager_closes_connection(self):
        with tempfile.TemporaryDirectory() as folder:
            with AtomicLedger(Path(folder) / 'events.db') as ledger:
                ledger.append({'event': 'test'})
                db = ledger.db
            with self.assertRaises(sqlite3.ProgrammingError):
                db.execute('SELECT 1')

    def test_advisory_runtime_explicit_shutdown_closes_ledger(self):
        with tempfile.TemporaryDirectory() as folder:
            runtime = AdvisoryRuntime(Path(folder) / 'events.db')
            db = runtime.ledger.db
            runtime.close()
            with self.assertRaises(sqlite3.ProgrammingError):
                db.execute('SELECT 1')

if __name__ == '__main__':
    unittest.main()
