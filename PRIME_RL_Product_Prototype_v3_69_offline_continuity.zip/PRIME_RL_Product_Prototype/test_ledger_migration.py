import sqlite3
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from atomic_ledger import AtomicLedger
from ledger_migration import migrate_legacy_ledger

class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.db=Path(self.tmp.name)/'legacy.db'; self.bak=Path(self.tmp.name)/'legacy.bak'

    def test_preserves_events_and_backup(self):
        old=Ledger(self.db)
        for n in range(4): old.append({'n':n})
        old.close()
        result=migrate_legacy_ledger(self.db,self.bak)
        self.assertEqual(result['events'],4)
        current=AtomicLedger(self.db); self.assertEqual(len(current.events()),4)
        current.append({'n':4}); self.assertTrue(current.verify()); current.close()
        backup=Ledger(self.bak); self.assertEqual(len(backup.events()),4); self.assertTrue(backup.verify()); backup.close()

    def test_rejects_tampered_legacy(self):
        old=Ledger(self.db); old.append({'n':1})
        with old.db: old.db.execute("UPDATE events SET payload='{}' WHERE seq=1")
        old.close()
        with self.assertRaisesRegex(ValueError,'integrity'): migrate_legacy_ledger(self.db,self.bak)
        self.assertFalse(self.bak.exists())

    def test_refuses_second_migration(self):
        old=Ledger(self.db); old.append({'n':1}); old.close()
        migrate_legacy_ledger(self.db,self.bak)
        with self.assertRaises(ValueError): migrate_legacy_ledger(self.db,Path(self.tmp.name)/'other.bak')

    def test_rejects_existing_backup(self):
        old=Ledger(self.db); old.close(); self.bak.write_text('do not overwrite')
        with self.assertRaises(ValueError): migrate_legacy_ledger(self.db,self.bak)
        self.assertEqual(self.bak.read_text(),'do not overwrite')

if __name__=='__main__': unittest.main()
