import unittest
from ros2_live_smoke import validate_timings


class TimingContractTests(unittest.TestCase):
    def test_valid_samples(self):
        result = validate_timings([1.25, 3.5], max_latency_ms=5)
        self.assertEqual(result['max_round_trip_ms'], 3.5)

    def test_over_budget_fails(self):
        with self.assertRaises(ValueError):
            validate_timings([1, 6], max_latency_ms=5)

    def test_missing_or_invalid_samples_fail(self):
        for samples in ([], [-1], [float('nan')], [float('inf')]):
            with self.subTest(samples=samples), self.assertRaises(ValueError):
                validate_timings(samples, max_latency_ms=5)

    def test_invalid_budget_fails(self):
        for budget in (0, -1, float('nan'), True):
            with self.subTest(budget=budget), self.assertRaises(ValueError):
                validate_timings([1], max_latency_ms=budget)
