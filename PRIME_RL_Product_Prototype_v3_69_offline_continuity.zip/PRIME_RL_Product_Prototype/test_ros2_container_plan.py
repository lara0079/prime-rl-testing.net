import hashlib
import tempfile
import unittest
from pathlib import Path
from ros2_container_plan import FILES, plan, main


class ContainerPlanTests(unittest.TestCase):
    def test_complete_package_produces_hashes_without_execution(self):
        result = plan()
        self.assertEqual(result['status'], 'ready_for_external_runtime')
        self.assertEqual(len(result['files']), len(FILES))
        self.assertFalse(result['docker_executed'])
        self.assertFalse(result['ros2_executed'])
        self.assertFalse(result['gazebo_executed'])
        self.assertTrue(result['requires_explicit_runtime_opt_in'])

    def test_hashes_are_deterministic_and_match_bytes(self):
        root = Path(__file__).resolve().parent
        self.assertEqual(plan(root), plan(root))
        for entry in plan(root)['files']:
            self.assertEqual(entry['sha256'], hashlib.sha256((root / entry['path']).read_bytes()).hexdigest())

    def test_missing_files_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = plan(tmp)
            self.assertEqual(result['status'], 'blocked')
            self.assertEqual(len(result['problems']), len(FILES))
            self.assertEqual(main(['--root', tmp]), 2)

    def test_symlink_does_not_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in FILES:
                (root / name).write_text('test')
            (root / FILES[0]).unlink()
            (root / FILES[0]).symlink_to(Path(__file__).resolve())
            self.assertEqual(plan(root)['status'], 'blocked')


if __name__ == '__main__':
    unittest.main()
