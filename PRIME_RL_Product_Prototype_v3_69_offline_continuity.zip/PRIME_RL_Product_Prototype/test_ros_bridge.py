import unittest
from ros_bridge import RobotTelemetry, assess

class BridgeTests(unittest.TestCase):
    def sample(self, **changes):
        values = dict(stamp_seconds=10, gnss_quality=.9, odometry_quality=.9,
                      imu_quality=.9, map_freshness=1., battery_fraction=.9, connected=True)
        values.update(changes)
        return RobotTelemetry(**values)

    def test_advisory(self):
        self.assertTrue(assess(self.sample(), 'hold', now_seconds=10)['advisory_only'])
    def test_stale_rejected(self):
        self.assertFalse(assess(self.sample(), 'return', now_seconds=13)['accepted'])
    def test_future_rejected(self):
        self.assertEqual(assess(self.sample(), now_seconds=9)['reason'], 'stale_or_future_telemetry')
    def test_missing_sources(self):
        s=self.sample(gnss_quality=None, odometry_quality=None, imu_quality=None)
        self.assertEqual(assess(s, now_seconds=10)['confidence'], 0.)
    def test_nan_rejected(self):
        with self.assertRaises(ValueError): assess(self.sample(gnss_quality=float('nan')), now_seconds=10)
    def test_bad_time_rejected(self):
        with self.assertRaises(ValueError): assess(self.sample(), now_seconds=float('inf'))
    def test_not_actuator_api(self):
        self.assertNotIn('command', assess(self.sample(), now_seconds=10))
    def test_bad_connection_rejected(self):
        with self.assertRaises(ValueError): assess(self.sample(connected=1), now_seconds=10)

if __name__ == '__main__': unittest.main()
