"""Offline verification of ROS 2 preflight evidence against a source tree.

A matching manifest does not imply that ROS 2/Gazebo was executed.
"""
import argparse
import hashlib
import json
from pathlib import Path


def verify_manifest(manifest, root):
    root = Path(root).resolve()
    issues = []
    if manifest.get('schema_version') != 1:
        issues.append('unsupported schema_version')
    if manifest.get('validation_status') != 'NOT_EXECUTED':
        issues.append('unexpected validation_status')
    artifacts = manifest.get('artifacts')
    if not isinstance(artifacts, dict) or not artifacts:
        return {'verified': False, 'issues': issues + ['missing artifacts']}
    for relative, record in artifacts.items():
        if not isinstance(relative, str) or not isinstance(record, dict):
            issues.append('malformed artifact record')
            continue
        # A symlink at any path component can silently change the source being verified.
        raw = root / relative
        if any(component.is_symlink() for component in (raw, *raw.parents) if component != root and component.is_relative_to(root)):
            issues.append(f'{relative}: symlinked source path')
            continue
        path = raw.resolve()
        if not path.is_relative_to(root) or not path.is_file():
            issues.append(f'{relative}: absent or outside root')
            continue
        if record.get('present') is not True:
            issues.append(f'{relative}: not marked present')
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != record.get('sha256'):
            issues.append(f'{relative}: sha256 mismatch')
    return {'verified': not issues, 'issues': issues,
            'scope': 'source hash consistency only; not ROS 2/Gazebo validation'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args(argv)
    result = verify_manifest(json.loads(args.manifest.read_text(encoding='utf-8')), args.root)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['verified'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
