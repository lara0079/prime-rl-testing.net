"""Fail-closed audit/lifecycle sequencing checks; not distributed atomicity."""
import tempfile
import unittest
from pathlib import Path
from authority import AuthorityVerifier, sign
from lifecycle import LifecycleStore
from ledger import Ledger
from session import GovernedSession

KEY = b'k' * 32

class FailingLedger:
    def append(self, event):
        raise OSError('simulated audit write failure')

class FailingLifecycle:
    def mark_revalidation_required(self):
        pass
    def mark_refreshed(self):
        raise OSError('simulated lifecycle failure')

class RefreshConsistencyTests(unittest.TestCase):
    def token(self, nonce):
        return sign({'kid':'k','iss':'issuer','aud':'robot','nbf':0,'exp':100,
                     'nonce':nonce,'permissions':['inspect']}, KEY)

    def test_lifecycle_failure_never_records_accepted_refresh(self):
        with tempfile.TemporaryDirectory() as td:
            with Ledger(Path(td)/'audit.sqlite') as ledger:
                verifier = AuthorityVerifier({'k':KEY},'issuer','robot')
                session = GovernedSession(verifier, ledger, FailingLifecycle())
                with self.assertRaises(OSError):
                    session.refresh(self.token('n1'), 10, True)
                self.assertEqual(ledger.events(), [])
                self.assertTrue(session.revalidation_required)
                self.assertFalse(session.permissions)

    def test_audit_failure_restores_durable_revalidation(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'state.sqlite'
            lifecycle = LifecycleStore(path)
            try:
                verifier = AuthorityVerifier({'k':KEY},'issuer','robot')
                session = GovernedSession(verifier, FailingLedger(), lifecycle)
                with self.assertRaises(OSError):
                    session.refresh(self.token('n2'), 10, True)
                self.assertTrue(lifecycle.required())
                self.assertTrue(session.revalidation_required)
                self.assertFalse(session.permissions)
            finally:
                lifecycle.close()

    def test_successful_refresh_has_matching_audit_and_clearance(self):
        with tempfile.TemporaryDirectory() as td:
            lifecycle = LifecycleStore(Path(td)/'state.sqlite')
            try:
                with Ledger(Path(td)/'audit.sqlite') as ledger:
                    verifier = AuthorityVerifier({'k':KEY},'issuer','robot')
                    session = GovernedSession(verifier, ledger, lifecycle)
                    self.assertTrue(session.refresh(self.token('n3'), 10, True))
                    self.assertFalse(lifecycle.required())
                    self.assertTrue(ledger.events()[-1]['accepted'])
            finally:
                lifecycle.close()

if __name__ == '__main__':
    unittest.main()
