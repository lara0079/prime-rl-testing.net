"""Prototype cross-file ledger checkpoint; NOT an independent trust anchor."""
import json
import os
import tempfile
from pathlib import Path


def head(ledger):
    row = ledger.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
    return {'seq': row[0], 'hash': row[1]} if row else {'seq': 0, 'hash': '0'*64}


def save_checkpoint(ledger, path):
    """Atomically store the observed head, requiring an existing parent directory."""
    path = Path(path)
    if not path.parent.is_dir() or path.is_symlink():
        raise ValueError('invalid checkpoint path')
    data = json.dumps(head(ledger), sort_keys=True)
    fd, temporary = tempfile.mkstemp(prefix='.checkpoint-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def verify_checkpoint(ledger, path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        return False
    try:
        saved = json.loads(path.read_text())
    except (OSError, ValueError):
        return False
    return saved == head(ledger) and ledger.verify()
