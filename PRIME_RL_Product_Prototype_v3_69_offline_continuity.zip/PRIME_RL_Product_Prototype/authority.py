"""Simulation-only signed authority tokens; HMAC is a local demonstration, not PKI."""
import base64
import hashlib
import hmac
import json
import math
import sqlite3
from dataclasses import dataclass

def encode(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def sign(payload, key):
    if not isinstance(key, bytes) or len(key) < 32:
        raise ValueError('demo key must contain at least 32 bytes')
    body = encode(payload)
    signature = hmac.new(key, body, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(body).decode().rstrip('=') + '.' + base64.urlsafe_b64encode(signature).decode().rstrip('=')

def _decode(part):
    return base64.urlsafe_b64decode(part + '=' * (-len(part) % 4))

@dataclass(frozen=True)
class AuthorityResult:
    valid: bool
    reason: str
    permissions: frozenset = frozenset()
    nonce: str = ''
    expires_at: float = 0.0

class AuthorityVerifier:
    def __init__(self, keys, issuer, audience, replay_db=None):
        self.keys = dict(keys)
        self.issuer = issuer
        self.audience = audience
        self.seen_nonces = set()
        self.replay_db = sqlite3.connect(replay_db) if replay_db is not None else None
        if self.replay_db is not None:
            self.replay_db.execute('PRAGMA journal_mode=WAL')
            self.replay_db.execute('PRAGMA synchronous=FULL')
            self.replay_db.execute('CREATE TABLE IF NOT EXISTS consumed (issuer TEXT NOT NULL, audience TEXT NOT NULL, nonce TEXT NOT NULL, PRIMARY KEY (issuer,audience,nonce))')
            self.replay_db.commit()

    def verify(self, token, now, consume=False):
        try:
            if not math.isfinite(float(now)) or len(token) > 8192:
                return AuthorityResult(False, 'invalid_input')
            body64, sig64 = token.split('.')
            body = _decode(body64)
            payload = json.loads(body)
            if encode(payload) != body:
                return AuthorityResult(False, 'noncanonical_token')
            key = self.keys.get(payload.get('kid'))
            if not key or not hmac.compare_digest(hmac.new(key, body, hashlib.sha256).digest(), _decode(sig64)):
                return AuthorityResult(False, 'invalid_signature')
            if payload.get('iss') != self.issuer or payload.get('aud') != self.audience:
                return AuthorityResult(False, 'wrong_scope')
            if type(payload.get('nbf')) not in (int, float) or type(payload.get('exp')) not in (int, float):
                return AuthorityResult(False, 'invalid_time')
            if not (math.isfinite(payload['nbf']) and math.isfinite(payload['exp']) and payload['nbf'] <= now < payload['exp']):
                return AuthorityResult(False, 'expired_or_not_yet_valid')
            nonce = payload.get('nonce')
            permissions = payload.get('permissions')
            if not isinstance(nonce, str) or not nonce or not isinstance(permissions, list) or not all(isinstance(p,str) for p in permissions):
                return AuthorityResult(False, 'invalid_claims')
            if self.replay_db is not None:
                if consume:
                    try:
                        with self.replay_db:
                            self.replay_db.execute('INSERT INTO consumed VALUES (?,?,?)', (self.issuer,self.audience,nonce))
                    except sqlite3.IntegrityError:
                        return AuthorityResult(False, 'replay_detected')
                elif self.replay_db.execute('SELECT 1 FROM consumed WHERE issuer=? AND audience=? AND nonce=?', (self.issuer,self.audience,nonce)).fetchone():
                    return AuthorityResult(False, 'replay_detected')
            else:
                if nonce in self.seen_nonces:
                    return AuthorityResult(False, 'replay_detected')
                if consume:
                    self.seen_nonces.add(nonce)
            return AuthorityResult(True, 'verified', frozenset(permissions), nonce, float(payload['exp']))
        except (ValueError, TypeError, KeyError, AttributeError, OverflowError):
            return AuthorityResult(False, 'malformed_token')

    def close(self):
        if self.replay_db is not None:
            self.replay_db.close()
