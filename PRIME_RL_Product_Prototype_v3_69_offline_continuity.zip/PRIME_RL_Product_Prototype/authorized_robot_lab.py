"""Synthetic, read-only robot telemetry evaluated with signed mission authority.

No ROS/Gazebo runtime, actuation, or operational safety claim.
"""
import json
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from navigation_lab import LocalizationSample, estimate_confidence
from session import GovernedSession

DEMO_KEY = b'prime-rl-synthetic-key-not-for-deployment-2026'


def run(steps=500):
    if type(steps) is not int or steps < 1:
        raise ValueError('steps must be positive integer')
    phases = ('nominal', 'gnss_loss', 'disconnected', 'stale', 'recovery')
    metrics = {'version': 'v1.9', 'scope': 'signed_authority_synthetic_robot_advisory',
               'steps': steps, 'phase_counts': {p: 0 for p in phases},
               'proposals': {}, 'accepted': {}, 'denied': {}, 'refresh_success': 0,
               'refresh_failure': 0, 'ledger_valid': False}
    with tempfile.TemporaryDirectory() as tmp:
        ledger = Ledger(Path(tmp) / 'events.sqlite')
        verifier = AuthorityVerifier({'demo': DEMO_KEY}, 'robot-lab', 'synthetic-robot')
        session = GovernedSession(verifier, ledger)
        nonce = 0
        for tick in range(steps):
            phase = phases[(tick // 20) % len(phases)]
            metrics['phase_counts'][phase] += 1
            connected = phase != 'disconnected'
            gnss = None if phase in ('gnss_loss', 'disconnected', 'stale') else 0.98
            quality = 0.4 if phase in ('gnss_loss', 'disconnected', 'stale') else 0.98
            sample = LocalizationSample(gnss, quality, quality, quality, 0.8, connected)
            confidence = estimate_confidence(sample)
            now = 1000.0 + tick * 0.1
            # Deliberately stale telemetry must be rejected before the authority gate.
            is_stale = phase == 'stale'
            snapshot = Snapshot(connected, 1.0 if connected else 0.0,
                                confidence, sample.energy, True)
            action = 'hold' if phase in ('disconnected', 'stale') else 'inspect'
            # Observe connectivity transitions before refreshing: refresh does not
            # itself update session.previous_connected.
            if connected and (session.revalidation_required or session.previous_connected is False):
                nonce += 1
                payload = {'kid': 'demo', 'iss': 'robot-lab', 'aud': 'synthetic-robot',
                           'nbf': now - 1, 'exp': now + 1.0,
                           'nonce': f'robot-{nonce}', 'permissions': ['inspect']}
                # Mark the connection transition before granting a fresh token.
                if session.previous_connected is False:
                    session.revalidation_required = True
                ok = session.refresh(sign(payload, DEMO_KEY), now, True)
                metrics['refresh_success' if ok else 'refresh_failure'] += 1
            if is_stale:
                accepted = False
                reason = 'stale_telemetry'
                ledger.append({'kind': 'telemetry_rejected', 'tick': tick, 'reason': reason})
            else:
                decision = session.decide(snapshot, action, now=now)
                accepted, reason = decision['accepted'], decision['reason']
            metrics['proposals'][action] = metrics['proposals'].get(action, 0) + 1
            target = metrics['accepted'] if accepted else metrics['denied']
            target[phase] = target.get(phase, 0) + 1
        metrics['ledger_valid'] = ledger.verify()
        metrics['ledger_events'] = len(ledger.events())
        ledger.close()
        verifier.close()
    metrics['limitations'] = ('Synthetic telemetry and illustrative policy. No ROS 2/Gazebo execution, '
                              'physical dynamics, secure key storage, trusted clock, or certified safety.')
    return metrics


if __name__ == '__main__':
    Path(__file__).with_name('authorized_robot_report.json').write_text(
        json.dumps(run(), indent=2), encoding='utf-8')
