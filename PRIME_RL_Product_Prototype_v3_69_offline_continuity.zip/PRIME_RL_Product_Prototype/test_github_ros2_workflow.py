import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parent

class GithubROS2WorkflowTests(unittest.TestCase):
    def test_manual_only(self):
        y = (ROOT / '.github/workflows/prime-rl-ros2.yml').read_text()
        self.assertIn('workflow_dispatch:', y)
        self.assertNotIn('  push:', y)
        self.assertNotIn('  pull_request:', y)

    def test_isolated_smoke_and_unit_tests(self):
        y = (ROOT / '.github/workflows/prime-rl-ros2.yml').read_text()
        self.assertIn('m unittest discover -q', y)
        self.assertIn('bash run_ros2_container_smoke.sh', y)
        self.assertIn('PRIME_RL_ALLOW_DOCKER:', y)

    def test_read_only_token(self):
        y = (ROOT / '.github/workflows/prime-rl-ros2.yml').read_text()
        self.assertIn('contents: read', y)
        self.assertNotIn('contents: write', y)

if __name__ == '__main__':
    unittest.main()
