"""Offline, non-installing ROS 2 workspace preparation; no network or actuators."""
import argparse
import json
import shutil
from pathlib import Path

PACKAGE = 'prime_rl_advisory'
REQUIRED = ('package.xml', 'setup.py', 'ros2_advisory_node.py', 'ros2_live_smoke.py', 'ros2_integration_preflight.py')


def prepare(source, workspace, *, copy=False):
    source = Path(source).resolve(strict=True)
    workspace = Path(workspace).resolve()
    missing = [name for name in REQUIRED if not (source / name).is_file()]
    if missing:
        raise ValueError('missing package files: ' + ', '.join(missing))
    if source == workspace or source in workspace.parents or workspace in source.parents:
        raise ValueError('source and workspace must not contain each other')
    destination = workspace / 'src' / PACKAGE
    if destination.exists() or destination.is_symlink():
        raise FileExistsError('workspace package already exists: ' + str(destination))
    result = {'source': str(source), 'workspace': str(workspace),
              'destination': str(destination), 'mode': 'copy' if copy else 'dry_run',
              'ros2_executed': False, 'dependencies_installed': False,
              'commands_after_prerequisites': [
                  'source /opt/ros/jazzy/setup.bash',
                  'cd ' + str(workspace) + ' && colcon build --packages-select ' + PACKAGE,
                  'source ' + str(workspace / 'install/setup.bash'),
                  'python3 ' + str(destination / 'ros2_integration_preflight.py')],
              'warning': 'Commands require an independently prepared compatible ROS 2 host; do not attach actuators.'}
    if copy:
        # Exclude generated outputs and prevent symlinks from entering the staging workspace.
        for path in source.rglob('*'):
            if path.is_symlink():
                raise ValueError('source contains symlink: ' + str(path))
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, destination, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.pytest_cache'))
    return result


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, default=Path(__file__).resolve().parent)
    p.add_argument('--workspace', type=Path, required=True)
    p.add_argument('--copy', action='store_true', help='Explicitly copy source into a new workspace (never install dependencies)')
    args = p.parse_args(argv)
    try:
        result = prepare(args.source, args.workspace, copy=args.copy)
    except (ValueError, FileExistsError, OSError) as exc:
        print(json.dumps({'status': 'blocked', 'reason': str(exc)}))
        return 2
    print(json.dumps({'status': 'prepared' if args.copy else 'dry_run', **result}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
