"""Local, durable, tamper-evident simulation ledger (not tamper-proof)."""
import hashlib
import json
import sqlite3
from pathlib import Path

ZERO = '0' * 64

def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), allow_nan=False)

class Ledger:
    def __init__(self, path):
        self.path = str(Path(path))
        self.db = sqlite3.connect(self.path)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY, payload TEXT NOT NULL, previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL)')
        self.db.commit()

    def append(self, event):
        payload = canonical(event)
        with self.db:
            row = self.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
            seq, prev = (row[0]+1, row[1]) if row else (1, ZERO)
            digest = hashlib.sha256(f'{seq}:{prev}:{payload}'.encode()).hexdigest()
            self.db.execute('INSERT INTO events VALUES (?,?,?,?)', (seq,payload,prev,digest))
        return digest

    def verify(self):
        previous = ZERO
        expected = 1
        for seq, payload, prev, digest in self.db.execute('SELECT * FROM events ORDER BY seq'):
            if seq != expected or prev != previous or hashlib.sha256(f'{seq}:{prev}:{payload}'.encode()).hexdigest() != digest:
                return False
            previous = digest
            expected += 1
        return True

    def events(self):
        return [dict(seq=seq, **json.loads(payload), event_hash=digest) for seq,payload,_,digest in self.db.execute('SELECT * FROM events ORDER BY seq')]

    def close(self):
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
