"""Process-level crash tests for committed and uncommitted SQLite ledger writes."""
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from atomic_ledger import AtomicLedger


class CrashRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'events.db'

    def child(self, script):
        env = os.environ.copy()
        env['PYTHONPATH'] = str(Path(__file__).resolve().parent)
        result = subprocess.run([sys.executable, '-c', script, str(self.path)],
                                env=env, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 77, result.stderr)

    def test_uncommitted_insert_and_head_update_are_rolled_back_after_process_exit(self):
        with AtomicLedger(self.path) as ledger:
            ledger.append({'event': 'baseline'})
        self.child('''
import os, sys, hashlib
from atomic_ledger import AtomicLedger
from ledger import canonical
ledger = AtomicLedger(sys.argv[1])
ledger.db.execute('BEGIN IMMEDIATE')
seq, previous = ledger.db.execute('SELECT seq,event_hash FROM ledger_head WHERE id=1').fetchone()
payload = canonical({'event': 'uncommitted'})
digest = hashlib.sha256(f'{seq+1}:{previous}:{payload}'.encode()).hexdigest()
ledger.db.execute('INSERT INTO events VALUES (?,?,?,?)', (seq+1,payload,previous,digest))
ledger.db.execute('UPDATE ledger_head SET seq=?,event_hash=? WHERE id=1', (seq+1,digest))
os._exit(77)
''')
        with AtomicLedger(self.path) as ledger:
            self.assertTrue(ledger.verify())
            self.assertEqual(len(ledger.events()), 1)
            ledger.append({'event': 'after-restart'})
            self.assertEqual([e['seq'] for e in ledger.events()], [1, 2])

    def test_committed_event_survives_abrupt_process_exit(self):
        self.child('''
import os, sys
from atomic_ledger import AtomicLedger
ledger = AtomicLedger(sys.argv[1])
ledger.append({'event': 'committed'})
os._exit(77)
''')
        with AtomicLedger(self.path) as ledger:
            self.assertTrue(ledger.verify())
            self.assertEqual(ledger.events()[0]['event'], 'committed')

    def test_crash_during_first_write_preserves_empty_chain(self):
        with AtomicLedger(self.path):
            pass
        self.child('''
import os, sys
from atomic_ledger import AtomicLedger
ledger = AtomicLedger(sys.argv[1])
ledger.db.execute('BEGIN IMMEDIATE')
ledger.db.execute("INSERT INTO events VALUES (1,'{}',?,?)", ('0'*64, 'f'*64))
os._exit(77)
''')
        with AtomicLedger(self.path) as ledger:
            self.assertTrue(ledger.verify())
            self.assertEqual(ledger.events(), [])
