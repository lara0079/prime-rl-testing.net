import tempfile
import unittest
from pathlib import Path
from ros2_offline_handoff import REQUIRED, build_manifest, main


class OfflineHandoffTests(unittest.TestCase):
    def test_real_package_manifest(self):
        result = build_manifest(Path(__file__).parent)
        self.assertEqual(len(result['required_file_sha256']), len(REQUIRED))
        self.assertFalse(result['dds_messages_exchanged'])
        self.assertFalse(result['gazebo_simulation_verified'])

    def test_missing_file_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                build_manifest(tmp)

    def test_write_then_refuse_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'handoff.json'
            root = Path(__file__).parent
            self.assertEqual(main(['--root', str(root), '--output', str(path)]), 0)
            self.assertTrue(path.is_file())
            self.assertEqual(main(['--root', str(root), '--output', str(path)]), 2)

    def test_hashes_are_repeatable(self):
        root = Path(__file__).parent
        self.assertEqual(build_manifest(root), build_manifest(root))
