import unittest
from ros2_repeatability import execute_repetitions, validate_evidence_report


class TestRepeatability(unittest.TestCase):
    def test_multiple_runs_and_aggregate(self):
        calls = []
        def probe(**kwargs):
            calls.append(kwargs)
            return {'status': 'pass', 'timing': {'round_trip_ms': [1.2, 2.4]}}
        result = execute_repetitions(3, probe=probe)
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(result['completed_repetitions'], 3)
        self.assertEqual(result['max_round_trip_ms'], 2.4)
        self.assertFalse(result['live_dds_verified'])
        self.assertEqual(len(calls), 3)

    def test_failure_stops_repetitions(self):
        calls = []
        def probe(**kwargs):
            calls.append(1)
            raise TimeoutError('DDS disconnected')
        result = execute_repetitions(5, probe=probe)
        self.assertEqual(result['status'], 'fail')
        self.assertEqual(result['completed_repetitions'], 1)
        self.assertEqual(len(calls), 1)

    def test_invalid_metrics_rejected(self):
        for value in [float('nan'), float('inf'), -1, 5001, True]:
            with self.subTest(value=value):
                result = execute_repetitions(1, probe=lambda **kwargs: {'status': 'pass', 'timing': {'round_trip_ms': [value]}})
                self.assertEqual(result['status'], 'fail')

    def test_invalid_count_rejected(self):
        for count in [0, 101, 1.5, True]:
            with self.subTest(count=count):
                with self.assertRaises(ValueError):
                    execute_repetitions(count, probe=lambda **kwargs: None)

    def test_report_consistency_detects_tampering(self):
        report = execute_repetitions(2, probe=lambda **kw: {'status': 'pass', 'timing': {'round_trip_ms': [1.0, 2.0]}})
        self.assertTrue(validate_evidence_report(report))
        report['max_round_trip_ms'] = 0.0
        with self.assertRaises(ValueError):
            validate_evidence_report(report)

    def test_report_rejects_invalid_timestamp_and_status(self):
        report = execute_repetitions(1, probe=lambda **kw: {'status': 'pass', 'timing': {'round_trip_ms': [1.0]}})
        report['runs'][0]['started_utc'] = 'not a timestamp'
        with self.assertRaises(ValueError):
            validate_evidence_report(report)
        report['runs'][0]['started_utc'] = '2026-10-18T12:00:00+00:00'
        report['status'] = 'fail'
        with self.assertRaises(ValueError):
            validate_evidence_report(report)

    def test_invalid_timeout_and_latency_budget(self):
        for value in [0, -1, float('nan'), float('inf'), True]:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    execute_repetitions(1, timeout=value)
                with self.assertRaises(ValueError):
                    execute_repetitions(1, max_latency_ms=value)


if __name__ == '__main__':
    unittest.main()

class TestEvidenceDigest(unittest.TestCase):
    def make_report(self):
        return execute_repetitions(2, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': [1.0, 2.0]}})

    def test_digest_is_stable_across_json_roundtrip(self):
        import json
        from ros2_repeatability import evidence_sha256, verify_evidence_digest
        report = self.make_report()
        digest = evidence_sha256(report)
        self.assertEqual(len(digest), 64)
        self.assertTrue(verify_evidence_digest(json.loads(json.dumps(report)), digest))

    def test_modified_but_consistent_report_changes_digest(self):
        from ros2_repeatability import evidence_sha256, verify_evidence_digest
        report = self.make_report()
        digest = evidence_sha256(report)
        report['runs'][0]['round_trip_ms'][0] = 1.5
        self.assertFalse(verify_evidence_digest(report, digest))

    def test_bad_digest_rejected(self):
        from ros2_repeatability import verify_evidence_digest
        for bad in ('', 'A' * 64, 'z' * 64, None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                verify_evidence_digest(self.make_report(), bad)
