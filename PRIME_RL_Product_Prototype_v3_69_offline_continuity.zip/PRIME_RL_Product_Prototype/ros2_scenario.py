"""Deterministic, simulation-only ROS 2 telemetry scenario; never commands motion."""
import json
from ros_bridge import RobotTelemetry

SCENARIO = ('nominal', 'gnss_loss', 'disconnected', 'stale', 'recovery')


def scenario_payload(phase: str, *, now_seconds: float) -> str:
    if phase not in SCENARIO:
        raise ValueError('unknown phase')
    if not isinstance(now_seconds, (float, int)) or isinstance(now_seconds, bool):
        raise ValueError('invalid timestamp')
    import math
    if not math.isfinite(now_seconds):
        raise ValueError('nonfinite timestamp')
    degraded = phase in ('gnss_loss', 'disconnected')
    sample = RobotTelemetry(
        stamp_seconds=float(now_seconds) - (10.0 if phase == 'stale' else 0.0),
        gnss_quality=None if degraded else 0.95,
        odometry_quality=0.45 if degraded else 0.95,
        imu_quality=0.45 if degraded else 0.95,
        map_freshness=0.4 if degraded else 0.95,
        battery_fraction=0.7,
        connected=phase not in ('disconnected',),
    )
    return json.dumps(vars(sample), sort_keys=True, allow_nan=False)


def main(args=None):
    try:
        import rclpy
        from rclpy.node import Node
        from std_msgs.msg import String
    except ImportError as exc:
        raise RuntimeError('ROS 2 rclpy and std_msgs required') from exc
    from ros2_advisory_node import INPUT_TOPIC

    class ScenarioNode(Node):
        def __init__(self):
            super().__init__('prime_rl_scenario')
            self.publisher = self.create_publisher(String, INPUT_TOPIC, 10)
            self.index = 0
            self.timer = self.create_timer(1.0, self.tick)

        def tick(self):
            phase = SCENARIO[self.index % len(SCENARIO)]
            now = self.get_clock().now().nanoseconds / 1e9
            msg = String()
            msg.data = scenario_payload(phase, now_seconds=now)
            self.publisher.publish(msg)
            self.get_logger().info('simulated telemetry phase=%s' % phase)
            self.index += 1

    rclpy.init(args=args)
    node = None
    try:
        node = ScenarioNode()
        rclpy.spin(node)
    finally:
        if node is not None:
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
