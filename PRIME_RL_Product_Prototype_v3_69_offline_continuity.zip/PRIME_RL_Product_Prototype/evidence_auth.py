"""Optional HMAC authentication of repeatability reports, not hardware attestation."""
import hashlib
import hmac
import json

from ros2_repeatability import validate_evidence_report

DOMAIN = b'PRIME-RL/ROS2-REPORT/v1\0'


def _key(secret):
    if not isinstance(secret, bytes) or len(secret) < 32:
        raise ValueError('authentication key must contain at least 32 bytes')
    return secret


def _payload(report):
    validate_evidence_report(report)
    return DOMAIN + json.dumps(report, sort_keys=True, separators=(',', ':'),
                               ensure_ascii=False, allow_nan=False).encode('utf-8')


def sign_evidence(report, secret):
    """Return a hex HMAC-SHA256 tag; never embed the secret in report artifacts."""
    return hmac.new(_key(secret), _payload(report), hashlib.sha256).hexdigest()


def verify_evidence(report, secret, tag):
    """Return False for malformed tags, altered reports or incorrect keys."""
    key = _key(secret)
    if not isinstance(tag, str) or len(tag) != 64 or any(c not in '0123456789abcdef' for c in tag):
        return False
    return hmac.compare_digest(hmac.new(key, _payload(report), hashlib.sha256).hexdigest(), tag)
