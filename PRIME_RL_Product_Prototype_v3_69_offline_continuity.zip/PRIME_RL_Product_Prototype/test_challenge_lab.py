import unittest
from challenge_lab import run

class ChallengeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = run(cycles=12)
        cls.m = cls.result['metrics']

    def test_forced_offline_inspection_is_exercised_and_blocked(self):
        self.assertEqual(self.m['offline_inspection_proposals'],12)
        self.assertEqual(self.m['offline_inspection_accepted'],0)

    def test_expired_inspection_is_exercised_and_blocked(self):
        self.assertEqual(self.m['expired_inspection_proposals'],12)
        self.assertEqual(self.m['expired_inspection_accepted'],0)

    def test_online_inspection_is_possible(self):
        self.assertEqual(self.m['online_inspection_accepted'],12)

    def test_offline_hold_remains_possible(self):
        self.assertEqual(self.m['offline_hold_accepted'],12)

    def test_evidence_and_reproducibility(self):
        self.assertTrue(self.m['ledger_integrity'])
        self.assertEqual(self.result,run(cycles=12))

    def test_invalid_cycles_rejected(self):
        for n in [0,-1,1.5]:
            with self.assertRaises(ValueError): run(n)

if __name__ == '__main__': unittest.main()
