"""ROS-independent authorized advisory boundary, simulation only; never actuator control.

Authorization tokens arrive via a separate trusted local control path, not telemetry JSON.
This module intentionally exposes no ROS command publisher or motion interface.
"""
import json
from math import isfinite
from ros2_boundary_hardening import MAX_BYTES, _unique_pairs
from ros_bridge import RobotTelemetry
from navigation_lab import LocalizationSample, estimate_confidence
from core import Snapshot

class GovernedAdvisory:
    def __init__(self, session, max_age_seconds=2.0):
        if not isinstance(max_age_seconds, (int, float)) or isinstance(max_age_seconds, bool) or not isfinite(max_age_seconds) or max_age_seconds <= 0:
            raise ValueError('invalid maximum telemetry age')
        self.session = session
        self.max_age_seconds = max_age_seconds
        self.last_stamp = None
        self.last_now = None

    def evaluate(self, payload, *, now_seconds, action='inspect'):
        def reject(reason):
            return {'accepted': False, 'reason': reason, 'advisory_only': True}
        if not isinstance(now_seconds, (int, float)) or isinstance(now_seconds, bool) or not isfinite(now_seconds):
            return reject('invalid_clock')
        # Detect backwards local time rather than trusting a regressed clock for expiry.
        if self.last_now is not None and now_seconds < self.last_now:
            self.session.revalidation_required = True
            if self.session.lifecycle: self.session.lifecycle.mark_revalidation_required()
            return reject('clock_regression')
        self.last_now = now_seconds
        try:
            if not isinstance(payload, str) or len(payload.encode('utf-8')) > MAX_BYTES:
                raise ValueError('invalid payload size or type')
            raw = json.loads(payload, object_pairs_hook=_unique_pairs,
                             parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON constant')))
            if not isinstance(raw, dict) or set(raw) != set(RobotTelemetry.__dataclass_fields__):
                raise ValueError('telemetry schema mismatch')
            telemetry = RobotTelemetry(**raw)
            if not isinstance(telemetry.connected, bool):
                raise ValueError('connected must be boolean')
            for t in (telemetry.stamp_seconds,):
                if not isinstance(t, (int, float)) or isinstance(t, bool) or not isfinite(t):
                    raise ValueError('invalid stamp')
            sample = LocalizationSample(telemetry.gnss_quality, telemetry.odometry_quality,
                                        telemetry.imu_quality, telemetry.map_freshness,
                                        telemetry.battery_fraction, telemetry.connected)
            sample.validate()
        except (ValueError, TypeError, OverflowError, UnicodeError, KeyError):
            return reject('invalid_telemetry')
        if telemetry.stamp_seconds > now_seconds or now_seconds - telemetry.stamp_seconds > self.max_age_seconds:
            return reject('stale_or_future_telemetry')
        if self.last_stamp is not None and telemetry.stamp_seconds <= self.last_stamp:
            return reject('replayed_or_out_of_order_telemetry')
        self.last_stamp = telemetry.stamp_seconds
        confidence = estimate_confidence(sample)
        snapshot = Snapshot(telemetry.connected, 1.0 if telemetry.connected else 0.0,
                            confidence, telemetry.battery_fraction, True)
        decision = self.session.decide(snapshot, action, now=now_seconds)
        return {'accepted': bool(decision['accepted']), 'reason': decision['reason'],
                'state': decision['state'], 'advisory_only': True, 'confidence': confidence}
