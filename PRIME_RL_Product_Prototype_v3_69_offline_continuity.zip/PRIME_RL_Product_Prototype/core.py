"""PRIME-RL simulation-only offline governance prototype.
Not certified for physical actuation or safety-critical deployment.
"""
from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
import json

class State(str, Enum):
    ONLINE='online'
    DEGRADED='degraded'
    DISCONNECTED='disconnected'
    EXPIRED='authority_expired'

@dataclass(frozen=True)
class Snapshot:
    connected: bool
    link_quality: float
    sensor_confidence: float
    energy_fraction: float
    authority_valid: bool
    integrity_ok: bool = True

class Runtime:
    def __init__(self):
        self.events=[]
        self.last_hash='0'*64

    def evaluate(self, s: Snapshot, proposed: str):
        if not s.integrity_ok or not s.authority_valid:
            state=State.EXPIRED
        elif not s.connected:
            state=State.DISCONNECTED
        elif min(s.link_quality,s.sensor_confidence,s.energy_fraction)<0.5:
            state=State.DEGRADED
        else:
            state=State.ONLINE
        # Illustrative conservative demo policy, not proprietary production logic.
        allowed={State.ONLINE:{'inspect','hold','return','signal'},
                 State.DEGRADED:{'hold','return','signal'},
                 State.DISCONNECTED:{'hold','return','signal'},
                 State.EXPIRED:{'hold','signal'}}[state]
        if s.energy_fraction<0.2 or s.sensor_confidence<0.25:
            allowed=allowed & {'hold','signal'}
        accepted=proposed in allowed
        record={'state':state.value,'proposed':proposed,'accepted':accepted,'allowed':sorted(allowed)}
        payload=json.dumps(record,sort_keys=True,separators=(',',':'))
        self.last_hash=sha256((self.last_hash+payload).encode()).hexdigest()
        self.events.append({**record,'chain_hash':self.last_hash})
        return record
