import sqlite3
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from atomic_ledger import AtomicLedger

class LedgerContextTests(unittest.TestCase):
    def test_legacy_context_closes_on_success(self):
        with tempfile.TemporaryDirectory() as d:
            with Ledger(Path(d)/"a.db") as ledger:
                ledger.append({"event": 1})
                connection = ledger.db
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute("SELECT 1")

    def test_atomic_context_closes_on_success(self):
        with tempfile.TemporaryDirectory() as d:
            with AtomicLedger(Path(d)/"a.db") as ledger:
                ledger.append({"event": 1})
                connection = ledger.db
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute("SELECT 1")

    def test_context_closes_on_exception(self):
        with tempfile.TemporaryDirectory() as d:
            connection = None
            with self.assertRaisesRegex(RuntimeError, "abort"):
                with AtomicLedger(Path(d)/"a.db") as ledger:
                    connection = ledger.db
                    raise RuntimeError("abort")
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute("SELECT 1")

if __name__ == "__main__":
    unittest.main()
