"""Simulation-only evaluation metrics, not physical safety certification."""
import statistics
import time
from core import Runtime, Snapshot

def percentile(values, pct):
    ordered = sorted(values)
    return ordered[min(len(ordered)-1, max(0, int((len(ordered)-1)*pct)))] if ordered else None

def benchmark(iterations=1000):
    if iterations <= 0: raise ValueError('iterations must be positive')
    runtime = Runtime()
    scenarios = [
        ('online', Snapshot(True,1,1,1,True), 'inspect', True),
        ('degraded', Snapshot(True,.3,1,1,True), 'inspect', False),
        ('disconnected', Snapshot(False,0,1,1,True), 'inspect', False),
        ('expired', Snapshot(False,0,1,1,False), 'inspect', False),
        ('low_energy', Snapshot(False,0,1,.1,True), 'return', False),
        ('low_sensor', Snapshot(True,1,.1,1,True), 'return', False),
        ('offline_recovery', Snapshot(False,0,1,1,True), 'hold', True),
        ('integrity_failure', Snapshot(True,1,1,1,True,False), 'inspect', False),
    ]
    latencies=[]
    correct=0
    rejected=0
    unsafe_acceptances=0
    for i in range(iterations):
        _, snap, action, expected = scenarios[i % len(scenarios)]
        start = time.perf_counter_ns()
        actual = runtime.evaluate(snap,action)['accepted']
        latencies.append((time.perf_counter_ns()-start)/1e6)
        correct += actual == expected
        rejected += not actual
        unsafe_acceptances += actual and not expected
    return {'iterations':iterations, 'scenario_count':len(scenarios), 'expected_outcome_accuracy':correct/iterations,
            'unexpected_acceptances':unsafe_acceptances,'rejection_rate':rejected/iterations,
            'decision_latency_ms':{'p50':percentile(latencies,.5),'p95':percentile(latencies,.95),'p99':percentile(latencies,.99)},
            'scope':'illustrative deterministic simulation; not a physical safety or security guarantee'}
