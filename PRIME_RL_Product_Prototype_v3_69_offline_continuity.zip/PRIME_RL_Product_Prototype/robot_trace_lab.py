"""Deterministic 2D robot trace and read-only PRIME-RL advisory evaluation.

Not Gazebo, physics validation, motor control, or real-world safety evidence.
"""
from dataclasses import dataclass
import json
import math
import random
from pathlib import Path
from ros_bridge import RobotTelemetry, assess

@dataclass(frozen=True)
class TracePoint:
    tick: int
    x: float
    y: float
    localization_error: float
    phase: str
    advisory: dict


def run(seed=2026, steps=500, dt=0.1):
    if isinstance(steps, bool) or not isinstance(steps, int) or steps <= 0:
        raise ValueError('steps must be positive integer')
    if not isinstance(dt, (int, float)) or isinstance(dt, bool) or not math.isfinite(dt) or dt <= 0:
        raise ValueError('dt must be finite and positive')
    rng = random.Random(seed)
    x = y = 0.0
    points = []
    counts = {'nominal': 0, 'gnss_loss': 0, 'disconnected': 0, 'stale': 0, 'recovery': 0}
    denied = 0
    for tick in range(steps):
        phase = ('nominal', 'gnss_loss', 'disconnected', 'stale', 'recovery')[(tick // 20) % 5]
        counts[phase] += 1
        # Exogenous, scripted robot path: PRIME-RL cannot control movement.
        x += 0.1 * dt
        y += 0.03 * math.sin(tick * dt) * dt
        error_scale = 0.02 if phase in ('nominal', 'recovery') else 0.5
        localization_error = math.hypot(rng.gauss(0, error_scale), rng.gauss(0, error_scale))
        now = tick * dt + 100.0
        degraded = phase in ('gnss_loss', 'disconnected', 'stale')
        telemetry = RobotTelemetry(
            stamp_seconds=now - (5.0 if phase == 'stale' else 0.0),
            gnss_quality=None if degraded else 0.95,
            odometry_quality=0.35 if degraded else 0.95,
            imu_quality=0.35 if degraded else 0.95,
            map_freshness=0.35 if degraded else 0.95,
            battery_fraction=0.75,
            connected=phase != 'disconnected',
        )
        advisory = assess(telemetry, action='return', now_seconds=now)
        denied += not advisory['accepted']
        points.append(TracePoint(tick, round(x, 6), round(y, 6), round(localization_error, 6), phase, advisory))
    return {
        'version': 'v1.8', 'scope': 'scripted_2d_kinematics_read_only_advisory',
        'seed': seed, 'steps': steps, 'dt': dt,
        'phase_counts': counts, 'denied_advisories': denied,
        'accepted_advisories': steps - denied,
        'mean_synthetic_localization_error': round(sum(p.localization_error for p in points) / steps, 6),
        'trace': [vars(p) for p in points],
        'limitations': 'Scripted 2D path, not Gazebo or physical dynamics; no actuation, localization estimator, trusted clock, or robot safety certification.'
    }

if __name__ == '__main__':
    Path(__file__).with_name('robot_trace_report.json').write_text(json.dumps(run(), indent=2), encoding='utf-8')
