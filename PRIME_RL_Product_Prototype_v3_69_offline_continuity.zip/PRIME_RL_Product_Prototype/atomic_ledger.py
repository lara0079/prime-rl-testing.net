"""SQLite-atomic ledger head, NOT an external trust anchor or anti-rollback security."""
import hashlib
import json
from ledger import Ledger, ZERO, canonical


class AtomicLedger(Ledger):
    def __init__(self, path):
        super().__init__(path)
        try:
            with self.db:
                self.db.execute('CREATE TABLE IF NOT EXISTS ledger_head (id INTEGER PRIMARY KEY CHECK(id=1), seq INTEGER NOT NULL, event_hash TEXT NOT NULL)')
                row = self.db.execute('SELECT seq,event_hash FROM ledger_head WHERE id=1').fetchone()
                if row is None:
                    # Never silently initialize over an existing history.
                    if self.db.execute('SELECT 1 FROM events LIMIT 1').fetchone():
                        raise ValueError('existing history without atomic head: explicit migration required')
                    self.db.execute('INSERT INTO ledger_head VALUES (1,0,?)', (ZERO,))
            if not self.verify():
                raise ValueError('atomic ledger integrity check failed')
        except Exception:
            self.close()
            raise

    def append(self, event, *, inject_failure=False, inject_failure_after_head=False):
        """Serialize independent SQLite writers before reading the chain head.

        BEGIN IMMEDIATE acquires the SQLite writer reservation before the read;
        otherwise concurrent connections may both select the same sequence.
        """
        payload = canonical(event)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            seq, previous = self.db.execute('SELECT seq,event_hash FROM ledger_head WHERE id=1').fetchone()
            digest = hashlib.sha256(f'{seq+1}:{previous}:{payload}'.encode()).hexdigest()
            self.db.execute('INSERT INTO events VALUES (?,?,?,?)', (seq+1,payload,previous,digest))
            if inject_failure:
                raise RuntimeError('injected failure before head update')
            self.db.execute('UPDATE ledger_head SET seq=?, event_hash=? WHERE id=1', (seq+1,digest))
            if inject_failure_after_head:
                raise RuntimeError('injected failure after head update')
            self.db.commit()
            return digest
        except BaseException:
            self.db.rollback()
            raise

    def verify(self):
        if not super().verify():
            return False
        saved = self.db.execute('SELECT seq,event_hash FROM ledger_head WHERE id=1').fetchone()
        observed = self.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
        return saved == (observed if observed else (0, ZERO))
