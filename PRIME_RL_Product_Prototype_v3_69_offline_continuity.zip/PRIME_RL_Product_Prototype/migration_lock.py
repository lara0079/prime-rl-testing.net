"""Cooperative, process-level migration exclusion on POSIX systems.

All participating writers must acquire the same lock; this does not stop
uncooperative SQLite clients or protect against privileged file tampering.
"""
import fcntl
import os
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def migration_lock(database_path):
    path = Path(str(database_path) + '.migration.lock')
    if path.is_symlink():
        raise ValueError('migration lock path cannot be a symlink')
    flags = os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('migration lock already held') from exc
        yield
    finally:
        os.close(fd)
