import tempfile
import unittest
from pathlib import Path
from ros2_integration_preflight import REQUIRED, preflight


class IntegrationPreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in REQUIRED:
            p = self.root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text('test', encoding='utf-8')
        self.environment = {'checks': dict.fromkeys(
            ('ros2_cli', 'colcon_cli', 'rclpy_importable', 'std_msgs_importable'), True)}

    def test_all_prerequisites_only_allows_smoke_not_attestation(self):
        result = preflight(self.root, environment=self.environment)
        self.assertEqual(result['status'], 'ready_for_isolated_advisory_smoke')
        self.assertFalse(result['dds_test_executed'])
        self.assertFalse(result['actuator_absence_verified'])

    def test_missing_file_blocks(self):
        (self.root / 'ros2_live_smoke.py').unlink()
        result = preflight(self.root, environment=self.environment)
        self.assertEqual(result['status'], 'blocked')
        self.assertIn('ros2_live_smoke.py', result['missing_files'])

    def test_missing_ros_dependency_blocks(self):
        self.environment['checks']['rclpy_importable'] = False
        result = preflight(self.root, environment=self.environment)
        self.assertEqual(result['status'], 'blocked')
        self.assertIn('rclpy_importable', result['missing_environment'])

    def test_absent_check_fails_closed(self):
        result = preflight(self.root, environment={'checks': {}})
        self.assertEqual(result['status'], 'blocked')
        self.assertEqual(len(result['missing_environment']), 4)
