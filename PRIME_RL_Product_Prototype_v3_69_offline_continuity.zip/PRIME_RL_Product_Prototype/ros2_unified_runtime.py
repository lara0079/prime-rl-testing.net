"""Opt-in ROS-independent advisory adapter for unified authority storage.

No ROS subscriptions for credentials and no actuator publisher. A trusted local
controller must explicitly call refresh; telemetry cannot authorize missions.
"""
import json
from pathlib import Path
from authority import AuthorityVerifier
from ledger import Ledger
from ros2_governed_advisory import GovernedAdvisory
from unified_authority_store import UnifiedAuthorityStore
from unified_session import UnifiedGovernedSession


class UnifiedAdvisoryRuntime:
    def __init__(self, authority_path, decision_ledger_path, *, verifier=None):
        if not authority_path or not decision_ledger_path:
            raise ValueError('durable storage paths required')
        if Path(authority_path).resolve() == Path(decision_ledger_path).resolve():
            raise ValueError('authority and decision ledger must use separate paths')
        self.store = None
        self.ledger = None
        self.verifier = verifier if verifier is not None else AuthorityVerifier({}, 'local', 'robot')
        self.owns_verifier = verifier is None
        try:
            self.store = UnifiedAuthorityStore(authority_path)
            if not self.store.verify_audit():
                raise ValueError('unified authority audit integrity failure')
            self.ledger = Ledger(decision_ledger_path)
            if not self.ledger.verify():
                raise ValueError('decision ledger integrity failure')
            self.session = UnifiedGovernedSession(self.verifier, self.ledger, self.store)
            self.gate = GovernedAdvisory(self.session)
        except BaseException:
            self.close()
            raise

    def refresh_from_trusted_control(self, token, *, now_seconds, connected):
        """Not exposed via ROS telemetry, parameters, or environment variables."""
        return self.session.refresh(token, now_seconds, connected)

    def evaluate(self, payload, now_seconds):
        return json.dumps(self.gate.evaluate(payload, now_seconds=now_seconds),
                          sort_keys=True, allow_nan=False)

    def close(self):
        try:
            if self.ledger is not None:
                self.ledger.close()
        finally:
            try:
                if self.store is not None:
                    self.store.close()
            finally:
                if self.owns_verifier:
                    self.verifier.close()
