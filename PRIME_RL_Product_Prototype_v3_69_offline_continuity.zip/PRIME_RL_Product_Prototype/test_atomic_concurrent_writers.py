"""Concurrent independent SQLite connections and transactional rollback tests."""
import concurrent.futures
import tempfile
import unittest
from pathlib import Path
from atomic_ledger import AtomicLedger


class AtomicConcurrentWriterTests(unittest.TestCase):
    def test_two_independent_writers_preserve_sequence(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'ledger.sqlite3'
            with AtomicLedger(path):
                pass

            def writer(worker):
                with AtomicLedger(path) as ledger:
                    for i in range(25):
                        ledger.append({'worker': worker, 'i': i})

            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                list(pool.map(writer, (1, 2)))
            with AtomicLedger(path) as ledger:
                events = ledger.events()
                self.assertEqual(len(events), 50)
                self.assertEqual([event['seq'] for event in events], list(range(1, 51)))
                self.assertTrue(ledger.verify())

    def test_failure_after_head_update_rolls_back_both_tables(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'ledger.sqlite3'
            with AtomicLedger(path) as ledger:
                ledger.append({'event': 'committed'})
                with self.assertRaisesRegex(RuntimeError, 'after head'):
                    ledger.append({'event': 'rolled back'}, inject_failure_after_head=True)
                self.assertEqual(len(ledger.events()), 1)
                self.assertTrue(ledger.verify())
            with AtomicLedger(path) as reopened:
                self.assertEqual(len(reopened.events()), 1)
                self.assertTrue(reopened.verify())

    def test_following_append_after_rollback_uses_correct_head(self):
        with tempfile.TemporaryDirectory() as directory:
            with AtomicLedger(Path(directory) / 'ledger.sqlite3') as ledger:
                with self.assertRaises(RuntimeError):
                    ledger.append({'event': 'discard'}, inject_failure_after_head=True)
                ledger.append({'event': 'accepted'})
                self.assertEqual([event['seq'] for event in ledger.events()], [1])
                self.assertTrue(ledger.verify())

if __name__ == '__main__':
    unittest.main()
