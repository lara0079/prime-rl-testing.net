import json
import unittest
from ros2_contract_lab import BASE, run
from ros2_advisory_node import evaluate_payload

class ContractTests(unittest.TestCase):
    def test_reproducible_campaign(self):
        self.assertEqual(run(cases=250), run(cases=250))
    def test_campaign_counts(self):
        report = run(cases=300)
        self.assertEqual(report['outcomes']['accepted'] + report['outcomes']['rejected'], 300)
    def test_deeply_wrong_fields(self):
        for field in BASE:
            with self.subTest(field=field):
                obj = dict(BASE); obj[field] = {'nested': ['unexpected']}
                result = json.loads(evaluate_payload(json.dumps(obj), now_seconds=100.0))
                self.assertFalse(result['accepted'])
    def test_no_implicit_action_commands(self):
        obj = dict(BASE); obj['cmd_vel'] = {'linear': 1}
        result = json.loads(evaluate_payload(json.dumps(obj), now_seconds=100.0))
        self.assertFalse(result['accepted'])
    def test_invalid_cases_count(self):
        with self.assertRaises(ValueError): run(cases=0)
    def test_nonfinite_clock_rejected(self):
        result = json.loads(evaluate_payload(json.dumps(BASE), now_seconds=float('nan')))
        self.assertFalse(result['accepted'])

if __name__ == '__main__': unittest.main()
