import unittest
from navigation_lab import LocalizationSample, estimate_confidence, evaluate_navigation, run

class NavigationLabTests(unittest.TestCase):
    def test_missing_all_sources(self):
        self.assertEqual(estimate_confidence(LocalizationSample(None,None,None,1,1,False)),0)
    def test_low_confidence_blocks_return(self):
        self.assertFalse(evaluate_navigation(LocalizationSample(None,0.9,0.9,0.1,0.9,False))['decision']['accepted'])
    def test_offline_hold_survives_loss(self):
        self.assertTrue(evaluate_navigation(LocalizationSample(None,None,None,0,0.8,False),'hold')['decision']['accepted'])
    def test_invalid_confidence_rejected(self):
        with self.assertRaises(ValueError):
            estimate_confidence(LocalizationSample(float('nan'),None,None,1,1,True))
    def test_deterministic_campaign(self):
        self.assertEqual(run(500,7),run(500,7))
    def test_low_confidence_never_approves_return(self):
        m=run(1000,42)['metrics']
        self.assertGreater(m['low_confidence_return_proposals'],0)
        self.assertEqual(m['low_confidence_return_accepted'],0)

if __name__=='__main__':
    unittest.main()
