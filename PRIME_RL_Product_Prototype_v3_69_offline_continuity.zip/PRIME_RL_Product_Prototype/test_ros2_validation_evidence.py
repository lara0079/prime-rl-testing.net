import hashlib
import tempfile
import unittest
from pathlib import Path
from ros2_validation_evidence import build_manifest


class EvidenceManifestTests(unittest.TestCase):
    def test_records_missing_artifacts_without_claiming_validation(self):
        with tempfile.TemporaryDirectory() as folder:
            result = build_manifest(folder, readiness={'ros2_execution_ready': False}, timestamp='fixed')
            self.assertEqual(result['validation_status'], 'NOT_EXECUTED')
            self.assertFalse(result['artifacts']['package.xml']['present'])
            self.assertIsNone(result['artifacts']['package.xml']['sha256'])

    def test_hashes_source_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            Path(folder, 'package.xml').write_bytes(b'example')
            result = build_manifest(folder, readiness={'ros2_execution_ready': True}, timestamp='fixed')
            self.assertEqual(result['artifacts']['package.xml']['sha256'], hashlib.sha256(b'example').hexdigest())
            self.assertEqual(result['validation_status'], 'NOT_EXECUTED')

    def test_manifest_is_deterministic_for_fixed_inputs(self):
        with tempfile.TemporaryDirectory() as folder:
            kwargs = {'readiness': {'ros2_execution_ready': False}, 'timestamp': 'fixed'}
            self.assertEqual(build_manifest(folder, **kwargs), build_manifest(folder, **kwargs))


if __name__ == '__main__':
    unittest.main()
