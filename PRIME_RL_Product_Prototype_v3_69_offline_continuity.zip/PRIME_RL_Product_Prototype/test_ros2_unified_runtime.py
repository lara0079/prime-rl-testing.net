import json
import tempfile
import unittest
from pathlib import Path
from authority import AuthorityVerifier, sign
from ros2_unified_runtime import UnifiedAdvisoryRuntime

KEY = b'k' * 32


class UnifiedRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.auth = self.root / 'authority.sqlite'
        self.ledger = self.root / 'decisions.sqlite'

    def make(self, verifier=None):
        return UnifiedAdvisoryRuntime(self.auth, self.ledger, verifier=verifier)

    def token(self, nonce):
        return sign({'kid':'demo','iss':'lab','aud':'robot','nbf':0,'exp':100,
                     'nonce':nonce,'permissions':['inspect']}, KEY)

    def test_no_keys_defaults_to_denial(self):
        runtime = self.make()
        try:
            self.assertFalse(runtime.refresh_from_trusted_control(self.token('one'), now_seconds=5, connected=True))
            self.assertTrue(runtime.store.status()['revalidation_required'])
        finally:
            runtime.close()

    def test_trusted_refresh_is_durable_and_replay_protected(self):
        verifier = AuthorityVerifier({'demo': KEY}, 'lab', 'robot')
        try:
            runtime = self.make(verifier)
            try:
                self.assertTrue(runtime.refresh_from_trusted_control(self.token('one'), now_seconds=5, connected=True))
                self.assertTrue(runtime.store.verify_audit())
            finally:
                runtime.close()
            restarted = self.make(verifier)
            try:
                self.assertTrue(restarted.store.status()['revalidation_required'])
                self.assertFalse(restarted.refresh_from_trusted_control(self.token('one'), now_seconds=6, connected=True))
                self.assertTrue(restarted.refresh_from_trusted_control(self.token('two'), now_seconds=7, connected=True))
            finally:
                restarted.close()
        finally:
            verifier.close()

    def test_telemetry_cannot_supply_token(self):
        runtime = self.make()
        try:
            result = json.loads(runtime.evaluate(json.dumps({'token':self.token('x')}), 5))
            self.assertFalse(result['accepted'])
            self.assertEqual(result['reason'], 'invalid_telemetry')
        finally:
            runtime.close()

    def test_rejects_same_database_path(self):
        with self.assertRaisesRegex(ValueError, 'separate paths'):
            UnifiedAdvisoryRuntime(self.auth, self.auth)


if __name__ == '__main__':
    unittest.main()
