"""Explicit offline legacy-to-atomic ledger migration. Stop writers first.

Not a trust anchor or a concurrency-safe live migration. Requires an independent
backup location and rejects already migrated databases.
"""
import os
import sqlite3
from pathlib import Path
from ledger import Ledger, ZERO
from atomic_ledger import AtomicLedger
from migration_lock import migration_lock


def migrate_legacy_ledger(path, backup_path):
    source = Path(path)
    backup = Path(backup_path)
    if not source.is_file() or source.is_symlink():
        raise ValueError('regular non-symlink source required')
    if backup.exists() or backup.is_symlink() or source.resolve() == backup.resolve():
        raise ValueError('backup must be a new, separate path')
    if not backup.parent.is_dir():
        raise ValueError('backup directory must exist')
    with migration_lock(source):
        return _migrate_locked(source, backup)


def _migrate_locked(source, backup):
    legacy = Ledger(source)
    try:
        if not legacy.verify():
            raise ValueError('legacy ledger integrity check failed')
        if legacy.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ledger_head'").fetchone():
            raise ValueError('ledger already contains atomic head')
        row = legacy.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
        seq, digest = row if row else (0, ZERO)
        # SQLite's backup API captures a consistent snapshot, including WAL data.
        # Reserve the backup filename exclusively before using SQLite backup API.
        fd = os.open(str(backup), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        try:
            target = sqlite3.connect(backup)
            try:
                legacy.db.backup(target)
            finally:
                target.close()
            # Validate the backup before modifying the source. A backup is not
            # useful for recovery unless its chain and head match the source.
            saved = Ledger(backup)
            try:
                if not saved.verify():
                    raise ValueError('backup integrity check failed')
                backed_up_head = saved.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
            finally:
                saved.close()
            # Acquire SQLite's writer reservation; reject changes made by
            # uncooperative writers since the snapshot instead of silently
            # migrating a history the backup does not contain.
            legacy.db.execute('BEGIN IMMEDIATE')
            try:
                current_head = legacy.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone()
                if current_head != backed_up_head or not legacy.verify():
                    raise ValueError('source changed since backup snapshot')
                legacy.db.execute('CREATE TABLE ledger_head (id INTEGER PRIMARY KEY CHECK(id=1), seq INTEGER NOT NULL, event_hash TEXT NOT NULL)')
                legacy.db.execute('INSERT INTO ledger_head VALUES (1,?,?)', (seq, digest))
                legacy.db.commit()
            except Exception:
                legacy.db.rollback()
                raise
        except Exception:
            # Keep backup for recovery even if migration fails.
            raise
    finally:
        legacy.close()
    verified = AtomicLedger(source)
    try:
        if not verified.verify():
            raise ValueError('post-migration verification failed')
    finally:
        verified.close()
    return {'events': seq, 'backup': str(backup), 'status': 'verified'}
