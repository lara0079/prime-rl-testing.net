"""Synthetic trained-policy integration. No network, ROS, or actuators."""
import argparse
import json
import random
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from session import GovernedSession
from learning_lab import TabularAgent, ToyObservation, toy_reward

KEY = b'prime-rl-training-lab-key-not-for-production'
ACTIONS = ('inspect', 'hold', 'return', 'signal')

def train(seed=42, steps=8000):
    if steps < 1:
        raise ValueError('training steps must be positive')
    agent = TabularAgent(seed=seed, epsilon=0.25)
    from core import Runtime
    gate = Runtime()
    rng = random.Random(seed + 200)
    for _ in range(steps):
        obs = ToyObservation(rng.random() > 0.4, rng.random() > 0.2, rng.random() > 0.15)
        proposal = agent.propose(obs)
        accepted = gate.evaluate(obs.snapshot(), proposal.action)['accepted']
        agent.learn(obs, proposal.action, toy_reward(obs, proposal.action, accepted))
    agent.epsilon = 0.0
    return agent

def evaluate(seed=42, train_steps=8000, eval_steps=3000):
    if eval_steps < 1:
        raise ValueError('evaluation steps must be positive')
    agent = train(seed, train_steps)
    rng = random.Random(seed + 10000)
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        verifier = AuthorityVerifier({'lab':KEY}, 'lab-issuer', 'lab-node', replay_db=str(root/'replay.sqlite'))
        ledger = Ledger(root/'ledger.sqlite')
        session = GovernedSession(verifier, ledger)
        counts = {'proposals':0,'accepted':0,'blocked':0,'offline_steps':0,
                  'offline_mission_proposals':0,'offline_mission_accepted':0,
                  'refresh_success':0,'reconnects':0,'recovery_accepted_offline':0}
        previous_connected = None
        for step in range(eval_steps):
            connected = step % 41 < 25
            if previous_connected is False and connected:
                counts['reconnects'] += 1
            previous_connected = connected
            now = 10000.0 + step
            # Explicit revalidation when link comes back; no stale token reuse.
            if connected and step % 41 == 0:
                token = sign({'kid':'lab','iss':'lab-issuer','aud':'lab-node',
                              'nbf':now-1,'exp':now+26,'nonce':f'{seed}-{step}',
                              'permissions':['inspect']}, KEY)
                if session.refresh(token, now, connected):
                    counts['refresh_success'] += 1
            sensor_good = rng.random() > 0.18
            energy_good = rng.random() > 0.15
            obs = ToyObservation(connected, sensor_good, energy_good)
            action = agent.propose(obs).action
            snapshot = Snapshot(connected, 0.95 if connected else 0.0,
                                0.9 if sensor_good else 0.15,
                                0.9 if energy_good else 0.1, True)
            result = session.decide(snapshot, action, now=now)
            counts['proposals'] += 1
            counts['accepted' if result['accepted'] else 'blocked'] += 1
            if not connected:
                counts['offline_steps'] += 1
                if action == 'inspect':
                    counts['offline_mission_proposals'] += 1
                    if result['accepted']:
                        counts['offline_mission_accepted'] += 1
                elif result['accepted']:
                    counts['recovery_accepted_offline'] += 1
        counts['ledger_integrity'] = ledger.verify()
        counts['ledger_events'] = len(ledger.events())
        ledger.close()
        verifier.close()
    return {'version':'v1.0','type':'trained_toy_policy_integrated_synthetic_lab',
            'seed':seed,'training_steps':train_steps,'evaluation_steps':eval_steps,
            'metrics':counts,'limitations':'Tabular toy policy; simulated environment and clock; no physical actuation, trusted time, or safety certification.'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--train-steps', type=int, default=8000)
    parser.add_argument('--eval-steps', type=int, default=3000)
    parser.add_argument('--output', default='trained_integrated_report.json')
    args = parser.parse_args()
    result = evaluate(args.seed,args.train_steps,args.eval_steps)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
