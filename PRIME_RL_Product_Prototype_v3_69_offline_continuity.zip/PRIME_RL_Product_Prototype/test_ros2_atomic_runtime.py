"""Optional SQLite-atomic evidence store in the advisory runtime."""
import sqlite3
import tempfile
import unittest
from pathlib import Path
from ros2_runtime_gate import AdvisoryRuntime
from ledger import Ledger

class AtomicRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'runtime.db'

    def test_atomic_mode_starts_and_restarts(self):
        a = AdvisoryRuntime(self.path, atomic_ledger=True)
        a.ledger.append({'event':'one'})
        a.close()
        b = AdvisoryRuntime(self.path, atomic_ledger=True)
        self.assertTrue(b.ledger.verify())
        b.close()

    def test_atomic_mode_rejects_tail_deletion(self):
        a = AdvisoryRuntime(self.path, atomic_ledger=True)
        a.ledger.append({'event':'one'})
        with a.ledger.db:
            a.ledger.db.execute('DELETE FROM events WHERE seq=1')
        a.close()
        with self.assertRaisesRegex(ValueError, 'integrity'):
            AdvisoryRuntime(self.path, atomic_ledger=True)

    def test_legacy_history_cannot_silently_migrate(self):
        a = Ledger(self.path)
        a.append({'event':'legacy'})
        a.close()
        with self.assertRaisesRegex(ValueError, 'migration'):
            AdvisoryRuntime(self.path, atomic_ledger=True)

    def test_injected_failure_keeps_atomic_head_consistent(self):
        a = AdvisoryRuntime(self.path, atomic_ledger=True)
        with self.assertRaises(RuntimeError):
            a.ledger.append({'event':'failed'}, inject_failure=True)
        self.assertTrue(a.ledger.verify())
        self.assertEqual(a.ledger.events(), [])
        a.close()
