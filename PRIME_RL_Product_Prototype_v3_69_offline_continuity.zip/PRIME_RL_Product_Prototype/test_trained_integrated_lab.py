import unittest
from trained_integrated_lab import evaluate, train
from learning_lab import ToyObservation

class TrainedIntegrationTests(unittest.TestCase):
    def test_training_reproducible(self):
        a = train(12, 250)
        b = train(12, 250)
        self.assertEqual(a.q, b.q)
    def test_evaluation_reproducible(self):
        self.assertEqual(evaluate(7, 200, 180), evaluate(7, 200, 180))
    def test_no_offline_mission_acceptance(self):
        r = evaluate(9, 350, 500)
        self.assertEqual(r['metrics']['offline_mission_accepted'], 0)
    def test_ledger_valid(self):
        r = evaluate(3, 200, 200)
        self.assertTrue(r['metrics']['ledger_integrity'])
        self.assertGreaterEqual(r['metrics']['ledger_events'], r['metrics']['proposals'])
    def test_reconnect_and_refresh(self):
        r = evaluate(4, 200, 250)
        self.assertGreater(r['metrics']['reconnects'], 0)
        self.assertGreater(r['metrics']['refresh_success'], 0)
    def test_bad_input(self):
        with self.assertRaises(ValueError): train(1, 0)
        with self.assertRaises(ValueError): evaluate(1, 1, 0)

if __name__ == '__main__': unittest.main()
