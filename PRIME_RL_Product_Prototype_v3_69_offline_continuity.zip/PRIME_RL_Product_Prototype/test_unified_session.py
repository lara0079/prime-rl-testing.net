import tempfile
import unittest
from pathlib import Path
from authority import AuthorityVerifier, sign
from ledger import Ledger
from unified_authority_store import UnifiedAuthorityStore
from unified_session import UnifiedGovernedSession

KEY = b'k'*32

class UnifiedSessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.store = UnifiedAuthorityStore(self.root/'unified.sqlite')
        self.ledger = Ledger(self.root/'decisions.sqlite')
        self.verifier = AuthorityVerifier({'demo': KEY}, 'lab', 'robot')
        self.session = UnifiedGovernedSession(self.verifier,self.ledger,self.store)

    def tearDown(self):
        self.store.close(); self.ledger.close(); self.verifier.close(); self.tmp.cleanup()

    def token(self, nonce):
        return sign({'kid':'demo','iss':'lab','aud':'robot','nbf':0,'exp':100,'nonce':nonce,'permissions':['inspect']},KEY)

    def test_refresh_atomic_and_replay_rejected(self):
        self.assertTrue(self.session.refresh(self.token('a'), 5, True))
        self.assertFalse(self.store.status()['revalidation_required'])
        self.assertTrue(self.store.verify_audit())
        self.assertFalse(self.session.refresh(self.token('a'), 6, True))
        self.assertTrue(self.store.status()['revalidation_required'])
        self.assertTrue(self.session.revalidation_required)

    def test_offline_revokes_durable_authority(self):
        self.assertTrue(self.session.refresh(self.token('a'), 5, True))
        self.assertFalse(self.session.refresh(self.token('b'), 6, False))
        self.assertTrue(self.store.status()['revalidation_required'])
        self.assertEqual(self.store.status()['audit_count'],1)

    def test_restart_requires_new_token(self):
        self.assertTrue(self.session.refresh(self.token('a'), 5, True))
        self.store.close()
        self.store = UnifiedAuthorityStore(self.root/'unified.sqlite')
        self.session = UnifiedGovernedSession(self.verifier,self.ledger,self.store)
        self.assertTrue(self.store.status()['revalidation_required'])
        self.assertFalse(self.session.refresh(self.token('a'), 6, True))
        self.assertTrue(self.session.refresh(self.token('b'), 7, True))

    def test_separate_replay_db_rejected(self):
        verifier = AuthorityVerifier({'demo':KEY},'lab','robot',str(self.root/'replay.sqlite'))
        try:
            with self.assertRaises(ValueError):
                UnifiedGovernedSession(verifier,self.ledger,self.store)
        finally:
            verifier.close()

if __name__ == '__main__': unittest.main()
