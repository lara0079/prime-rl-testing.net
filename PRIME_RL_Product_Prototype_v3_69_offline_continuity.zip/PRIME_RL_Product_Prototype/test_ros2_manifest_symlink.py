"""Reject symlinked source artifacts, including links that stay in the tree."""
import tempfile
import unittest
from pathlib import Path
from ros2_validation_evidence import build_manifest
from ros2_release_verify import REQUIRED, verify_release_manifest


class ManifestSymlinkTests(unittest.TestCase):
    def setup_tree(self, root):
        for relative in REQUIRED:
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(relative, encoding='utf-8')

    def test_internal_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.setup_tree(root)
            (root / 'package.xml').unlink()
            (root / 'package.xml').symlink_to('setup.py')
            with self.assertRaisesRegex(ValueError, 'symlinked evidence source'):
                build_manifest(root, readiness={'ros2_execution_ready': False})

    def test_symlinked_parent_directory_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.setup_tree(root)
            (root / 'launch' / 'scenario.launch.py').rename(root / 'scenario.launch.py')
            (root / 'launch' / 'advisory.launch.py').rename(root / 'advisory.launch.py')
            (root / 'launch').rmdir()
            (root / 'launch').symlink_to('.', target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'symlinked evidence source'):
                build_manifest(root, readiness={'ros2_execution_ready': False})

    def test_regular_files_still_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.setup_tree(root)
            manifest = build_manifest(root, readiness={'ros2_execution_ready': False})
            self.assertTrue(verify_release_manifest(manifest, root)['verified'])
