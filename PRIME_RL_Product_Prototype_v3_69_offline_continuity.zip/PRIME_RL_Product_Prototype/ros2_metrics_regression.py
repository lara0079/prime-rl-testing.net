"""Compare two independently verified offline evidence sets; no live DDS attestation."""
import argparse
import json
import math
from pathlib import Path
from ros2_metrics_summary import summarize
from ros2_evidence_audit import audit_directory


def compare(baseline_directory, candidate_directory, *, max_p95_increase_pct, min_samples):
    if (isinstance(max_p95_increase_pct, bool) or
            not isinstance(max_p95_increase_pct, (int, float)) or
            not math.isfinite(max_p95_increase_pct) or max_p95_increase_pct < 0):
        raise ValueError('max_p95_increase_pct must be a finite nonnegative number')
    if isinstance(min_samples, bool) or not isinstance(min_samples, int) or min_samples < 1:
        raise ValueError('min_samples must be a positive integer')
    baseline_path = Path(baseline_directory).resolve()
    candidate_path = Path(candidate_directory).resolve()
    if baseline_path == candidate_path:
        raise ValueError('baseline and candidate must be different evidence directories')
    baseline = summarize(baseline_directory)
    candidate = summarize(candidate_directory)
    result = {'status': 'fail', 'baseline': baseline, 'candidate': candidate,
              'max_p95_increase_pct': max_p95_increase_pct,
              'min_samples': min_samples, 'live_dds_attested': False}
    if baseline['status'] != 'pass' or candidate['status'] != 'pass':
        result['reason'] = 'invalid_evidence'
        return result
    # Comparing reused runs can falsely suggest independent confirmation.
    def run_ids(directory):
        return {
            json.loads((Path(directory) / (item['stem'] + '.manifest.json'))
                       .read_text(encoding='utf-8'))['run_id']
            for item in audit_directory(directory)['pairs']
        }
    if run_ids(baseline_directory) & run_ids(candidate_directory):
        result['reason'] = 'overlapping_run_ids'
        return result
    if baseline['sample_count'] < min_samples or candidate['sample_count'] < min_samples:
        result['reason'] = 'insufficient_samples'
        return result
    old = baseline['latency_ms']['p95']
    new = candidate['latency_ms']['p95']
    # Verified timing samples are nonnegative; zero baseline requires zero candidate.
    if old == 0:
        result['p95_increase_pct'] = 0.0 if new == 0 else None
        passed = new == 0
    else:
        result['p95_increase_pct'] = (new / old - 1) * 100
        passed = new <= old * (1 + max_p95_increase_pct / 100)
    result['status'] = 'pass' if passed else 'fail'
    result['reason'] = 'within_tolerance' if passed else 'p95_regression'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--max-p95-increase-pct', type=float, required=True)
    parser.add_argument('--min-samples', type=int, required=True)
    args = parser.parse_args()
    try:
        result = compare(args.baseline, args.candidate,
                         max_p95_increase_pct=args.max_p95_increase_pct,
                         min_samples=args.min_samples)
    except (ValueError, OSError) as exc:
        result = {'status': 'fail', 'reason': 'invalid_input', 'detail': str(exc),
                  'live_dds_attested': False}
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    if result['status'] != 'pass':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
