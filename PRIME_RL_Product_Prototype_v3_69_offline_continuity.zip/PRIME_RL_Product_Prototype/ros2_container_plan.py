"""Generate a deterministic, offline ROS 2 container handoff manifest.

Does not start Docker, access the network, or execute robotics software.
"""
import argparse
import hashlib
import json
from pathlib import Path

FILES = ('Dockerfile.ros2', '.dockerignore', 'run_ros2_container_smoke.sh',
         'package.xml', 'setup.py', 'ros2_advisory_node.py',
         'ros2_live_smoke.py', 'ros2_integration_preflight.py')


def plan(root=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parent
    records = []
    problems = []
    for name in FILES:
        path = root / name
        if path.is_symlink() or not path.is_file():
            problems.append('missing or symlinked: ' + name)
            continue
        data = path.read_bytes()
        records.append({'path': name, 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
    return {'schema_version': 1, 'status': 'ready_for_external_runtime' if not problems else 'blocked',
            'files': records, 'problems': problems,
            'docker_executed': False, 'ros2_executed': False,
            'gazebo_executed': False, 'network_accessed': False,
            'requires_explicit_runtime_opt_in': True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path)
    args = parser.parse_args(argv)
    result = plan(args.root)
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0 if result['status'] == 'ready_for_external_runtime' else 2


if __name__ == '__main__':
    raise SystemExit(main())
