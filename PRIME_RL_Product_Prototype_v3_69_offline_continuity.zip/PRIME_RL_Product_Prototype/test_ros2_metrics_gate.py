import tempfile
import unittest
from pathlib import Path

from ros2_metrics_gate import assess
from ros2_repeatability import execute_repetitions, write_evidence_pair


class MetricsGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def pair(self, samples):
        report = execute_repetitions(1, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': samples}})
        write_evidence_pair(report, self.root / 'one.evidence.json',
                            self.root / 'one.manifest.json')

    def test_passing_gate_with_explicit_limits(self):
        self.pair([1, 2, 3, 4])
        result = assess(self.root, max_p95_ms=4, min_samples=4, max_mean_ms=3)
        self.assertEqual(result['status'], 'pass')
        self.assertFalse(result['live_dds_attested'])

    def test_insufficient_samples_fails(self):
        self.pair([1, 2])
        self.assertIn('insufficient_samples', assess(self.root, max_p95_ms=10,
                                                      min_samples=3)['failures'])

    def test_latency_failures_are_independent(self):
        self.pair([1, 10])
        result = assess(self.root, max_p95_ms=5, min_samples=2, max_mean_ms=3)
        self.assertEqual(set(result['failures']), {'p95_exceeds_limit', 'mean_exceeds_limit'})

    def test_invalid_evidence_fails_closed(self):
        result = assess(self.root, max_p95_ms=5, min_samples=1)
        self.assertEqual(result['reason'], 'invalid_evidence')

    def test_invalid_thresholds_rejected(self):
        for value in (float('nan'), float('inf'), -1, 0, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                assess(self.root, max_p95_ms=value, min_samples=1)
        for value in (0, -1, True, 1.5):
            with self.subTest(samples=value), self.assertRaises(ValueError):
                assess(self.root, max_p95_ms=5, min_samples=value)
