# PRIME-RL ROS 2 validation runbook — v3.9

**Status:** unexecuted integration procedure. The current system is advisory-only, with no actuator command publisher. It has not been validated in ROS 2 or Gazebo.

## Prerequisites

Use an isolated supported Linux host or container with a mutually compatible ROS 2 distribution, Python version, `rclpy`, `std_msgs`, `colcon`, `launch`, `launch_ros`, and a Gazebo installation compatible with the chosen ROS 2 distribution. Do not run on a physical robot. Keep all actuator interfaces disconnected.

## Build and launch (on a prepared host)

1. Create a ROS 2 workspace, place the `PRIME_RL_Product_Prototype` source folder under `src/prime_rl_advisory`, and source the ROS 2 distribution's setup script.
2. Run `python3 src/prime_rl_advisory/ros2_readiness.py`. It should return exit code 0; investigate any missing prerequisite.
3. Run `colcon build --packages-select prime_rl_advisory` and source `install/setup.bash`.
4. Run `ros2 launch prime_rl_advisory scenario.launch.py` in a sandboxed session. Capture stdout, ROS topic list, message rates, error counts and timing data.
5. Independently confirm no actuator publishers or controller subscriptions have been added; keep the simulation advisory-only.
6. Only after a successful ROS 2 middleware smoke test, connect a separately controlled Gazebo telemetry bridge. Gazebo integration is **not included** in this version.

## Acceptance criteria (not yet met)

- ROS 2 package builds on the target distribution; launch starts and stops cleanly.
- Valid and invalid telemetry yield expected advisory results; missing, stale and reordered messages are tested.
- Offline and expired-authority mission actions are denied, and reconnection requires revalidation.
- Logs are complete and restart/rollback tests are repeatable.
- No actuator control exists; no physical robot is connected.

Record the exact ROS 2/Gazebo versions, environment, command outputs, measured latency distribution, message loss and test artifacts. Passing Python unit tests alone does not satisfy these criteria.

## Reproducible preflight evidence (v3.10)

Before any ROS 2 execution, run `python3 ros2_validation_evidence.py --output ros2_preflight_evidence.json` from the source folder. This generates a read-only manifest of environment readiness and SHA-256 hashes of the relevant launch/package files. Exit code 2 means the host is not ready; exit code 0 only means the listed prerequisites were detected, **not** that ROS 2 or Gazebo worked. Archive the evidence JSON with the separate, actual integration-test logs once those tests have been performed. Do not use this evidence report as safety certification.

## v3.28 live DDS smoke test (requires installed ROS 2; not executed here)

In an isolated ROS 2 environment, launch the advisory node in one terminal,
then from a second sourced terminal run:

```bash
python3 ros2_live_smoke.py --timeout 15
```

The smoke client waits for DDS discovery, publishes a deliberately malformed
telemetry JSON on `/prime_rl/telemetry_json`, and requires a rejected,
`advisory_only=true` response on `/prime_rl/advisory_json`. It exits nonzero
if the subscriber or matching response is absent. No actuator topic is used.
This is a minimal end-to-end middleware check, **not** a latency benchmark,
Gazebo scenario, proof of safety, or production authorization assessment.
Capture the JSON result and full ROS 2 logs separately as evidence.
