"""Product-boundary regression for signed, bounded offline continuation (simulation)."""
import copy
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from authority import sign
from offline_mission_continuity import LocalObservation, OfflineMissionContinuity, MissionRejected

KEY = b'v369-test-unique-local-hmac-key-nonproduction!'


def permit(**overrides):
    base = dict(schema='prime-rl-offline-plan-v1', kid='k1', iss='local-issuer', aud='robot-runtime',
                nbf=99, exp=140, nonce='n-01', permissions=['offline:continue'],
                mission_id='demo-1', robot_id='test-robot',
                plan=[{'step_id': 's1', 'target_x': .3}, {'step_id':'s2','target_x':.6},
                      {'step_id':'s3','target_x':.9}],
                offline_limit=10, total_limit=1.2, step_limit=.4,
                min_confidence=.7, min_battery=.3, lower_x=-1, upper_x=2)
    base.update(overrides)
    return sign(base, KEY)


def obs(x=0., now=100., conf=.95, battery=.8, integrity=True):
    return LocalObservation(now, x, conf, battery, integrity)


class MissionContinuityTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.file = Path(self.tmp.name) / 'mission.sqlite'
        self.gate = self.open()

    def tearDown(self):
        self.gate.close()
        self.tmp.cleanup()

    def open(self):
        return OfflineMissionContinuity(self.file, keys={'k1':KEY}, issuer='local-issuer',
                                        audience='robot-runtime', robot_id='test-robot')

    def stage(self, **kw):
        return self.gate.stage(permit(**kw), now=100, connected=True, observation=obs())

    def offline(self):
        self.stage()
        self.assertTrue(self.gate.disconnect('demo-1', now=100.1, connected=False, observation=obs(now=100.1))['accepted'])

    def test_valid_offline_three_segments_with_actual_confirmations(self):
        self.offline()
        x = 0.
        for i, next_x in enumerate((.3,.6,.9)):
            issued = self.gate.next_intent('demo-1', now=100.2+i, connected=False, observation=obs(x,100.2+i))
            self.assertTrue(issued['accepted'], issued)
            self.assertEqual(issued['target_x'], next_x)
            self.assertTrue(issued['advisory_only'])
            self.assertEqual(issued['action'], 'bounded_segment')
            self.assertTrue(issued['requires_observed_confirmation'])
            self.assertNotIn('cmd_vel', issued)
            result = self.gate.confirm('demo-1', intent_id=issued['intent_id'], now=100.4+i,
                                       connected=False, observation=obs(next_x,100.4+i))
            self.assertTrue(result['accepted'], result)
            x = next_x
        self.assertEqual(self.gate.status('demo-1')['status'], 'completed')
        self.assertEqual(self.gate.status('demo-1')['confirmed_steps'], 3)
        self.assertFalse(self.gate.next_intent('demo-1', now=104, connected=False, observation=obs(.9,104))['accepted'])
        self.assertTrue(self.gate.verify_audit())

    def test_requires_online_staging(self):
        with self.assertRaisesRegex(MissionRejected,'online'):
            self.gate.stage(permit(), now=100, connected=False, observation=obs())

    def test_wrong_key(self):
        with self.assertRaises(MissionRejected):
            self.gate.stage(sign(json.loads(__import__('base64').urlsafe_b64decode(permit().split('.')[0]+'==')), b'different-key-different-key-32bytes!!'), now=100, connected=True, observation=obs())

    def test_wrong_robot(self):
        with self.assertRaisesRegex(MissionRejected,'wrong_robot'):
            self.stage(robot_id='a-different-robot')

    def test_missing_permission(self):
        with self.assertRaises(MissionRejected): self.stage(permissions=['hold'])

    def test_token_expired(self):
        with self.assertRaises(MissionRejected): self.stage(exp=100)

    def test_nonce_reuse_even_if_mission_completed(self):
        self.offline()
        self.gate.reconnect('demo-1', now=101)
        with self.assertRaisesRegex(MissionRejected,'replayed'):
            self.stage()

    def test_duplicate_mission_blocked_while_active(self):
        self.stage()
        with self.assertRaisesRegex(MissionRejected,'another_mission'):
            self.stage(nonce='n-02', mission_id='demo-2')

    def test_no_offline_without_loss(self):
        self.stage()
        with self.assertRaises(MissionRejected): self.gate.disconnect('demo-1',now=100.1,connected=True,observation=obs(now=100.1))

    def test_unauthorized_target_rejected_at_staging(self):
        with self.assertRaises(MissionRejected): self.stage(plan=[{'step_id':'s1','target_x':30}])

    def test_step_distance_rejected_at_staging(self):
        with self.assertRaises(MissionRejected): self.stage(plan=[{'step_id':'s1','target_x':1.5}])

    def test_total_distance_rejected_at_staging(self):
        with self.assertRaises(MissionRejected): self.stage(total_limit=.5)

    def test_duplicate_step_id_rejected(self):
        with self.assertRaises(MissionRejected): self.stage(plan=[{'step_id':'a','target_x':.3},{'step_id':'a','target_x':.6}])

    def test_no_duplicate_pending_issuance(self):
        self.offline()
        first = self.gate.next_intent('demo-1', now=100.2,connected=False,observation=obs(now=100.2))
        second = self.gate.next_intent('demo-1', now=100.3,connected=False,observation=obs(now=100.3))
        self.assertTrue(first['accepted'])
        self.assertFalse(second['accepted'])
        self.assertEqual(second['action'], 'hold')

    def test_unconfirmed_step_halts(self):
        self.offline()
        issued = self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        result = self.gate.confirm('demo-1',intent_id=issued['intent_id'],now=100.3,connected=False,observation=obs(.1,100.3))
        self.assertFalse(result['accepted']);self.assertEqual(self.gate.status('demo-1')['status'],'halted')

    def test_confirmation_replay_blocked(self):
        self.offline()
        intent=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        self.gate.confirm('demo-1',intent_id=intent['intent_id'],now=100.3,connected=False,observation=obs(.3,100.3))
        repeated=self.gate.confirm('demo-1',intent_id=intent['intent_id'],now=100.5,connected=False,observation=obs(.3,100.5))
        self.assertFalse(repeated['accepted']);self.assertEqual(repeated['reason'],'unknown_or_replayed_intent')

    def test_stale_sensor_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=103,connected=False,observation=obs(now=100))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'stale_local_telemetry')

    def test_sensor_degradation_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2,conf=.3))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'insufficient_local_safety_margin')

    def test_low_energy_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2,battery=.2))
        self.assertFalse(r['accepted'])

    def test_loss_of_integrity_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2,integrity=False))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'integrity_failure')

    def test_clock_rollback_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=100,connected=False,observation=obs(now=100))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'clock_rollback')

    def test_offline_budget_elapsed(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=111,connected=False,observation=obs(now=111))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'offline_budget_exhausted')

    def test_permit_expiration(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=140,connected=False,observation=obs(now=140))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'permit_expired')

    def test_unexpected_position_halts(self):
        self.offline()
        r=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(.2,100.2))
        self.assertFalse(r['accepted']);self.assertEqual(r['reason'],'unexpected_position')

    def test_reconnect_revokes_and_stops(self):
        self.offline()
        issued=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        r=self.gate.confirm('demo-1',intent_id=issued['intent_id'],now=100.3,connected=True,observation=obs(.3,100.3))
        self.assertFalse(r['accepted']);self.assertEqual(self.gate.status('demo-1')['status'],'needs_revalidation')

    def test_reconnect_explicit_requires_new_permit(self):
        self.offline()
        self.gate.reconnect('demo-1',now=100.2)
        r=self.gate.next_intent('demo-1',now=100.3,connected=False,observation=obs(now=100.3))
        self.assertFalse(r['accepted'])
        self.assertTrue(self.gate.stage(permit(nonce='n-02',mission_id='demo-2'),now=101,connected=True,observation=obs(now=101))['accepted'])

    def test_restart_fails_closed_without_resending(self):
        self.offline()
        issued=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        self.gate.close()
        self.gate=self.open()
        self.assertEqual(self.gate.status('demo-1')['status'],'needs_revalidation')
        after=self.gate.next_intent('demo-1',now=100.3,connected=False,observation=obs(now=100.3))
        self.assertFalse(after['accepted'])
        self.assertTrue(self.gate.verify_audit())

    def test_audit_tampering_detected(self):
        self.offline()
        self.assertTrue(self.gate.verify_audit())
        self.gate.db.execute("UPDATE audit SET event='{}' WHERE seq=1")
        self.assertFalse(self.gate.verify_audit())

    def test_staging_missing_observation(self):
        with self.assertRaises(MissionRejected):
            self.gate.stage(permit(), now=100, connected=True, observation=None)

    def test_tampered_audit_blocks_new_intent(self):
        self.offline()
        self.gate.db.execute("UPDATE audit SET event='{}' WHERE seq=1")
        with self.assertRaisesRegex(MissionRejected, 'audit_integrity_failure'):
            self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))

    def test_atomic_stage_rollback_on_audit_failure(self):
        original = self.gate._audit
        self.gate._audit = lambda *a: (_ for _ in ()).throw(OSError('injected audit I/O failure'))
        try:
            with self.assertRaises(OSError): self.stage()
        finally:
            self.gate._audit = original
        self.assertEqual(self.gate.db.execute('SELECT COUNT(*) FROM permits').fetchone()[0], 0)
        self.assertTrue(self.gate.verify_audit())

    def test_atomic_intent_rollback_on_audit_failure(self):
        self.offline()
        original = self.gate._audit
        self.gate._audit = lambda *a: (_ for _ in ()).throw(OSError('injected audit I/O failure'))
        try:
            with self.assertRaises(OSError):
                self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        finally:
            self.gate._audit = original
        self.assertEqual(self.gate.status('demo-1')['status'], 'offline')
        self.assertIsNone(self.gate.status('demo-1')['pending_id'])
        self.assertTrue(self.gate.verify_audit())

    def test_expiration_during_pending_step(self):
        self.offline()
        issued=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        result=self.gate.confirm('demo-1',intent_id=issued['intent_id'],now=140,
                                 connected=False,observation=obs(.3,140))
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'permit_expired')

    def test_no_general_actuator_authority(self):
        self.offline()
        issued=self.gate.next_intent('demo-1',now=100.2,connected=False,observation=obs(now=100.2))
        self.assertTrue(issued['advisory_only'])
        self.assertEqual(set(issued), {'accepted','action','intent_id','target_x','advisory_only','requires_observed_confirmation'})


if __name__ == '__main__':
    unittest.main()
