"""Process-local request-id replay regression checks (no ROS installation needed)."""
import json
import unittest
import uuid
from collections import OrderedDict
from ros2_advisory_node import evaluate_correlated

class StubRuntime:
    def __init__(self): self.calls = 0
    def evaluate(self, payload, *, now_seconds):
        self.calls += 1
        return json.dumps({"accepted": False, "advisory_only": True, "reason": "invalid_telemetry"})

class TestReplay(unittest.TestCase):
    def test_duplicate_is_rejected_without_second_evaluation(self):
        runtime, cache = StubRuntime(), OrderedDict()
        ident = str(uuid.uuid4())
        payload = json.dumps({"request_id": ident, "telemetry": "invalid"})
        first = json.loads(evaluate_correlated(runtime, payload, now_seconds=1, replay_cache=cache))
        second = json.loads(evaluate_correlated(runtime, payload, now_seconds=2, replay_cache=cache))
        self.assertEqual(first["request_id"], ident)
        self.assertEqual(second["reason"], "duplicate_request_id")
        self.assertEqual(runtime.calls, 1)

    def test_distinct_ids_are_accepted(self):
        runtime, cache = StubRuntime(), OrderedDict()
        for _ in range(2):
            payload = json.dumps({"request_id": str(uuid.uuid4()), "telemetry": "invalid"})
            evaluate_correlated(runtime, payload, now_seconds=1, replay_cache=cache)
        self.assertEqual(runtime.calls, 2)

    def test_cache_is_bounded(self):
        runtime, cache = StubRuntime(), OrderedDict()
        for _ in range(4098):
            payload = json.dumps({"request_id": str(uuid.uuid4()), "telemetry": "invalid"})
            evaluate_correlated(runtime, payload, now_seconds=1, replay_cache=cache)
        self.assertEqual(len(cache), 4096)
