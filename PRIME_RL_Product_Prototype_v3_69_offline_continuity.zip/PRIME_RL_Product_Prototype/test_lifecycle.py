import os
import tempfile
import unittest
from authority import AuthorityVerifier
from core import Snapshot
from ledger import Ledger
from lifecycle import LifecycleStore
from policy import FixedPolicy, GovernedPolicy
from session import GovernedSession
from test_authority import KEY, token, snap

class LifecycleTests(unittest.TestCase):
    def test_restart_requires_new_authority(self):
        with tempfile.TemporaryDirectory() as d:
            path=os.path.join(d,'lifecycle.sqlite')
            l=Ledger(os.path.join(d,'events.sqlite'))
            v=AuthorityVerifier({'demo':KEY},'lab','sim',replay_db=os.path.join(d,'replay.sqlite'))
            store=LifecycleStore(path)
            first_epoch=store.epoch()
            s=GovernedSession(v,l,store)
            self.assertTrue(s.refresh(token('first'),150,True))
            self.assertTrue(s.decide(snap(),'inspect',now=151)['accepted'])
            store.close()
            store=LifecycleStore(path)
            self.assertEqual(store.epoch(),first_epoch+1)
            self.assertTrue(store.required())
            s=GovernedSession(v,l,store)
            self.assertFalse(s.decide(snap(),'inspect',now=152)['accepted'])
            self.assertTrue(s.refresh(token('second'),152,True))
            self.assertTrue(s.decide(snap(),'inspect',now=153)['accepted'])
            self.assertTrue(l.verify())
            store.close();v.close();l.close()

    def test_policy_cannot_bypass_gate(self):
        with tempfile.TemporaryDirectory() as d:
            l=Ledger(os.path.join(d,'events.sqlite'))
            v=AuthorityVerifier({'demo':KEY},'lab','sim')
            s=GovernedSession(v,l)
            agent=GovernedPolicy(s,FixedPolicy('inspect'))
            self.assertFalse(agent.evaluate(snap(),150)['accepted'])
            self.assertTrue(s.refresh(token('policy'),150,True))
            self.assertTrue(agent.evaluate(snap(),151)['accepted'])
            self.assertFalse(agent.evaluate(Snapshot(False,0,0.9,0.9,True),152)['accepted'])
            l.close()

    def test_invalid_policy_result_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            class BadPolicy:
                def propose(self, obs): return 'inspect'
            l=Ledger(os.path.join(d,'events.sqlite'))
            agent=GovernedPolicy(GovernedSession(AuthorityVerifier({'demo':KEY},'lab','sim'),l),BadPolicy())
            with self.assertRaises(TypeError): agent.evaluate(snap(),150)
            l.close()

if __name__=='__main__': unittest.main()
