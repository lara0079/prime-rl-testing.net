"""Restart and audit-failure regression tests; simulation-only."""
import os
import tempfile
import unittest
from authority import AuthorityVerifier
from ledger import Ledger
from lifecycle import LifecycleStore
from session import GovernedSession
from test_authority import KEY, token, snap

class FailingLedger:
    def append(self, event):
        raise OSError('simulated audit write failure')

class RestartRevalidationTests(unittest.TestCase):
    def test_previous_token_rejected_after_restart(self):
        with tempfile.TemporaryDirectory() as d:
            lifecycle_path=os.path.join(d,'lifecycle.db')
            replay_path=os.path.join(d,'replay.db')
            ledger=Ledger(os.path.join(d,'events.db'))
            verifier=AuthorityVerifier({'demo':KEY},'lab','sim',replay_db=replay_path)
            lifecycle=LifecycleStore(lifecycle_path)
            session=GovernedSession(verifier,ledger,lifecycle)
            signed=token('restart-replay')
            self.assertTrue(session.refresh(signed,150,True))
            self.assertTrue(session.decide(snap(),'inspect',now=151)['accepted'])
            lifecycle.close();verifier.close()
            lifecycle=LifecycleStore(lifecycle_path)
            verifier=AuthorityVerifier({'demo':KEY},'lab','sim',replay_db=replay_path)
            session=GovernedSession(verifier,ledger,lifecycle)
            self.assertFalse(session.decide(snap(),'inspect',now=152)['accepted'])
            self.assertFalse(session.refresh(signed,152,True))
            self.assertFalse(session.decide(snap(),'inspect',now=153)['accepted'])
            self.assertTrue(session.refresh(token('restart-fresh'),153,True))
            self.assertTrue(session.decide(snap(),'inspect',now=154)['accepted'])
            self.assertTrue(ledger.verify())
            lifecycle.close();verifier.close();ledger.close()

    def test_audit_failure_cannot_activate_authority(self):
        with tempfile.TemporaryDirectory() as d:
            lifecycle=LifecycleStore(os.path.join(d,'lifecycle.db'))
            verifier=AuthorityVerifier({'demo':KEY},'lab','sim')
            session=GovernedSession(verifier,FailingLedger(),lifecycle)
            with self.assertRaises(OSError):
                session.refresh(token('audit-failure'),150,True)
            self.assertTrue(lifecycle.required())
            self.assertTrue(session.revalidation_required)
            lifecycle.close()

if __name__ == '__main__': unittest.main()
