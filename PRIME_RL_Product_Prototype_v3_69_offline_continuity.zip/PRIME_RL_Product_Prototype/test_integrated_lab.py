import unittest
from integrated_lab import run

class IntegratedLabTests(unittest.TestCase):
    def test_reproducibility(self):
        self.assertEqual(run(12, 200), run(12, 200))
    def test_offline_inspection_never_accepted_in_synthetic_lab(self):
        self.assertEqual(run(42, 1000)['metrics']['offline_inspection_accepted'],0)
    def test_ledger_integrity(self):
        result=run(42, 250)
        self.assertTrue(result['metrics']['ledger_integrity'])
        self.assertGreater(result['metrics']['ledger_event_count'],result['metrics']['proposals'])
    def test_offline_recovery_remains_available(self):
        self.assertGreater(run(42, 500)['metrics']['offline_recovery_accepted'],0)
    def test_reconnect_requires_new_authority(self):
        result=run(42, 1000)['metrics']
        self.assertGreater(result['reconnects'],0)
        self.assertGreater(result['refresh_success'],1)
        self.assertEqual(result['refresh_failed'],0)
