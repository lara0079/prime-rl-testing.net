"""Dependency-injected ROS 2 API contract tests; no DDS/Gazebo execution."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from ros2_advisory_node import main, INPUT_TOPIC, OUTPUT_TOPIC


class FakeString:
    def __init__(self):
        self.data = ''


class FakeNode:
    instances = []
    def __init__(self, name):
        self.name = name
        self.published = []
        self.destroyed = False
        self.topics = []
        self.instances.append(self)
    def create_publisher(self, msg_type, topic, depth):
        self.topics.append(('publisher', topic, depth))
        node = self
        class Publisher:
            def publish(self, message):
                node.published.append(message.data)
        return Publisher()
    def create_subscription(self, msg_type, topic, callback, depth):
        self.topics.append(('subscriber', topic, depth))
        self.callback = callback
        return object()
    def get_clock(self):
        return types.SimpleNamespace(now=lambda: types.SimpleNamespace(nanoseconds=10_000_000_000))
    def destroy_node(self):
        self.destroyed = True


def fake_ros(spin):
    rclpy = types.ModuleType('rclpy')
    rclpy.init = lambda args=None: None
    rclpy.shutdown = lambda: None
    rclpy.spin = spin
    node = types.ModuleType('rclpy.node')
    node.Node = FakeNode
    std = types.ModuleType('std_msgs')
    stdmsg = types.ModuleType('std_msgs.msg')
    stdmsg.String = FakeString
    return {'rclpy': rclpy, 'rclpy.node': node, 'std_msgs': std, 'std_msgs.msg': stdmsg}


class ROSNodeLifecycleTests(unittest.TestCase):
    def setUp(self):
        FakeNode.instances.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = str(Path(self.tmp.name) / 'events.sqlite3')

    def run_node(self, spin):
        with patch.dict(sys.modules, fake_ros(spin)), patch.dict('os.environ', {'PRIME_RL_LEDGER_PATH': self.path}):
            main([])

    def test_subscription_and_advisory_publication(self):
        def spin(node):
            message = FakeString()
            message.data = json.dumps(dict(stamp_seconds=10., gnss_quality=.9,
                odometry_quality=.9, imu_quality=.9, map_freshness=1.,
                battery_fraction=.9, connected=True))
            node.callback(message)
            self.assertEqual(len(node.published), 1)
            result = json.loads(node.published[0])
            self.assertTrue(result['advisory_only'])
            self.assertFalse(result['accepted'])  # No mission authority installed.
        self.run_node(spin)
        node = FakeNode.instances[-1]
        self.assertEqual(node.topics, [('publisher', OUTPUT_TOPIC, 10), ('subscriber', INPUT_TOPIC, 10)])
        self.assertTrue(node.destroyed)

    def test_malformed_message_still_returns_rejection(self):
        def spin(node):
            message = FakeString()
            message.data = '{broken'
            node.callback(message)
            self.assertFalse(json.loads(node.published[0])['accepted'])
        self.run_node(spin)

    def test_subscription_failure_closes_runtime_and_shutdown(self):
        from ros2_runtime_gate import AdvisoryRuntime
        original = FakeNode.create_subscription
        shutdown_calls = []
        modules = fake_ros(lambda node: None)
        modules['rclpy'].shutdown = lambda: shutdown_calls.append(True)
        with patch.object(FakeNode, 'create_subscription', side_effect=RuntimeError('subscription failed')):
            with patch.dict(sys.modules, modules), patch.dict('os.environ', {'PRIME_RL_LEDGER_PATH': self.path}):
                with self.assertRaisesRegex(RuntimeError, 'subscription failed'):
                    main([])
        self.assertEqual(shutdown_calls, [True])
        self.assertTrue(FakeNode.instances[-1].destroyed)
        ledger = AdvisoryRuntime(self.path)
        ledger.close()

    def test_node_destroy_failure_still_shuts_down(self):
        shutdown_calls = []
        modules = fake_ros(lambda node: None)
        modules['rclpy'].shutdown = lambda: shutdown_calls.append(True)
        with patch.object(FakeNode, 'destroy_node', side_effect=RuntimeError('destroy failed')):
            with patch.dict(sys.modules, modules), patch.dict('os.environ', {'PRIME_RL_LEDGER_PATH': self.path}):
                with self.assertRaisesRegex(RuntimeError, 'destroy failed'):
                    main([])
        self.assertEqual(shutdown_calls, [True])

    def test_spin_exception_still_closes_runtime_and_node(self):
        def spin(node):
            raise RuntimeError('simulated middleware failure')
        with self.assertRaisesRegex(RuntimeError, 'simulated middleware failure'):
            self.run_node(spin)
        self.assertTrue(FakeNode.instances[-1].destroyed)
        # SQLite ledger can be reopened after node cleanup.
        from ledger import Ledger
        ledger = Ledger(self.path)
        try:
            self.assertTrue(ledger.verify())
        finally:
            ledger.close()


if __name__ == '__main__':
    unittest.main()
