"""Strict JSON intake for advisory-only telemetry. No actuation authority."""
import json
from ros2_advisory_node import evaluate_payload

MAX_BYTES = 4096

def _unique_pairs(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('duplicate JSON key')
        obj[key] = value
    return obj

def strict_advisory(payload, *, now_seconds):
    """Reject oversized/ambiguous/non-standard JSON before legacy evaluation."""
    try:
        if not isinstance(payload, str):
            raise TypeError('JSON string required')
        if len(payload.encode('utf-8')) > MAX_BYTES:
            raise ValueError('payload too large')
        obj = json.loads(payload, object_pairs_hook=_unique_pairs,
                         parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonstandard JSON constant')))
        if not isinstance(obj, dict):
            raise ValueError('JSON object required')
        return evaluate_payload(json.dumps(obj, allow_nan=False), now_seconds=now_seconds)
    except (TypeError, ValueError, UnicodeError, OverflowError) as exc:
        return json.dumps({'accepted': False, 'advisory_only': True,
                           'reason': 'invalid_telemetry', 'error_type': type(exc).__name__}, sort_keys=True)
