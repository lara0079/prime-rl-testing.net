"""Optional ROS 2 ament_python packaging for the advisory-only demonstrator."""
from setuptools import setup

setup(
    name='prime_rl_advisory',
    version='3.9.0',
    py_modules=['core', 'navigation_lab', 'ros_bridge', 'ros2_advisory_node', 'ros2_scenario', 'ros2_runtime_gate', 'ros2_governed_advisory', 'ros2_boundary_hardening', 'authority', 'ledger', 'session', 'unified_authority_store', 'unified_session', 'ros2_unified_runtime', 'lifecycle'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/prime_rl_advisory']),
        ('share/prime_rl_advisory', ['package.xml']),
        ('share/prime_rl_advisory/launch', ['launch/advisory.launch.py', 'launch/scenario.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='PRIME-RL research prototype',
    maintainer_email='noreply@example.invalid',
    description='Advisory-only ROS 2 telemetry validation prototype; no actuation',
    license='Proprietary - evaluation only',
    entry_points={'console_scripts': ['prime-rl-advisory = ros2_advisory_node:main', 'prime-rl-scenario = ros2_scenario:main']},
)
