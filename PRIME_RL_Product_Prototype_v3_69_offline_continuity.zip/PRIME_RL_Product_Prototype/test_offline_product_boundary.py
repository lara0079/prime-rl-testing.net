"""Regression for offline advisory boundary; NOT a live Gazebo or motion test."""
import unittest
from ros_bridge import RobotTelemetry, assess
from continuity_lab import run

class OfflineProductBoundaryTests(unittest.TestCase):
    def sample(self, connected=True, stamp=100.0):
        return RobotTelemetry(stamp, .9, .9, .9, .9, .8, connected)

    def test_offline_hold_is_advisory_only(self):
        result = assess(self.sample(False), 'hold', now_seconds=100.1)
        self.assertTrue(result['accepted'])
        self.assertTrue(result['advisory_only'])

    def test_offline_mission_is_not_authorized(self):
        result = assess(self.sample(False), 'inspect', now_seconds=100.1)
        self.assertFalse(result['accepted'])
        self.assertTrue(result['advisory_only'])

    def test_stale_offline_telemetry_rejected(self):
        result = assess(self.sample(False), 'hold', now_seconds=103.0)
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'stale_or_future_telemetry')

    def test_reconnection_requires_fresh_authority(self):
        result = run(2)
        self.assertTrue(result['passed'], result['failures'])
        self.assertEqual(result['checks'], 26)

if __name__ == '__main__':
    unittest.main()
