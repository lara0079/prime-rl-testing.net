"""Mock middleware contract for explicit unified storage opt-in."""
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from ros2_advisory_node import main
from test_ros2_node_lifecycle import FakeNode, FakeString, fake_ros

class UnifiedNodeOptinTests(unittest.TestCase):
    def setUp(self):
        FakeNode.instances.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def run_with(self, env, spin):
        with patch.dict(sys.modules, fake_ros(spin)), patch.dict(os.environ, env, clear=True):
            main([])

    def test_unified_node_rejects_telemetry_authority_and_closes(self):
        env = {'PRIME_RL_STORAGE_MODE':'unified', 'PRIME_RL_AUTHORITY_DB':str(self.root/'auth.db'),
               'PRIME_RL_DECISION_DB':str(self.root/'decisions.db')}
        def spin(node):
            msg=FakeString(); msg.data=json.dumps({'token':'untrusted'})
            node.callback(msg)
            self.assertFalse(json.loads(node.published[0])['accepted'])
        self.run_with(env, spin)
        self.assertTrue(FakeNode.instances[-1].destroyed)
        self.assertTrue((self.root/'auth.db').exists())

    def test_missing_unified_paths_fail_before_subscription(self):
        with self.assertRaisesRegex(ValueError, 'requires explicit'):
            self.run_with({'PRIME_RL_STORAGE_MODE':'unified'}, lambda node:None)
        self.assertTrue(FakeNode.instances[-1].destroyed)

    def test_unknown_mode_fails_closed(self):
        with self.assertRaisesRegex(ValueError, 'unknown'):
            self.run_with({'PRIME_RL_STORAGE_MODE':'unknown'}, lambda node:None)
        self.assertTrue(FakeNode.instances[-1].destroyed)
