import unittest
from transport_lab import SimulatedLink, run

class TransportTests(unittest.TestCase):
    def test_complete_packet_loss(self):
        link=SimulatedLink(loss=1)
        link.send('token',0)
        self.assertEqual(link.receive(100),[])
        self.assertEqual(link.stats['dropped'],1)

    def test_partition_blocks_delivery_until_reconnected(self):
        link=SimulatedLink(loss=0,duplicate=0,max_delay=0)
        link.send('token',0)
        self.assertEqual(link.receive(1,connected=False),[])
        self.assertEqual(link.receive(2,connected=True),['token'])

    def test_duplicate_delivery(self):
        link=SimulatedLink(loss=0,duplicate=1,max_delay=0)
        link.send('token',0)
        self.assertEqual(link.receive(0),['token','token'])

    def test_reproducible(self):
        a,b=run(200,seed=7),run(200,seed=7)
        self.assertEqual(a,b)

    def test_no_offline_inspection_acceptance(self):
        report=run(250)
        m=report['metrics']
        self.assertGreater(m['offline_inspect_proposals'],0)
        self.assertEqual(m['offline_inspect_accepted'],0)
        self.assertTrue(m['ledger_integrity'])

    def test_stale_and_replayed_tokens_rejected(self):
        report=run(600,seed=8)
        m=report['metrics']
        self.assertEqual(m['expired_inspect_accepted'],0)
        self.assertGreater(m['refresh_rejected'],0)
        self.assertGreater(m['online_inspect_accepted'],0)

if __name__=='__main__':
    unittest.main()
