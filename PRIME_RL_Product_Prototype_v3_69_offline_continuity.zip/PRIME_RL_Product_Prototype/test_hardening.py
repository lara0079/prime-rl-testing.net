import os
import tempfile
import unittest
from authority import AuthorityVerifier
from session import GovernedSession
from ledger import Ledger
from core import Snapshot
from test_authority import KEY, token, snap

class HardeningTests(unittest.TestCase):
    def test_replay_survives_restart(self):
        with tempfile.TemporaryDirectory() as d:
            path=os.path.join(d,'replay.sqlite')
            v=AuthorityVerifier({'demo':KEY},'lab','sim',replay_db=path)
            self.assertTrue(v.verify(token('durable'),150,consume=True).valid)
            v.close()
            v=AuthorityVerifier({'demo':KEY},'lab','sim',replay_db=path)
            self.assertEqual(v.verify(token('durable'),150,consume=True).reason,'replay_detected')
            v.close()
    def test_expiry_at_decision(self):
        with tempfile.TemporaryDirectory() as d:
            v=AuthorityVerifier({'demo':KEY},'lab','sim')
            l=Ledger(os.path.join(d,'events.sqlite'))
            session=GovernedSession(v,l)
            self.assertTrue(session.refresh(token('fresh',exp=160),150,True))
            self.assertTrue(session.decide(snap(),'inspect',now=159)['accepted'])
            self.assertFalse(session.decide(snap(),'inspect',now=160)['accepted'])
            self.assertFalse(session.decide(snap(),'inspect',now=159)['accepted'])
            self.assertTrue(l.verify())
            l.close()
    def test_missing_clock_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            v=AuthorityVerifier({'demo':KEY},'lab','sim')
            l=Ledger(os.path.join(d,'events.sqlite'))
            session=GovernedSession(v,l)
            self.assertTrue(session.refresh(token('fresh'),150,True))
            self.assertFalse(session.decide(snap(),'inspect')['accepted'])
            l.close()
    def test_recovery_remains_available_after_expiry(self):
        with tempfile.TemporaryDirectory() as d:
            v=AuthorityVerifier({'demo':KEY},'lab','sim')
            l=Ledger(os.path.join(d,'events.sqlite'))
            session=GovernedSession(v,l)
            self.assertTrue(session.refresh(token('fresh'),150,True))
            self.assertTrue(session.decide(snap(),'hold',now=201)['accepted'])
            l.close()

if __name__=='__main__':unittest.main()
