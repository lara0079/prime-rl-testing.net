"""End-to-end, synthetic mission-authority integration lab. No actuators or network I/O."""
import argparse
import json
import random
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from session import GovernedSession

KEY = b'prime-rl-simulation-key-32-bytes-only!!'

def run(seed=42, steps=1000):
    if steps < 10:
        raise ValueError('steps must be >= 10')
    rng = random.Random(seed)
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        verifier = AuthorityVerifier({'lab': KEY}, 'sim-issuer', 'sim-node', replay_db=str(root/'replay.db'))
        ledger = Ledger(root/'events.db')
        session = GovernedSession(verifier, ledger)
        counts = {'proposals':0,'accepted':0,'rejected':0,'offline_inspection_accepted':0,
                  'reconnects':0,'refresh_success':0,'refresh_failed':0,'offline_recovery_accepted':0}
        connected = True
        nonce = 0
        for i in range(steps):
            # Synthetic link outages and restoration; refreshes only when connected.
            if i % 37 == 10: connected = False
            if i % 37 == 24:
                connected = True
                counts['reconnects'] += 1
            now = 1000.0 + i
            if connected and (i == 0 or i % 37 == 24):
                nonce += 1
                claims = {'kid':'lab','iss':'sim-issuer','aud':'sim-node',
                          'nbf':now-1,'exp':now+40,'nonce':f'{seed}-{nonce}',
                          'permissions':['inspect']}
                accepted = session.refresh(sign(claims,KEY), now, True)
                counts['refresh_success' if accepted else 'refresh_failed'] += 1
            action = rng.choice(['inspect','inspect','hold','return','signal'])
            sensor = 0.15 if i % 29 == 0 else 0.9
            energy = 0.12 if i % 43 == 0 else 0.9
            snapshot = Snapshot(connected, 0.9 if connected else 0.0, sensor, energy, True)
            decision = session.decide(snapshot, action, now=now)
            counts['proposals'] += 1
            counts['accepted' if decision['accepted'] else 'rejected'] += 1
            if not connected and action == 'inspect' and decision['accepted']:
                counts['offline_inspection_accepted'] += 1
            if not connected and action in ('hold','return','signal') and decision['accepted']:
                counts['offline_recovery_accepted'] += 1
        counts['ledger_integrity'] = ledger.verify()
        counts['ledger_event_count'] = len(ledger.events())
        ledger.close()
        verifier.close()
    return {'version':'v0.9','environment':'synthetic_simulation_only','seed':seed,'steps':steps,'metrics':counts}

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--steps',type=int,default=1000)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--output',default='integrated_report.json')
    args=parser.parse_args()
    report=run(args.seed,args.steps)
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
