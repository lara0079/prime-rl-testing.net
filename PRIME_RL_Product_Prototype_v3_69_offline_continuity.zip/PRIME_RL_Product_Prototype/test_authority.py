import os
import tempfile
import unittest
from authority import sign, AuthorityVerifier
from session import GovernedSession
from ledger import Ledger
from core import Snapshot

KEY=b'local-demo-secret-key-32-bytes-minimum!'
def token(nonce='a', exp=200, permissions=None):
    return sign({'kid':'demo','iss':'lab','aud':'sim','nbf':100,'exp':exp,'nonce':nonce,
                 'permissions':['inspect'] if permissions is None else permissions}, KEY)

def snap(connected=True):
    return Snapshot(connected, 1 if connected else 0, 1, 1, True)

class AuthorityTests(unittest.TestCase):
    def setUp(self): self.v=AuthorityVerifier({'demo':KEY},'lab','sim')
    def test_signature_and_expiry(self):
        self.assertTrue(self.v.verify(token(),150).valid)
        self.assertFalse(self.v.verify(token(),200).valid)
        self.assertFalse(self.v.verify(token()+'x',150).valid)
    def test_scope(self):
        other=AuthorityVerifier({'demo':KEY},'other','sim')
        self.assertFalse(other.verify(token(),150).valid)
    def test_replay(self):
        self.assertTrue(self.v.verify(token(),150,consume=True).valid)
        self.assertEqual(self.v.verify(token(),150,consume=True).reason,'replay_detected')
    def test_permissions(self):
        self.assertEqual(self.v.verify(token(permissions=['hold']),150).permissions,frozenset({'hold'}))
    def test_reconnect_requires_refresh(self):
        with tempfile.TemporaryDirectory() as tmp:
            ledger=Ledger(os.path.join(tmp,'events.db'))
            session=GovernedSession(self.v,ledger)
            self.assertFalse(session.decide(snap(),'inspect',now=150)['accepted'])
            self.assertTrue(session.refresh(token('a'),150,True))
            self.assertTrue(session.decide(snap(),'inspect',now=150)['accepted'])
            self.assertFalse(session.decide(snap(False),'inspect',now=150)['accepted'])
            self.assertFalse(session.decide(snap(),'inspect',now=150)['accepted'])
            self.assertFalse(session.refresh(token('a'),150,True))
            self.assertTrue(session.refresh(token('b'),150,True))
            self.assertTrue(session.decide(snap(),'inspect',now=150)['accepted'])
            self.assertTrue(ledger.verify())
            ledger.close()
    def test_offline_refresh_denied(self):
        with tempfile.TemporaryDirectory() as tmp:
            ledger=Ledger(os.path.join(tmp,'events.db'))
            session=GovernedSession(self.v,ledger)
            self.assertFalse(session.refresh(token(),150,False))
            self.assertFalse(session.decide(snap(False),'inspect',now=150)['accepted'])
            ledger.close()

if __name__=='__main__': unittest.main()
