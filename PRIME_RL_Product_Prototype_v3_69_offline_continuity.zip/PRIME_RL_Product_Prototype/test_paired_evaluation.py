import unittest
from paired_evaluation import campaign, evaluate_seed, wilson_interval

class PairedEvaluationTests(unittest.TestCase):
    def test_reproducible(self):
        self.assertEqual(campaign(3, 120, 15), campaign(3, 120, 15))

    def test_paired_offline_exposure(self):
        r = campaign(4, 300, 3)
        self.assertGreater(r['offline_inspect_exposures'], 0)
        self.assertEqual(r['governed_offline_inspect_acceptances'], 0)
        self.assertEqual(r['ungoverned_offline_inspect_acceptances'], r['offline_inspect_exposures'])

    def test_accounting(self):
        r = campaign(2, 200)
        self.assertEqual(r['blocked_decisions'] + sum(x['accepted_total'] for x in r['per_seed']), 400)
        self.assertEqual(r['ledger_event_count'], 400)

    def test_wilson_bounds(self):
        self.assertEqual(wilson_interval(0, 0), [None, None])
        lo, hi = wilson_interval(0, 100)
        self.assertEqual(lo, 0)
        self.assertGreater(hi, 0)

    def test_invalid_arguments(self):
        with self.assertRaises(ValueError):
            campaign(0, 10)
        with self.assertRaises(ValueError):
            evaluate_seed(1, 0)

if __name__ == '__main__':
    unittest.main()
