"""Pure tests for a truthful, non-invasive ROS 2 readiness preflight."""
import tempfile
import unittest
from pathlib import Path
from ros2_readiness import check_environment


class ReadinessTests(unittest.TestCase):
    def test_missing_tools_is_not_ready(self):
        with tempfile.TemporaryDirectory() as d:
            result = check_environment(which=lambda _: None, find_spec=lambda _: None, package_root=d)
        self.assertFalse(result['ros2_execution_ready'])
        self.assertFalse(any(result['checks'].values()))

    def test_complete_mock_environment_is_ready_but_not_proof(self):
        with tempfile.TemporaryDirectory() as d:
            for name in ('package.xml', 'setup.py', 'ros2_advisory_node.py'):
                (Path(d) / name).write_text('')
            result = check_environment(which=lambda _: '/usr/bin/mock', find_spec=lambda _: object(), package_root=d)
        self.assertTrue(result['ros2_execution_ready'])
        self.assertIn('does not prove', result['note'])

    def test_missing_package_file_is_not_ready(self):
        with tempfile.TemporaryDirectory() as d:
            for name in ('package.xml', 'ros2_advisory_node.py'):
                (Path(d) / name).write_text('')
            result = check_environment(which=lambda _: '/usr/bin/mock', find_spec=lambda _: object(), package_root=d)
        self.assertFalse(result['ros2_execution_ready'])
        self.assertFalse(result['checks']['setup_py_present'])


if __name__ == '__main__':
    unittest.main()
