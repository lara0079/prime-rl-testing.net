"""Read-only ROS 2 environment preflight; never launches a robot or node."""
import importlib.util
import json
import shutil
from pathlib import Path


def check_environment(*, which=shutil.which, find_spec=importlib.util.find_spec, package_root=None):
    root = Path(package_root) if package_root is not None else Path(__file__).resolve().parent
    checks = {
        'ros2_cli': bool(which('ros2')),
        'colcon_cli': bool(which('colcon')),
        'rclpy_importable': bool(find_spec('rclpy')),
        'std_msgs_importable': bool(find_spec('std_msgs')),
        'package_xml_present': (root / 'package.xml').is_file(),
        'setup_py_present': (root / 'setup.py').is_file(),
        'advisory_node_present': (root / 'ros2_advisory_node.py').is_file(),
    }
    return {'checks': checks, 'ros2_execution_ready': all(checks.values()),
            'note': 'Environment checks only; does not prove ROS 2, DDS or Gazebo runtime behavior.'}


def main():
    report = check_environment()
    print(json.dumps(report, sort_keys=True, indent=2))
    return 0 if report['ros2_execution_ready'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
