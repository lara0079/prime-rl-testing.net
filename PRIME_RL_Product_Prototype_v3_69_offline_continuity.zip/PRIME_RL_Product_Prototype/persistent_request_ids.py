"""Durable request-ID deduplication for the advisory transport, not authentication."""
import sqlite3


class PersistentRequestIds:
    def __init__(self, path):
        if not path or path == ':memory:':
            raise ValueError('persistent request IDs require a file-backed SQLite path')
        self.db = sqlite3.connect(path, timeout=10)
        try:
            self.db.execute('PRAGMA busy_timeout=10000')
            self.db.execute('CREATE TABLE IF NOT EXISTS request_ids (request_id TEXT PRIMARY KEY)')
            self.db.commit()
        except BaseException:
            self.db.close()
            raise

    def claim(self, request_id):
        """Return True exactly once per database; never silently evict identifiers."""
        try:
            with self.db:
                cursor = self.db.execute('INSERT OR IGNORE INTO request_ids (request_id) VALUES (?)', (request_id,))
                return cursor.rowcount == 1
        except sqlite3.Error:
            self.db.rollback()
            raise

    def close(self):
        self.db.close()
