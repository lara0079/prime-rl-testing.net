"""Start advisory-only node. ROS 2 required at runtime."""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(package='prime_rl_advisory', executable='prime-rl-advisory',
             name='prime_rl_advisory', output='screen')
    ])
