"""Optional ROS 2 advisory and synthetic telemetry demonstration."""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(package='prime_rl_advisory', executable='prime-rl-advisory', output='screen'),
        Node(package='prime_rl_advisory', executable='prime-rl-scenario', output='screen'),
    ])
