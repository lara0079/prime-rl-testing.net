"""Optional ROS 2 read-only telemetry subscriber and advisory-only publisher.

Requires rclpy and std_msgs at runtime. JSON is a prototype transport schema,
not a production ROS message contract. NEVER subscribe this output to actuators.
"""
import json
import os
import uuid
from collections import OrderedDict
from math import isfinite
from ros_bridge import RobotTelemetry, assess

INPUT_TOPIC = '/prime_rl/telemetry_json'
OUTPUT_TOPIC = '/prime_rl/advisory_json'


def evaluate_payload(payload: str, *, now_seconds: float) -> str:
    """Pure boundary, independently testable without ROS 2 dependencies."""
    try:
        raw = json.loads(payload)
        if not isinstance(raw, dict):
            raise ValueError('telemetry must be a JSON object')
        allowed = set(RobotTelemetry.__dataclass_fields__)
        if set(raw) != allowed:
            raise ValueError('telemetry fields do not match schema')
        telemetry = RobotTelemetry(**raw)
        result = assess(telemetry, 'hold', now_seconds=now_seconds)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        result = {'accepted': False, 'advisory_only': True, 'reason': 'invalid_telemetry',
                  'error_type': type(exc).__name__}
    return json.dumps(result, sort_keys=True, allow_nan=False)



def evaluate_correlated(runtime, payload: str, *, now_seconds: float, replay_cache=None) -> str:
    """Optional correlation envelope; never interprets telemetry as authority.

    Legacy raw telemetry remains supported. Correlation is metadata only, not
    authentication, and must not be used as a safety or replay guarantee.
    """
    try:
        envelope = json.loads(payload)
    except (ValueError, TypeError):
        envelope = None
    if isinstance(envelope, dict) and 'request_id' in envelope:
        request_id = envelope['request_id']
        try:
            valid = isinstance(request_id, str) and str(uuid.UUID(request_id)) == request_id
        except (ValueError, AttributeError):
            valid = False
        if not valid or set(envelope) != {'request_id', 'telemetry'} or not isinstance(envelope['telemetry'], str):
            return json.dumps({'accepted': False, 'advisory_only': True,
                               'reason': 'invalid_telemetry', 'error_type': 'ValueError'}, sort_keys=True)
        # Optional durable deduplication; a storage error fails closed.
        if replay_cache is not None:
            try:
                fresh = replay_cache.claim(request_id) if hasattr(replay_cache, 'claim') else request_id not in replay_cache
            except Exception:
                return json.dumps({'accepted': False, 'advisory_only': True,
                                   'reason': 'replay_store_unavailable', 'request_id': request_id}, sort_keys=True)
            if not fresh:
                return json.dumps({'accepted': False, 'advisory_only': True,
                                   'reason': 'duplicate_request_id', 'request_id': request_id}, sort_keys=True)
            if not hasattr(replay_cache, 'claim'):
                replay_cache[request_id] = None
                if len(replay_cache) > 4096:
                    replay_cache.popitem(last=False)
        result = json.loads(runtime.evaluate(envelope['telemetry'], now_seconds=now_seconds))
        if not isinstance(result, dict):
            raise ValueError('runtime advisory must be an object')
        result['request_id'] = request_id
        return json.dumps(result, sort_keys=True, allow_nan=False)
    return runtime.evaluate(payload, now_seconds=now_seconds)


def main(args=None):
    try:
        import rclpy
        from rclpy.node import Node
        from std_msgs.msg import String
    except ImportError as exc:
        raise RuntimeError('ROS 2 rclpy and std_msgs are required to run the node') from exc

    class AdvisoryNode(Node):
        def __init__(self):
            super().__init__('prime_rl_advisory')
            self.runtime = None
            self.replay_cache = OrderedDict()
            self.persistent_replay = None
            try:
                replay_path = os.environ.get('PRIME_RL_REPLAY_DB')
                if replay_path:
                    from persistent_request_ids import PersistentRequestIds
                    self.persistent_replay = PersistentRequestIds(replay_path)
                    self.replay_cache = self.persistent_replay
                mode = os.environ.get('PRIME_RL_STORAGE_MODE', 'legacy')
                if mode == 'unified':
                    from ros2_unified_runtime import UnifiedAdvisoryRuntime
                    authority_path = os.environ.get('PRIME_RL_AUTHORITY_DB')
                    decision_path = os.environ.get('PRIME_RL_DECISION_DB')
                    if not authority_path or not decision_path:
                        raise ValueError('unified mode requires explicit authority and decision database paths')
                    self.runtime = UnifiedAdvisoryRuntime(authority_path, decision_path)
                elif mode == 'legacy':
                    from ros2_runtime_gate import AdvisoryRuntime
                    self.runtime = AdvisoryRuntime(os.environ.get('PRIME_RL_LEDGER_PATH', '/tmp/prime_rl_advisory.sqlite3'))
                else:
                    raise ValueError('unknown PRIME_RL_STORAGE_MODE')
            except BaseException:
                if self.persistent_replay is not None:
                    self.persistent_replay.close()
                self.destroy_node()
                raise
            try:
                self.publisher = self.create_publisher(String, OUTPUT_TOPIC, 10)
                self.subscription = self.create_subscription(String, INPUT_TOPIC, self.on_telemetry, 10)
            except BaseException:
                try:
                    self.runtime.close()
                    self.runtime = None
                finally:
                    if self.persistent_replay is not None:
                        self.persistent_replay.close()
                    self.destroy_node()
                raise

        def on_telemetry(self, msg):
            now = self.get_clock().now().nanoseconds / 1e9
            advisory = String()
            advisory.data = evaluate_correlated(self.runtime, msg.data, now_seconds=now, replay_cache=self.replay_cache)
            self.publisher.publish(advisory)

    rclpy.init(args=args)
    node = None
    try:
        node = AdvisoryNode()
        rclpy.spin(node)
    finally:
        try:
            if node is not None:
                try:
                    if node.runtime is not None:
                        node.runtime.close()
                    if node.persistent_replay is not None:
                        node.persistent_replay.close()
                finally:
                    node.destroy_node()
        finally:
            rclpy.shutdown()


if __name__ == '__main__':
    main()
