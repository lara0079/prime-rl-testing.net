"""Deterministic multi-fault campaign; simulation only, no actuator interfaces."""
import json
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from lifecycle import LifecycleStore
from session import GovernedSession

KEY = b'illustrative-compound-fault-lab-key'

def run(cycles=20):
    if type(cycles) is not int or cycles < 1:
        raise ValueError('cycles must be a positive integer')
    report = {'release':'v2.1', 'cycles':cycles, 'checks':0, 'failures':[], 'scenarios':{}, 'mode':'synthetic_software_only'}
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp)
        verifier = AuthorityVerifier({'demo':KEY}, 'compound', 'robot', p/'replay.sqlite')
        ledger = Ledger(p/'ledger.sqlite')
        lifecycle = LifecycleStore(p/'lifecycle.sqlite')
        session = GovernedSession(verifier, ledger, lifecycle)
        counter = 0
        def issue(now):
            nonlocal counter
            counter += 1
            return sign({'kid':'demo','iss':'compound','aud':'robot','nbf':now-1,
                         'exp':now+2,'nonce':f'compound-{counter}', 'permissions':['inspect']}, KEY)
        def check(name, ok):
            report['checks'] += 1
            report['scenarios'].setdefault(name, {'checks':0,'failures':0})['checks'] += 1
            if not ok:
                report['failures'].append(name)
                report['scenarios'][name]['failures'] += 1
        online = Snapshot(True,1.,.9,.9,True)
        offline_low_sensor = Snapshot(False,0.,.1,.9,True)
        offline_low_energy = Snapshot(False,0.,.9,.1,True)
        tampered = Snapshot(True,1.,.9,.9,True,False)
        for i in range(cycles):
            t = 1000. + i*20
            check('fresh_authority', session.refresh(issue(t),t,True))
            check('authorized_inspection', session.decide(online,'inspect',t+.1)['accepted'])
            check('offline_sensor_inspection_denied', not session.decide(offline_low_sensor,'inspect',t+.2)['accepted'])
            check('offline_sensor_return_denied', not session.decide(offline_low_sensor,'return',t+.3)['accepted'])
            check('offline_energy_return_denied', not session.decide(offline_low_energy,'return',t+.4)['accepted'])
            check('offline_hold_allowed', session.decide(offline_low_sensor,'hold',t+.5)['accepted'])
            check('reconnect_requires_refresh', not session.decide(online,'inspect',t+.6)['accepted'])
            check('refresh_after_reconnect', session.refresh(issue(t+.7),t+.7,True))
            check('tampered_integrity_denied', not session.decide(tampered,'inspect',t+.8)['accepted'])
            check('expired_authority_denied', not session.decide(online,'inspect',t+3.)['accepted'])
            lifecycle.close()
            lifecycle = LifecycleStore(p/'lifecycle.sqlite')
            session = GovernedSession(verifier, ledger, lifecycle)
            check('restart_requires_refresh', not session.decide(online,'inspect',t+3.1)['accepted'])
        report['ledger_valid'] = ledger.verify()
        report['ledger_events'] = len(ledger.events())
        report['passed'] = not report['failures'] and report['ledger_valid']
        lifecycle.close(); ledger.close(); verifier.close()
    report['limitations'] = ['No ROS 2 or Gazebo execution', 'Synthetic telemetry and caller-supplied clock',
                             'Illustrative HMAC authority and demo safety rules', 'No hardware safety claims']
    return report

if __name__ == '__main__':
    Path(__file__).with_name('compound_fault_report.json').write_text(json.dumps(run(),indent=2),encoding='utf-8')
