"""Crash-safe, fail-closed session epoch bookkeeping for simulation only."""
import sqlite3

class LifecycleStore:
    def __init__(self, path):
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS lifecycle (id INTEGER PRIMARY KEY CHECK(id=1), epoch INTEGER NOT NULL, revalidation_required INTEGER NOT NULL CHECK(revalidation_required IN (0,1)))')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT OR IGNORE INTO lifecycle VALUES (1,0,1)')
            self.db.execute('UPDATE lifecycle SET epoch=epoch+1, revalidation_required=1 WHERE id=1')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def mark_revalidation_required(self):
        self.db.execute('UPDATE lifecycle SET revalidation_required=1 WHERE id=1')

    def mark_refreshed(self):
        self.db.execute('UPDATE lifecycle SET revalidation_required=0 WHERE id=1')

    def required(self):
        return bool(self.db.execute('SELECT revalidation_required FROM lifecycle WHERE id=1').fetchone()[0])

    def epoch(self):
        return self.db.execute('SELECT epoch FROM lifecycle WHERE id=1').fetchone()[0]

    def close(self):
        self.db.close()
