import hashlib
import tempfile
import unittest
from pathlib import Path
from ros2_evidence_verify import verify_manifest


class EvidenceVerifyTests(unittest.TestCase):
    def test_matching_file(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'package.xml').write_bytes(b'package')
            manifest = {'schema_version': 1, 'validation_status': 'NOT_EXECUTED', 'artifacts': {
                'package.xml': {'present': True, 'sha256': hashlib.sha256(b'package').hexdigest()}}}
            self.assertTrue(verify_manifest(manifest, root)['verified'])

    def test_modified_file_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'package.xml').write_bytes(b'changed')
            manifest = {'schema_version': 1, 'validation_status': 'NOT_EXECUTED', 'artifacts': {
                'package.xml': {'present': True, 'sha256': hashlib.sha256(b'original').hexdigest()}}}
            self.assertFalse(verify_manifest(manifest, root)['verified'])

    def test_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            manifest = {'schema_version': 1, 'validation_status': 'NOT_EXECUTED', 'artifacts': {
                '../outside': {'present': True, 'sha256': '0'}}}
            self.assertFalse(verify_manifest(manifest, directory)['verified'])

    def test_false_validation_claim_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'package.xml').write_bytes(b'package')
            manifest = {'schema_version': 1, 'validation_status': 'EXECUTED', 'artifacts': {
                'package.xml': {'present': True, 'sha256': hashlib.sha256(b'package').hexdigest()}}}
            self.assertFalse(verify_manifest(manifest, root)['verified'])
