import unittest
from authorized_robot_lab import run

class AuthorizedRobotLabTests(unittest.TestCase):
    def test_nominal_mission_admitted(self):
        result = run()
        self.assertGreater(result['accepted'].get('nominal', 0), 0)
        self.assertGreater(result['accepted'].get('recovery', 0), 0)
    def test_offline_and_stale_safe(self):
        result = run()
        self.assertEqual(result['accepted'].get('stale', 0), 0)
        self.assertEqual(result['accepted'].get('disconnected', 0), result['phase_counts']['disconnected'])
    def test_ledger(self):
        self.assertTrue(run(200)['ledger_valid'])
    def test_invalid_steps(self):
        for steps in (0, -1, 1.2, True):
            with self.assertRaises(ValueError): run(steps)
    def test_deterministic(self):
        self.assertEqual(run(250), run(250))

if __name__ == '__main__': unittest.main()
