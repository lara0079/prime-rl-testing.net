"""Fail-closed offline verification of ROS 2 evidence/manifest pairs.

Checks local file consistency only; never attests to live ROS 2 execution.
"""
import argparse
import json
from pathlib import Path

from ros2_run_manifest import verify_manifest


def verify_pair(evidence_path, manifest_path):
    """Return (valid, reason), rejecting incomplete, linked or malformed pairs."""
    evidence, manifest = Path(evidence_path), Path(manifest_path)
    if evidence.resolve() == manifest.resolve():
        return False, 'same_path'
    for path, label in ((evidence, 'evidence'), (manifest, 'manifest')):
        if path.is_symlink():
            return False, f'{label}_symlink'
        if not path.is_file():
            return False, f'{label}_missing'
    try:
        def no_duplicates(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate JSON key')
                result[key] = value
            return result
        def no_constants(value):
            raise ValueError('nonfinite JSON constant')
        report = json.loads(evidence.read_text(encoding='utf-8'),
                            object_pairs_hook=no_duplicates, parse_constant=no_constants)
        record = json.loads(manifest.read_text(encoding='utf-8'),
                            object_pairs_hook=no_duplicates, parse_constant=no_constants)
        if not verify_manifest(report, record):
            return False, 'manifest_mismatch'
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, RecursionError):
        return False, 'invalid_pair'
    return True, 'valid'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('manifest', type=Path)
    args = parser.parse_args()
    valid, reason = verify_pair(args.evidence, args.manifest)
    print(json.dumps({'valid': valid, 'reason': reason}, sort_keys=True))
    if not valid:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
