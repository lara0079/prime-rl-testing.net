import json
import unittest
from ros2_boundary_hardening import strict_advisory
from ros2_contract_lab import BASE

class BoundaryHardeningTests(unittest.TestCase):
    def check_rejected(self, payload):
        result = json.loads(strict_advisory(payload, now_seconds=100.0))
        self.assertFalse(result['accepted'])
        self.assertTrue(result['advisory_only'])
        self.assertEqual(result['reason'], 'invalid_telemetry')
    def test_duplicate_field(self):
        payload = json.dumps(BASE)
        self.check_rejected(payload[:-1] + ', "connected": false}')
    def test_oversized_payload(self):
        self.check_rejected(json.dumps(BASE) + ' ' * 5000)
    def test_nan(self):
        self.check_rejected(json.dumps(BASE).replace('0.9', 'NaN', 1))
    def test_infinity(self):
        self.check_rejected(json.dumps(BASE).replace('0.9', 'Infinity', 1))
    def test_not_object(self):
        self.check_rejected('[]')
    def test_invalid_type(self):
        self.check_rejected(None)
    def test_valid_advisory_only(self):
        result = json.loads(strict_advisory(json.dumps(BASE), now_seconds=100.0))
        self.assertTrue(result['advisory_only'])
        self.assertIn('accepted', result)
    def test_unknown_command_rejected(self):
        obj = dict(BASE, cmd_vel={'linear': 1})
        self.check_rejected(json.dumps(obj))
