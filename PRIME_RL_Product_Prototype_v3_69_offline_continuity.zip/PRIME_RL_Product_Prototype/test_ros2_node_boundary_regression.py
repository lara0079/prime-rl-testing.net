"""Advisory ROS boundary regression tests using injected middleware, not DDS."""
import json
import unittest
from test_ros2_node_lifecycle import ROSNodeLifecycleTests, FakeString


class ROSNodeBoundaryRegressionTests(ROSNodeLifecycleTests):
    def _result(self, node, data):
        msg = FakeString()
        msg.data = data
        node.callback(msg)
        return json.loads(node.published[-1])

    def test_duplicate_telemetry_key_rejected(self):
        def spin(node):
            payload = ('{"stamp_seconds":10,"stamp_seconds":10,"gnss_quality":0.9,'
                       '"odometry_quality":0.9,"imu_quality":0.9,"map_freshness":1,'
                       '"battery_fraction":0.9,"connected":true}')
            result = self._result(node, payload)
            self.assertFalse(result['accepted'])
            self.assertEqual(result['reason'], 'invalid_telemetry')
        self.run_node(spin)

    def test_oversized_telemetry_rejected(self):
        def spin(node):
            result = self._result(node, ' ' * 4097)
            self.assertFalse(result['accepted'])
            self.assertEqual(result['reason'], 'invalid_telemetry')
        self.run_node(spin)

    def test_replayed_telemetry_cannot_grant_authority(self):
        def spin(node):
            payload = json.dumps(dict(stamp_seconds=10., gnss_quality=.9,
                odometry_quality=.9, imu_quality=.9, map_freshness=1.,
                battery_fraction=.9, connected=True))
            first = self._result(node, payload)
            second = self._result(node, payload)
            self.assertFalse(first['accepted'])
            self.assertFalse(second['accepted'])
            self.assertEqual(second['reason'], 'replayed_or_out_of_order_telemetry')
        self.run_node(spin)


if __name__ == '__main__':
    unittest.main()
