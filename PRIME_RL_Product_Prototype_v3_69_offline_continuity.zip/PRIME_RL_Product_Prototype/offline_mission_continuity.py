"""Prototype of bounded PREAUTHORIZED offline mission continuation.

Simulator/advisory only. Nothing here publishes actuator commands or proves
safety, cryptographic hardware identity, secure clock, or trusted localization.

A signed permit is staged while online. A separate local observer must establish
supervisor loss. The permitted path consists of immutable, individually confirmed
one-dimensional demonstration targets. Each intent is issued at most once.
Database restart and reconnection revoke continuity instead of auto-resuming.
"""
import hashlib
import json
import math
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from authority import AuthorityVerifier, encode


class MissionRejected(ValueError):
    pass


@dataclass(frozen=True)
class LocalObservation:
    stamp: float
    x: float
    confidence: float
    battery: float
    integrity_ok: bool = True


class OfflineMissionContinuity:
    """Durable advisory intent gate, deliberately separate from actuators."""

    def __init__(self, db_path, *, keys, issuer, audience, robot_id, recover_pending=True):
        if not isinstance(robot_id, str) or not robot_id:
            raise ValueError('robot_id required')
        self.robot_id = robot_id
        self.issuer = issuer
        self.audience = audience
        self.verifier = AuthorityVerifier(keys, issuer, audience)
        self.db = sqlite3.connect(str(db_path), isolation_level=None, timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('''CREATE TABLE IF NOT EXISTS permits (
          mission_id TEXT PRIMARY KEY, nonce TEXT NOT NULL UNIQUE,
          robot_id TEXT NOT NULL, status TEXT NOT NULL,
          plan TEXT NOT NULL, expires REAL NOT NULL, offline_limit REAL NOT NULL,
          total_limit REAL NOT NULL, step_limit REAL NOT NULL,
          min_confidence REAL NOT NULL, min_battery REAL NOT NULL,
          lower_x REAL NOT NULL, upper_x REAL NOT NULL,
          cursor INTEGER NOT NULL, x REAL NOT NULL, distance REAL NOT NULL,
          offline_since REAL, last_now REAL NOT NULL,
          pending_id TEXT, pending_target REAL
        )''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS audit (
          seq INTEGER PRIMARY KEY AUTOINCREMENT,
          mission_id TEXT NOT NULL, event TEXT NOT NULL,
          previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL
        )''')
        if recover_pending:
            with self._transaction():
                # A process restart always requires external revalidation. We
                # cannot know if a previously issued command was executed.
                rows = self.db.execute("SELECT mission_id FROM permits WHERE status IN ('ready','offline','pending')").fetchall()
                for (mission_id,) in rows:
                    self.db.execute("UPDATE permits SET status='needs_revalidation', pending_id=NULL, pending_target=NULL WHERE mission_id=?", (mission_id,))
                    self._audit(mission_id, {'event': 'process_restart', 'result': 'needs_revalidation'})

    @contextmanager
    def _transaction(self):
        # isolation_level=None requires an explicit BEGIN; `with self.db`
        # alone does NOT make separate UPDATE and audit INSERT atomic.
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
        else:
            self.db.execute('COMMIT')

    def _audit(self, mission_id, event):
        event = json.dumps(event, sort_keys=True, separators=(',', ':'), allow_nan=False)
        row = self.db.execute('SELECT seq,event_hash FROM audit ORDER BY seq DESC LIMIT 1').fetchone()
        previous = row[1] if row else '0' * 64
        seq = row[0] + 1 if row else 1
        digest = hashlib.sha256(f'{seq}:{mission_id}:{previous}:{event}'.encode()).hexdigest()
        self.db.execute('INSERT INTO audit VALUES (?,?,?,?,?)', (seq, mission_id, event, previous, digest))

    def verify_audit(self):
        previous = '0' * 64
        for expected, (seq, mission_id, event, prev, digest) in enumerate(self.db.execute('SELECT * FROM audit ORDER BY seq'), 1):
            if seq != expected or prev != previous or hashlib.sha256(f'{seq}:{mission_id}:{prev}:{event}'.encode()).hexdigest() != digest:
                return False
            previous = digest
        return True

    @staticmethod
    def _number(value, label, *, low=None, high=None):
        if type(value) not in (int, float) or not math.isfinite(value):
            raise MissionRejected('invalid_' + label)
        value = float(value)
        if (low is not None and value < low) or (high is not None and value > high):
            raise MissionRejected('out_of_range_' + label)
        return value

    def _observation(self, observation, now, row):
        if not isinstance(observation, LocalObservation):
            return 'missing_local_telemetry'
        if not isinstance(observation.integrity_ok, bool) or not observation.integrity_ok:
            return 'integrity_failure'
        try:
            stamp = self._number(observation.stamp, 'stamp')
            x = self._number(observation.x, 'position')
            conf = self._number(observation.confidence, 'confidence', low=0, high=1)
            battery = self._number(observation.battery, 'battery', low=0, high=1)
        except MissionRejected:
            return 'invalid_local_telemetry'
        if stamp > now or now - stamp > 1.0:
            return 'stale_local_telemetry'
        if not row['lower_x'] <= x <= row['upper_x']:
            return 'position_out_of_bounds'
        if conf < row['min_confidence'] or battery < row['min_battery']:
            return 'insufficient_local_safety_margin'
        if abs(x - row['x']) > 0.08:
            return 'unexpected_position'
        return None

    def _row(self, mission_id):
        self.db.row_factory = sqlite3.Row
        row = self.db.execute('SELECT * FROM permits WHERE mission_id=?', (mission_id,)).fetchone()
        if row is None:
            raise MissionRejected('unknown_mission')
        return row

    def _stop(self, row, reason, now):
        self.db.execute("UPDATE permits SET status='halted',pending_id=NULL,pending_target=NULL,last_now=? WHERE mission_id=?", (now, row['mission_id']))
        self._audit(row['mission_id'], {'event': 'halt', 'reason': reason})
        return {'accepted': False, 'reason': reason, 'advisory_only': True, 'action': 'hold'}

    def _clock_limit(self, row, now):
        if now < row['last_now']:
            return 'clock_rollback'
        if now >= row['expires']:
            return 'permit_expired'
        if row['offline_since'] is not None and now - row['offline_since'] > row['offline_limit']:
            return 'offline_budget_exhausted'
        return None

    def stage(self, token, *, now, connected, observation):
        """Accept one verified signed path only while online; no implicit motion."""
        now = self._number(now, 'now')
        if connected is not True:
            raise MissionRejected('stage_requires_online_supervisor')
        if not isinstance(token, str) or len(token) > 8192:
            raise MissionRejected('invalid_permit')
        if not self.verify_audit():
            raise MissionRejected('audit_integrity_failure')
        verified = self.verifier.verify(token, now, consume=False)
        if not verified.valid or 'offline:continue' not in verified.permissions:
            raise MissionRejected('invalid_or_insufficient_signature')
        try:
            body = __import__('base64').urlsafe_b64decode(token.split('.')[0] + '=' * (-len(token.split('.')[0]) % 4))
            payload = json.loads(body)
        except (ValueError, TypeError, IndexError):
            raise MissionRejected('invalid_permit')
        permitted = {'kid', 'iss', 'aud', 'nbf', 'exp', 'nonce', 'permissions',
                     'schema', 'mission_id', 'robot_id', 'plan', 'offline_limit',
                     'total_limit', 'step_limit', 'min_confidence', 'min_battery', 'lower_x', 'upper_x'}
        if set(payload) != permitted or payload['schema'] != 'prime-rl-offline-plan-v1':
            raise MissionRejected('invalid_permit_schema')
        mission_id = payload.get('mission_id')
        if not isinstance(mission_id, str) or not (1 <= len(mission_id) <= 80) or payload.get('robot_id') != self.robot_id:
            raise MissionRejected('wrong_robot_or_mission')
        plan = payload.get('plan')
        if not isinstance(plan, list) or not 1 <= len(plan) <= 16:
            raise MissionRejected('invalid_plan_length')
        targets = []
        ids = set()
        for step in plan:
            if not isinstance(step, dict) or set(step) != {'step_id', 'target_x'}:
                raise MissionRejected('invalid_step_schema')
            identifier = step['step_id']
            if not isinstance(identifier, str) or not 1 <= len(identifier) <= 60 or identifier in ids:
                raise MissionRejected('duplicate_or_invalid_step_id')
            ids.add(identifier)
            targets.append(self._number(step['target_x'], 'target'))
        lower = self._number(payload['lower_x'], 'lower_x')
        upper = self._number(payload['upper_x'], 'upper_x')
        if lower >= upper or any(not lower <= t <= upper for t in targets):
            raise MissionRejected('plan_out_of_bounds')
        offline_limit = self._number(payload['offline_limit'], 'offline_limit', low=0.1, high=3600)
        total_limit = self._number(payload['total_limit'], 'total_limit', low=.01, high=100)
        step_limit = self._number(payload['step_limit'], 'step_limit', low=.01, high=10)
        min_conf = self._number(payload['min_confidence'], 'min_confidence', low=0, high=1)
        min_battery = self._number(payload['min_battery'], 'min_battery', low=0, high=1)
        self.db.row_factory = sqlite3.Row
        with self._transaction():
            if self.db.execute("SELECT 1 FROM permits WHERE status IN ('ready','offline','pending') LIMIT 1").fetchone():
                raise MissionRejected('another_mission_active')
            # Observation must be valid against signed bounds before staging.
            dummy = {'lower_x': lower, 'upper_x': upper, 'min_confidence': min_conf,
                     'min_battery': min_battery, 'x': float(observation.x) if isinstance(observation, LocalObservation) else float('nan')}
            problem = self._observation(observation, now, dummy)
            if problem:
                raise MissionRejected(problem)
            total = 0.0
            previous = observation.x
            for target in targets:
                diff = abs(target-previous)
                if diff > step_limit or diff <= 0:
                    raise MissionRejected('invalid_step_distance')
                total += diff
                previous = target
            if total > total_limit + 1e-9:
                raise MissionRejected('distance_budget_exceeded')
            try:
                self.db.execute('''INSERT INTO permits VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                                (mission_id, verified.nonce, self.robot_id, 'ready',
                                 json.dumps(plan, sort_keys=True, separators=(',', ':')), verified.expires_at,
                                 offline_limit, total_limit, step_limit, min_conf, min_battery,
                                 lower, upper, 0, observation.x, 0.0, None, now, None, None))
            except sqlite3.IntegrityError:
                raise MissionRejected('replayed_or_duplicate_permit')
            self._audit(mission_id, {'event': 'stage', 'result': 'ready', 'steps': len(plan)})
        return {'accepted': True, 'status': 'ready', 'advisory_only': True}

    def disconnect(self, mission_id, *, now, connected, observation):
        now = self._number(now, 'now')
        with self._transaction():
            row = self._row(mission_id)
            if row['status'] != 'ready' or connected is not False:
                raise MissionRejected('not_ready_or_link_not_lost')
            issue = self._clock_limit(row, now) or self._observation(observation, now, row)
            if issue:
                return self._stop(row, issue, now)
            self.db.execute("UPDATE permits SET status='offline',offline_since=?,last_now=? WHERE mission_id=?", (now, now, mission_id))
            self._audit(mission_id, {'event': 'supervisor_lost', 'result': 'offline_authority_active'})
        return {'accepted': True, 'status': 'offline', 'advisory_only': True}

    def next_intent(self, mission_id, *, now, connected, observation):
        now = self._number(now, 'now')
        if not self.verify_audit():
            raise MissionRejected('audit_integrity_failure')
        with self._transaction():
            row = self._row(mission_id)
            if connected is not False:
                self._revoke(row, now, 'supervisor_reconnected')
                return {'accepted': False, 'reason': 'revalidation_required', 'action': 'hold', 'advisory_only': True}
            if row['status'] != 'offline':
                return {'accepted': False, 'reason': 'not_offline_ready', 'action': 'hold', 'advisory_only': True}
            issue = self._clock_limit(row, now) or self._observation(observation, now, row)
            if issue:
                return self._stop(row, issue, now)
            plan = json.loads(row['plan'])
            if row['cursor'] >= len(plan):
                return self._stop(row, 'plan_exhausted', now)
            step = plan[row['cursor']]
            target = step['target_x']
            distance = abs(target - row['x'])
            if distance > row['step_limit'] or row['distance'] + distance > row['total_limit'] + 1e-9:
                return self._stop(row, 'distance_budget_exhausted', now)
            intent_id = f"{mission_id}/{row['cursor']}/{step['step_id']}"
            self.db.execute("UPDATE permits SET status='pending',pending_id=?,pending_target=?,last_now=? WHERE mission_id=?",
                            (intent_id, target, now, mission_id))
            self._audit(mission_id, {'event': 'intent_issued', 'step': step['step_id'], 'index': row['cursor']})
        return {'accepted': True, 'action': 'bounded_segment', 'intent_id': intent_id,
                'target_x': target, 'advisory_only': True, 'requires_observed_confirmation': True}

    def confirm(self, mission_id, *, intent_id, now, connected, observation):
        now = self._number(now, 'now')
        if not self.verify_audit():
            raise MissionRejected('audit_integrity_failure')
        with self._transaction():
            row = self._row(mission_id)
            if connected is not False:
                self._revoke(row, now, 'supervisor_reconnected')
                return {'accepted': False, 'reason': 'revalidation_required', 'action': 'hold', 'advisory_only': True}
            if row['status'] != 'pending' or row['pending_id'] != intent_id:
                return {'accepted': False, 'reason': 'unknown_or_replayed_intent', 'action': 'hold', 'advisory_only': True}
            issue = self._clock_limit(row, now)
            if not issue:
                # Only accept a position matching the issued target; the
                # prior last_x check applies before a segment, not after it.
                if not isinstance(observation, LocalObservation) or not observation.integrity_ok:
                    issue = 'invalid_local_telemetry'
                else:
                    try:
                        stamp = self._number(observation.stamp, 'stamp')
                        position = self._number(observation.x, 'position')
                        confidence = self._number(observation.confidence, 'confidence', low=0, high=1)
                        battery = self._number(observation.battery, 'battery', low=0, high=1)
                    except MissionRejected:
                        issue = 'invalid_local_telemetry'
                    else:
                        if stamp > now or now - stamp > 1.0:
                            issue = 'stale_local_telemetry'
                        elif confidence < row['min_confidence'] or battery < row['min_battery']:
                            issue = 'insufficient_local_safety_margin'
                        elif not row['lower_x'] <= position <= row['upper_x']:
                            issue = 'position_out_of_bounds'
                        elif abs(position - row['pending_target']) > .08:
                            issue = 'unconfirmed_segment_motion'
            if issue:
                return self._stop(row, issue, now)
            new_distance = row['distance'] + abs(row['pending_target'] - row['x'])
            plan = json.loads(row['plan'])
            new_cursor = row['cursor'] + 1
            new_status = 'completed' if new_cursor == len(plan) else 'offline'
            self.db.execute('''UPDATE permits SET status=?,cursor=?,x=?,distance=?,pending_id=NULL,pending_target=NULL,last_now=? WHERE mission_id=?''',
                            (new_status, new_cursor, observation.x, new_distance, now, mission_id))
            self._audit(mission_id, {'event': 'segment_confirmed', 'index': row['cursor'], 'complete': new_status == 'completed'})
        return {'accepted': True, 'status': new_status, 'completed_steps': new_cursor,
                'advisory_only': True}

    def _revoke(self, row, now, reason):
        self.db.execute("UPDATE permits SET status='needs_revalidation',pending_id=NULL,pending_target=NULL,last_now=? WHERE mission_id=?", (now, row['mission_id']))
        self._audit(row['mission_id'], {'event': 'revalidation_required', 'reason': reason})

    def reconnect(self, mission_id, *, now):
        now = self._number(now, 'now')
        with self._transaction():
            row = self._row(mission_id)
            if now < row['last_now']:
                return self._stop(row, 'clock_rollback', now)
            self._revoke(row, now, 'supervisor_reconnected')
        return {'accepted': True, 'status': 'needs_revalidation', 'advisory_only': True}

    def status(self, mission_id):
        row = self._row(mission_id)
        return {'mission_id': mission_id, 'status': row['status'], 'confirmed_steps': row['cursor'],
                'distance': row['distance'], 'offline_since': row['offline_since'],
                'pending_id': row['pending_id']}

    def close(self):
        self.db.close()
        self.verifier.close()
