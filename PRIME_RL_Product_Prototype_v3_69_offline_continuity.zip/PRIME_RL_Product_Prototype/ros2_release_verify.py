"""Strict offline verification of a complete ROS 2 preflight artifact manifest.

Hash consistency is not a signature, provenance proof, or runtime validation.
"""
from pathlib import Path
from ros2_evidence_verify import verify_manifest

REQUIRED = frozenset({
    'package.xml', 'setup.py', 'launch/scenario.launch.py',
    'launch/advisory.launch.py', 'ros2_advisory_node.py',
    'ROS2_VALIDATION_RUNBOOK.md',
})


def verify_release_manifest(manifest, root):
    if not isinstance(manifest, dict):
        return {'verified': False, 'issues': ['manifest must be an object']}
    artifacts = manifest.get('artifacts')
    if not isinstance(artifacts, dict):
        return {'verified': False, 'issues': ['artifacts must be an object']}
    issues = []
    missing = REQUIRED - artifacts.keys()
    if missing:
        issues.append('missing required artifacts: ' + ', '.join(sorted(missing)))
    unexpected = artifacts.keys() - REQUIRED
    if unexpected:
        issues.append('unexpected artifacts: ' + ', '.join(sorted(map(str, unexpected))))
    # Do not trust the recorded host readiness as proof of execution.
    if manifest.get('validation_status') != 'NOT_EXECUTED':
        issues.append('preflight cannot assert runtime validation')
    result = verify_manifest(manifest, Path(root))
    result['issues'] = issues + result['issues']
    result['verified'] = not result['issues']
    result['scope'] = 'complete source artifact consistency only; ROS 2/Gazebo untested'
    return result
