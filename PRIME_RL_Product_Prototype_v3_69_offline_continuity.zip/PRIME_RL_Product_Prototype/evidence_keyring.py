"""Local-only evidence HMAC key loading; never package or log key material.

POSIX owner-only file policy is a defense in depth, not a hardware key vault.
"""
import os
from pathlib import Path
import stat


def load_evidence_key(path):
    """Read a raw 32-4096 byte key from a regular, owner-only POSIX file.

    Reject symbolic links and permissive modes; fail closed on unsupported OS.
    """
    if os.name != 'posix':
        raise RuntimeError('secure key-file loader requires POSIX permissions')
    target = Path(path)
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0)
    if not hasattr(os, 'O_NOFOLLOW'):
        raise RuntimeError('no symlink-safe open available')
    fd = os.open(target, flags)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('key must be a regular file')
        if info.st_mode & 0o077:
            raise ValueError('key file must not be accessible by group or others')
        if info.st_uid != os.geteuid():
            raise ValueError('key file must be owned by current effective user')
        if not 32 <= info.st_size <= 4096:
            raise ValueError('key file size outside 32-4096 bytes')
        with os.fdopen(os.dup(fd), 'rb') as stream:
            key = stream.read(4097)
        if not 32 <= len(key) <= 4096:
            raise ValueError('invalid key length')
        return key
    finally:
        os.close(fd)
