import json
import unittest
from ros2_advisory_node import evaluate_payload, INPUT_TOPIC, OUTPUT_TOPIC


class ROS2AdvisoryTests(unittest.TestCase):
    def setUp(self):
        self.payload = dict(stamp_seconds=10., gnss_quality=.9, odometry_quality=.9,
                            imu_quality=.9, map_freshness=1., battery_fraction=.9,
                            connected=True)

    def evaluate(self, payload=None, now=10.):
        return json.loads(evaluate_payload(json.dumps(self.payload if payload is None else payload), now_seconds=now))

    def test_valid_advisory(self):
        self.assertTrue(self.evaluate()['advisory_only'])

    def test_stale_rejected(self):
        self.assertFalse(self.evaluate(now=15.)['accepted'])

    def test_missing_field_rejected(self):
        bad = self.payload.copy(); del bad['connected']
        self.assertEqual(self.evaluate(bad)['reason'], 'invalid_telemetry')

    def test_extra_field_rejected(self):
        bad = self.payload.copy(); bad['motor_command'] = 'go'
        self.assertFalse(self.evaluate(bad)['accepted'])

    def test_invalid_json_rejected(self):
        self.assertFalse(json.loads(evaluate_payload('{broken', now_seconds=10))['accepted'])

    def test_wrong_top_level_rejected(self):
        self.assertFalse(self.evaluate([])['accepted'])

    def test_no_actuator_topics(self):
        self.assertIn('advisory', OUTPUT_TOPIC)
        self.assertNotIn('cmd_vel', OUTPUT_TOPIC)
        self.assertNotEqual(INPUT_TOPIC, OUTPUT_TOPIC)

    def test_nan_rejected(self):
        bad = self.payload.copy(); bad['battery_fraction'] = float('nan')
        self.assertFalse(self.evaluate(bad)['accepted'])


if __name__ == '__main__': unittest.main()
