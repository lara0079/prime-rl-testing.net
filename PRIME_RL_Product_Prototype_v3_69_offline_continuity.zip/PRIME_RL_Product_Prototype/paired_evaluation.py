"""Reproducible paired counterfactual test on identical synthetic observations and proposals.
Not an estimate of field safety, causal policy-training gains, or hardware performance.
"""
import argparse
import json
import math
import random
from statistics import mean
from core import Runtime
from learning_lab import ACTIONS, ToyObservation


def wilson_interval(successes, total, z=1.96):
    if total <= 0:
        return [None, None]
    p = successes / total
    d = 1 + z*z/total
    center = (p + z*z/(2*total))/d
    margin = z*math.sqrt(p*(1-p)/total + z*z/(4*total*total))/d
    return [round(max(0, center-margin), 6), round(min(1, center+margin), 6)]


def evaluate_seed(seed, steps=1000):
    if steps <= 0:
        raise ValueError('steps must be positive')
    rng = random.Random(seed)
    gate = Runtime()
    counts = {'seed': seed, 'steps': steps, 'offline': 0, 'proposed_inspect_offline': 0,
              'ungoverned_inspect_offline': 0, 'governed_inspect_offline': 0,
              'blocked_total': 0, 'accepted_total': 0, 'ledger_events': 0,
              'unexpected_governed_offline_inspect': 0}
    for _ in range(steps):
        obs = ToyObservation(rng.random() >= .35, rng.random() >= .15, rng.random() >= .12)
        action = ACTIONS[rng.randrange(len(ACTIONS))]
        accepted = gate.evaluate(obs.snapshot(), action)['accepted']
        if not obs.connected:
            counts['offline'] += 1
            if action == 'inspect':
                counts['proposed_inspect_offline'] += 1
                counts['ungoverned_inspect_offline'] += 1
                if accepted:
                    counts['governed_inspect_offline'] += 1
                    counts['unexpected_governed_offline_inspect'] += 1
        counts['accepted_total' if accepted else 'blocked_total'] += 1
    counts['ledger_events'] = len(gate.events)
    return counts


def campaign(seeds=30, steps=1000, seed_start=100):
    if seeds <= 0 or steps <= 0:
        raise ValueError('seeds and steps must be positive')
    runs = [evaluate_seed(seed_start + i, steps) for i in range(seeds)]
    total = seeds * steps
    blocked = sum(r['blocked_total'] for r in runs)
    exposure = sum(r['proposed_inspect_offline'] for r in runs)
    violations = sum(r['unexpected_governed_offline_inspect'] for r in runs)
    return {'experiment': 'paired frozen synthetic proposals (not a trained policy comparison)',
            'seeds': seeds, 'steps_per_seed': steps, 'total_decisions': total,
            'blocked_decisions': blocked, 'blocked_fraction': round(blocked/total, 6),
            'blocked_fraction_wilson95': wilson_interval(blocked, total),
            'offline_inspect_exposures': exposure,
            'ungoverned_offline_inspect_acceptances': exposure,
            'governed_offline_inspect_acceptances': violations,
            'observed_violation_fraction': round(violations/exposure, 6) if exposure else None,
            'observed_violation_wilson95': wilson_interval(violations, exposure),
            'ledger_event_count': sum(r['ledger_events'] for r in runs),
            'run_blocked_fraction_min': round(min(r['blocked_total']/steps for r in runs), 6),
            'run_blocked_fraction_max': round(max(r['blocked_total']/steps for r in runs), 6),
            'per_seed': runs,
            'limitations': ['Synthetic independently sampled observations and uniformly random proposals',
                            'Unrestricted arm assumes every proposal executes; this is not a physical baseline',
                            'Illustrative rule gate; not an RL safety proof',
                            'Wilson interval quantifies sampling variation under this toy distribution only',
                            'No ROS 2, real sensors, real network, or real robot validation']}

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--seeds', type=int, default=30)
    p.add_argument('--steps', type=int, default=1000)
    p.add_argument('--output', default='paired_evaluation_report.json')
    a = p.parse_args()
    result = campaign(a.seeds, a.steps)
    with open(a.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    print(json.dumps({k:v for k,v in result.items() if k != 'per_seed'}, indent=2))
