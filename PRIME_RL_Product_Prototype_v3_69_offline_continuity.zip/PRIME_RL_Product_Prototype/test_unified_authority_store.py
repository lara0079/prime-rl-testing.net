import sqlite3
import tempfile
import unittest
from pathlib import Path
from unified_authority_store import UnifiedAuthorityStore


class UnifiedAuthorityStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'unified.sqlite'

    def tearDown(self):
        self.tmp.cleanup()

    def test_success_commits_all_three(self):
        with UnifiedAuthorityStore(self.path) as store:
            store.authorize('issuer','robot','nonce')
            self.assertTrue(store.nonce_consumed('issuer','robot','nonce'))
            self.assertEqual(store.status()['audit_count'],1)
            self.assertFalse(store.status()['revalidation_required'])
            self.assertTrue(store.verify_audit())

    def test_injected_failures_rollback_all(self):
        with UnifiedAuthorityStore(self.path) as store:
            for stage in ('nonce','state','audit'):
                with self.assertRaises(RuntimeError):
                    store.authorize('issuer','robot',stage,inject_failure=stage)
                self.assertFalse(store.nonce_consumed('issuer','robot',stage))
                self.assertTrue(store.status()['revalidation_required'])
                self.assertEqual(store.status()['audit_count'],0)

    def test_duplicate_nonce_does_not_add_audit(self):
        with UnifiedAuthorityStore(self.path) as store:
            store.authorize('issuer','robot','same')
            with self.assertRaises(sqlite3.IntegrityError):
                store.authorize('issuer','robot','same')
            self.assertEqual(store.status()['audit_count'],1)
            self.assertTrue(store.verify_audit())

    def test_restart_requires_revalidation(self):
        with UnifiedAuthorityStore(self.path) as store:
            store.authorize('issuer','robot','first')
            first_epoch = store.status()['epoch']
        with UnifiedAuthorityStore(self.path) as store:
            self.assertEqual(store.status()['epoch'],first_epoch+1)
            self.assertTrue(store.status()['revalidation_required'])
            self.assertTrue(store.nonce_consumed('issuer','robot','first'))
            self.assertEqual(store.status()['audit_count'],1)
