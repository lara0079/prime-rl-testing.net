"""Fail-closed restart tests for optional checkpoint enforcement."""
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from ledger_checkpoint import save_checkpoint
from ros2_runtime_gate import AdvisoryRuntime

class RuntimeCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'ledger.db'
        self.cp = Path(self.temp.name) / 'head.json'

    def test_matching_checkpoint_allows_startup(self):
        ledger = Ledger(self.db)
        ledger.append({'event': 'one'})
        save_checkpoint(ledger, self.cp)
        ledger.close()
        runtime = AdvisoryRuntime(self.db, self.cp)
        runtime.close()

    def test_deleted_tail_prevents_restart(self):
        ledger = Ledger(self.db)
        ledger.append({'event': 'one'})
        ledger.append({'event': 'two'})
        save_checkpoint(ledger, self.cp)
        with ledger.db:
            ledger.db.execute('DELETE FROM events WHERE seq=2')
        ledger.close()
        with self.assertRaisesRegex(ValueError, 'checkpoint'):
            AdvisoryRuntime(self.db, self.cp)

    def test_missing_checkpoint_prevents_restart(self):
        with self.assertRaisesRegex(ValueError, 'checkpoint'):
            AdvisoryRuntime(self.db, self.cp)

    def test_corrupt_checkpoint_prevents_restart(self):
        ledger = Ledger(self.db)
        save_checkpoint(ledger, self.cp)
        ledger.close()
        self.cp.write_text('broken')
        with self.assertRaisesRegex(ValueError, 'checkpoint'):
            AdvisoryRuntime(self.db, self.cp)

if __name__ == '__main__':
    unittest.main()
