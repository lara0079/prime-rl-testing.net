"""Synthetic localization uncertainty and navigation gating laboratory.
No physical motion, SLAM, ROS, sensor fusion certification, or actuators.
"""
from dataclasses import dataclass
from math import isfinite
import argparse
import json
import random
from pathlib import Path
from core import Runtime, Snapshot

@dataclass(frozen=True)
class LocalizationSample:
    gnss: float | None
    odometry: float | None
    imu: float | None
    map_freshness: float
    energy: float
    connected: bool

    def validate(self):
        for name in ('gnss','odometry','imu','map_freshness','energy'):
            value=getattr(self,name)
            if value is not None and (not isinstance(value,(int,float)) or not isfinite(value) or not 0 <= value <= 1):
                raise ValueError(f'invalid {name}')


def estimate_confidence(sample: LocalizationSample):
    """Illustrative conservative synthetic confidence; NOT a calibrated estimator."""
    sample.validate()
    candidates=[v for v in (sample.gnss,sample.odometry,sample.imu) if v is not None]
    if not candidates:
        return 0.0
    # Conservatively discount a single source and stale maps. Do not interpret as probability.
    redundancy=0.7 if len(candidates)==1 else 0.85 if len(candidates)==2 else 1.0
    return round(min(candidates)*redundancy*sample.map_freshness,6)


def evaluate_navigation(sample: LocalizationSample, proposed='return'):
    confidence=estimate_confidence(sample)
    snapshot=Snapshot(connected=sample.connected,link_quality=1.0 if sample.connected else 0.0,
                      sensor_confidence=confidence,energy_fraction=sample.energy,authority_valid=True)
    decision=Runtime().evaluate(snapshot,proposed)
    return {'confidence':confidence,'decision':decision,'sample':sample.__dict__}


def run(steps=1000,seed=42):
    if not isinstance(steps,int) or steps<1:
        raise ValueError('steps must be positive')
    rng=random.Random(seed)
    metrics={'steps':steps,'gnss_missing':0,'all_localization_missing':0,
             'low_confidence_return_proposals':0,'low_confidence_return_accepted':0,
             'offline_hold_proposals':0,'offline_hold_accepted':0,
             'return_proposals':0,'return_accepted':0}
    for tick in range(steps):
        connected=tick%80<40
        gnss=None if tick%50<20 else rng.uniform(0.7,1)
        odometry=None if tick%90<12 else rng.uniform(0.5,1)
        imu=None if tick%110<10 else rng.uniform(0.4,1)
        freshness=0.1 if tick%65<15 else rng.uniform(0.65,1)
        sample=LocalizationSample(gnss,odometry,imu,freshness,rng.uniform(0.35,1),connected)
        confidence=estimate_confidence(sample)
        metrics['gnss_missing']+=int(gnss is None)
        metrics['all_localization_missing']+=int(all(v is None for v in (gnss,odometry,imu)))
        proposal='hold' if not connected and tick%3==0 else 'return'
        result=evaluate_navigation(sample,proposal)['decision']
        if proposal=='hold':
            metrics['offline_hold_proposals']+=1
            metrics['offline_hold_accepted']+=int(result['accepted'])
        else:
            metrics['return_proposals']+=1
            metrics['return_accepted']+=int(result['accepted'])
            if confidence<0.25:
                metrics['low_confidence_return_proposals']+=1
                metrics['low_confidence_return_accepted']+=int(result['accepted'])
    return {'version':'v1.3','scope':'synthetic_localization_degradation','seed':seed,'metrics':metrics,
            'limitations':'Synthetic confidence only; no ROS 2, Gazebo, real sensor data, calibrated localization, trusted time, or hardware validation.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--steps',type=int,default=1000)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--output',default='navigation_report.json')
    args=parser.parse_args()
    report=run(args.steps,args.seed)
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
