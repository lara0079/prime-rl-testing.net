"""Offline contract tests; live DDS test requires a ROS 2 host."""
import json
import unittest
from ros2_live_smoke import check_advisory, run


class TestLiveSmokeContract(unittest.TestCase):
    def test_valid_fail_closed_advisory(self):
        self.assertEqual(check_advisory(json.dumps({'advisory_only': True, 'accepted': False, 'reason': 'invalid_telemetry'}))['reason'], 'invalid_telemetry')

    def test_rejects_unsafe_or_nonadvisory_result(self):
        for value in ({'advisory_only': False, 'accepted': False, 'reason': 'invalid_telemetry'},
                      {'advisory_only': True, 'accepted': True, 'reason': 'invalid_telemetry'},
                      {'advisory_only': True, 'accepted': False, 'reason': 'other'}, []):
            with self.subTest(value=value), self.assertRaises(ValueError):
                check_advisory(json.dumps(value))

    def test_requires_expected_error_type_when_specified(self):
        value = json.dumps({'advisory_only': True, 'accepted': False,
                            'reason': 'invalid_telemetry', 'error_type': 'JSONDecodeError'})
        self.assertEqual(check_advisory(value, expected_error_type='JSONDecodeError')['error_type'], 'JSONDecodeError')
        with self.assertRaises(ValueError):
            check_advisory(value, expected_error_type='ValueError')

    def test_invalid_timeout_without_ros_dependency(self):
        with self.assertRaises(ValueError):
            run(0)


if __name__ == '__main__':
    unittest.main()
