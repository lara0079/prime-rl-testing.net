import tempfile
import unittest
from pathlib import Path
from ros2_workspace_prepare import prepare


class WorkspacePreparationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'source'
        self.source.mkdir()
        for name in ('package.xml', 'setup.py', 'ros2_advisory_node.py', 'ros2_live_smoke.py', 'ros2_integration_preflight.py'):
            (self.source / name).write_text('placeholder')
        self.workspace = self.root / 'workspace'

    def test_dry_run_does_not_create_workspace(self):
        result = prepare(self.source, self.workspace)
        self.assertEqual(result['mode'], 'dry_run')
        self.assertFalse(self.workspace.exists())
        self.assertFalse(result['ros2_executed'])

    def test_copy_creates_package_without_installing(self):
        result = prepare(self.source, self.workspace, copy=True)
        self.assertTrue((self.workspace / 'src' / 'prime_rl_advisory' / 'package.xml').is_file())
        self.assertFalse(result['dependencies_installed'])

    def test_existing_destination_is_not_overwritten(self):
        prepare(self.source, self.workspace, copy=True)
        with self.assertRaises(FileExistsError):
            prepare(self.source, self.workspace, copy=True)

    def test_missing_files_fail_closed(self):
        (self.source / 'setup.py').unlink()
        with self.assertRaises(ValueError):
            prepare(self.source, self.workspace, copy=True)
        self.assertFalse(self.workspace.exists())

    def test_nested_workspace_is_rejected(self):
        with self.assertRaises(ValueError):
            prepare(self.source, self.source / 'workspace', copy=True)

    def test_symlink_source_is_rejected(self):
        (self.source / 'link').symlink_to(self.source / 'package.xml')
        with self.assertRaises(ValueError):
            prepare(self.source, self.workspace, copy=True)
        self.assertFalse(self.workspace.exists())


if __name__ == '__main__':
    unittest.main()
