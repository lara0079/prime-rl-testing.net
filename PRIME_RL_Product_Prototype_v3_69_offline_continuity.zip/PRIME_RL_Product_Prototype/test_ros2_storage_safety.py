"""Storage path adversarial checks for the advisory-only runtime."""
import json
import os
import tempfile
import unittest
from pathlib import Path
from ros2_runtime_gate import AdvisoryRuntime
from ros2_contract_lab import BASE

class StorageSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_symlink_database_is_rejected(self):
        target = self.root / 'target.sqlite3'
        target.touch()
        link = self.root / 'ledger.sqlite3'
        link.symlink_to(target)
        with self.assertRaises(ValueError):
            AdvisoryRuntime(link)

    def test_directory_database_is_rejected(self):
        path = self.root / 'dbdir'
        path.mkdir()
        with self.assertRaises(ValueError):
            AdvisoryRuntime(path)

    def test_missing_parent_is_rejected(self):
        with self.assertRaises(ValueError):
            AdvisoryRuntime(self.root / 'missing' / 'db.sqlite3')

    def test_regular_database_remains_functional(self):
        path = self.root / 'db.sqlite3'
        runtime = AdvisoryRuntime(path)
        try:
            output = json.loads(runtime.evaluate(json.dumps(BASE), 100))
            self.assertFalse(output['accepted'])
            self.assertTrue(runtime.ledger.verify())
        finally:
            runtime.close()

    def test_broken_symlink_is_rejected(self):
        link = self.root / 'broken.sqlite3'
        link.symlink_to(self.root / 'not-here.sqlite3')
        with self.assertRaises(ValueError):
            AdvisoryRuntime(link)

if __name__ == '__main__':
    unittest.main()
