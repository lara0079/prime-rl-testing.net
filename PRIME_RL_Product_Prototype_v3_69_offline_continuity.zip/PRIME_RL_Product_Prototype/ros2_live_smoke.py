"""Live ROS 2 DDS advisory smoke test. Run only on a prepared isolated ROS host.

No actuator topics are used. A running prime_rl_advisory node is required.
"""
import argparse
import json
import math
import time
import uuid

from ros2_advisory_node import INPUT_TOPIC, OUTPUT_TOPIC


def check_advisory(data, *, expected_error_type=None, expected_request_id=None):
    """Validate a received advisory envelope without asserting robot safety."""
    obj = json.loads(data)
    if not isinstance(obj, dict):
        raise ValueError('advisory must be a JSON object')
    if obj.get('advisory_only') is not True:
        raise ValueError('advisory_only must be true')
    if obj.get('accepted') is not False:
        raise ValueError('malformed telemetry must be rejected')
    if obj.get('reason') != 'invalid_telemetry':
        raise ValueError('expected invalid_telemetry rejection')
    if expected_error_type is not None and obj.get('error_type') != expected_error_type:
        raise ValueError('unexpected rejection error type')
    if expected_request_id is not None and obj.get('request_id') != expected_request_id:
        raise ValueError('request correlation mismatch')
    return obj


def validate_timings(samples, *, max_latency_ms):
    """Check measured local round trips; not a DDS one-way latency claim."""
    if not isinstance(max_latency_ms, (int, float)) or isinstance(max_latency_ms, bool) or not math.isfinite(max_latency_ms) or not 0 < max_latency_ms <= 120000:
        raise ValueError("invalid latency budget")
    if not samples or any(not isinstance(x, (int, float)) or isinstance(x, bool) or not math.isfinite(x) or not 0 <= x <= max_latency_ms for x in samples):
        raise ValueError("missing, invalid, or over-budget round trip")
    return {"round_trip_ms": [round(x, 3) for x in samples], "max_round_trip_ms": round(max(samples), 3),
            "latency_budget_ms": max_latency_ms, "metric": "publisher-to-correlated-advisory local elapsed time"}


def run(timeout=10.0, max_latency_ms=5000.0):
    """Publish one deliberately invalid payload and await an advisory rejection."""
    if (not isinstance(timeout, (int, float)) or isinstance(timeout, bool)
            or not math.isfinite(timeout) or not 0 < timeout <= 120):
        raise ValueError('timeout must be between 0 and 120 seconds')
    validate_timings([0.0], max_latency_ms=max_latency_ms)
    import rclpy
    from rclpy.node import Node
    from std_msgs.msg import String

    rclpy.init()
    node = None
    try:
        node = Node('prime_rl_smoke_' + uuid.uuid4().hex[:12])
        received = []
        sub = node.create_subscription(String, OUTPUT_TOPIC, lambda msg: received.append(msg.data), 10)
        pub = node.create_publisher(String, INPUT_TOPIC, 10)
        discovery_deadline = time.monotonic() + timeout
        # Wait for DDS discovery before publishing; avoid a false pass from no subscriber.
        while (pub.get_subscription_count() == 0 or sub.get_publisher_count() == 0) and time.monotonic() < discovery_deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
        if pub.get_subscription_count() == 0 or sub.get_publisher_count() == 0:
            raise TimeoutError('DDS discovery incomplete: telemetry subscriber or advisory publisher missing')
        # Each probe uses a unique request ID and accepts only the matching
        # rejected advisory. This is correlation, not authenticated provenance.
        scenarios = [('{broken-json', 'JSONDecodeError'),
                     ('{"unexpected_field": true}', 'ValueError')]
        evidence = []
        timings = []
        for payload, expected_error in scenarios:
            # DDS graph membership can change after initial discovery.
            # Do not publish a new probe into a disconnected graph.
            if pub.get_subscription_count() == 0 or sub.get_publisher_count() == 0:
                raise TimeoutError('DDS endpoint disappeared before telemetry probe')
            received.clear()
            msg = String()
            request_id = str(uuid.uuid4())
            msg.data = json.dumps({'request_id': request_id, 'telemetry': payload})
            sent_at = time.monotonic()
            scenario_deadline = sent_at + timeout
            pub.publish(msg)
            matched = False
            while time.monotonic() < scenario_deadline:
                if pub.get_subscription_count() == 0 or sub.get_publisher_count() == 0:
                    raise TimeoutError('DDS endpoint disappeared while awaiting advisory')
                rclpy.spin_once(node, timeout_sec=0.1)
                batch = received[:]
                received.clear()
                for data in batch:
                    try:
                        result = check_advisory(data, expected_error_type=expected_error,
                                                expected_request_id=request_id)
                    except (ValueError, json.JSONDecodeError):
                        continue
                    timings.append((time.monotonic() - sent_at) * 1000.0)
                    evidence.append(result)
                    matched = True
                    break
                if matched:
                    break
            if not matched:
                raise TimeoutError('no matching fail-closed advisory for ' + expected_error)
        metrics = validate_timings(timings, max_latency_ms=max_latency_ms)
        return {'status': 'pass', 'advisories': evidence, 'timing': metrics, 'input_topic': INPUT_TOPIC,
                'output_topic': OUTPUT_TOPIC, 'one_way_dds_latency_measured': False,
                'request_correlation_verified': True}

    finally:
        try:
            if node is not None:
                node.destroy_node()
        finally:
            rclpy.shutdown()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timeout', type=float, default=10.0)
    parser.add_argument('--max-latency-ms', type=float, default=5000.0)
    args = parser.parse_args()
    try:
        print(json.dumps(run(args.timeout, args.max_latency_ms), sort_keys=True))
    except (ImportError, RuntimeError, TimeoutError, ValueError) as exc:
        print(json.dumps({'status': 'fail', 'error_type': type(exc).__name__, 'error': str(exc)}))
        raise SystemExit(2)


if __name__ == '__main__':
    main()
