"""Offline user-configured latency gate; never establishes live DDS provenance."""
import argparse
import json
import math
from pathlib import Path

from ros2_metrics_summary import summarize


def assess(directory, *, max_p95_ms, min_samples, max_mean_ms=None,
           min_runs=1, min_evidence_pairs=1):
    for label, value in [('max_p95_ms', max_p95_ms), ('max_mean_ms', max_mean_ms)]:
        if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or
                                  not math.isfinite(value) or value <= 0):
            raise ValueError(label + ' must be a finite positive number')
    if isinstance(min_samples, bool) or not isinstance(min_samples, int) or min_samples < 1:
        raise ValueError('min_samples must be a positive integer')
    for label, value in [('min_runs', min_runs), ('min_evidence_pairs', min_evidence_pairs)]:
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(label + ' must be a positive integer')
    summary = summarize(directory)
    limits = {'max_p95_ms': max_p95_ms, 'min_samples': min_samples,
              'min_runs': min_runs, 'min_evidence_pairs': min_evidence_pairs}
    if max_mean_ms is not None:
        limits['max_mean_ms'] = max_mean_ms
    if summary['status'] != 'pass':
        return {'status': 'fail', 'reason': 'invalid_evidence', 'limits': limits,
                'summary': summary, 'live_dds_attested': False}
    failures = []
    if summary['sample_count'] < min_samples:
        failures.append('insufficient_samples')
    if summary['completed_runs'] < min_runs:
        failures.append('insufficient_independent_runs')
    if summary['evidence_pairs'] < min_evidence_pairs:
        failures.append('insufficient_evidence_pairs')
    if summary['latency_ms']['p95'] > max_p95_ms:
        failures.append('p95_exceeds_limit')
    if max_mean_ms is not None and summary['latency_ms']['mean'] > max_mean_ms:
        failures.append('mean_exceeds_limit')
    return {'status': 'fail' if failures else 'pass', 'failures': failures,
            'limits': limits, 'summary': summary, 'live_dds_attested': False,
            'scope': 'offline evidence latency acceptance only'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--max-p95-ms', type=float, required=True)
    parser.add_argument('--min-samples', type=int, required=True)
    parser.add_argument('--max-mean-ms', type=float)
    parser.add_argument('--min-runs', type=int, default=1)
    parser.add_argument('--min-evidence-pairs', type=int, default=1)
    args = parser.parse_args()
    try:
        result = assess(args.directory, max_p95_ms=args.max_p95_ms,
                        min_samples=args.min_samples, max_mean_ms=args.max_mean_ms,
                        min_runs=args.min_runs, min_evidence_pairs=args.min_evidence_pairs)
    except (ValueError, OSError) as exc:
        result = {'status': 'fail', 'reason': 'invalid_input', 'detail': str(exc),
                  'live_dds_attested': False}
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    if result['status'] != 'pass':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
