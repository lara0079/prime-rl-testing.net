"""Deterministic message-transport emulator. Simulation only, no sockets or actuators."""
import argparse
import heapq
import json
import random
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from session import GovernedSession
from trained_integrated_lab import KEY

class SimulatedLink:
    """Seeded message delivery with packet loss, duplication, delay and partitions."""
    def __init__(self, seed=42, loss=0.1, duplicate=0.05, max_delay=3):
        if not 0 <= loss <= 1 or not 0 <= duplicate <= 1 or max_delay < 0:
            raise ValueError('invalid link parameters')
        self.rng = random.Random(seed)
        self.loss, self.duplicate, self.max_delay = loss, duplicate, max_delay
        self.queue = []
        self.sequence = 0
        self.stats = {'sent':0,'dropped':0,'delivered':0,'duplicates_queued':0}

    def send(self, payload, tick, connected=True):
        self.stats['sent'] += 1
        if not connected or self.rng.random() < self.loss:
            self.stats['dropped'] += 1
            return
        copies = 1 + int(self.rng.random() < self.duplicate)
        self.stats['duplicates_queued'] += copies - 1
        for _ in range(copies):
            delay = self.rng.randint(0, self.max_delay)
            self.sequence += 1
            heapq.heappush(self.queue, (tick + delay, self.sequence, payload))

    def receive(self, tick, connected=True):
        if not connected:
            return []
        result = []
        while self.queue and self.queue[0][0] <= tick:
            _, _, payload = heapq.heappop(self.queue)
            result.append(payload)
        self.stats['delivered'] += len(result)
        return result


def run(steps=600, seed=42, loss=0.15, duplicate=0.2, max_delay=4):
    if not isinstance(steps, int) or steps < 20:
        raise ValueError('steps must be >= 20')
    link = SimulatedLink(seed, loss, duplicate, max_delay)
    counters = {'steps':steps, 'offline_ticks':0, 'refresh_attempts':0,
                'refresh_accepted':0, 'refresh_rejected':0,
                'offline_inspect_proposals':0, 'offline_inspect_accepted':0,
                'expired_inspect_proposals':0, 'expired_inspect_accepted':0,
                'online_inspect_accepted':0, 'hold_accepted':0}
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        verifier = AuthorityVerifier({'lab': KEY}, 'lab-issuer', 'lab-node', replay_db=str(root/'replay.sqlite'))
        ledger = Ledger(root/'ledger.sqlite')
        session = GovernedSession(verifier, ledger)
        try:
            for tick in range(steps):
                # Scheduled partitions; transport itself may additionally drop packets.
                connected = tick % 70 < 40
                now = 100000.0 + tick
                if not connected:
                    counters['offline_ticks'] += 1
                if tick % 7 == 0:
                    token = sign({'kid':'lab','iss':'lab-issuer','aud':'lab-node',
                                  'nbf':now-1,'exp':now+12,
                                  'nonce':f'net-{seed}-{tick}',
                                  'permissions':['inspect']}, KEY)
                    link.send(token, tick, connected)
                for token in link.receive(tick, connected):
                    counters['refresh_attempts'] += 1
                    if session.refresh(token, now, connected):
                        counters['refresh_accepted'] += 1
                    else:
                        counters['refresh_rejected'] += 1
                # Forced inspection proposals include offline and stale-token conditions.
                snapshot = Snapshot(connected, 0.95 if connected else 0.0, 0.9, 0.9, True)
                result = session.decide(snapshot, 'inspect', now=now)
                if not connected:
                    counters['offline_inspect_proposals'] += 1
                    counters['offline_inspect_accepted'] += int(result['accepted'])
                elif session.expires_at is None or now >= session.expires_at:
                    counters['expired_inspect_proposals'] += 1
                    counters['expired_inspect_accepted'] += int(result['accepted'])
                else:
                    counters['online_inspect_accepted'] += int(result['accepted'])
                if not connected:
                    hold = session.decide(snapshot, 'hold', now=now)
                    counters['hold_accepted'] += int(hold['accepted'])
            counters['ledger_integrity'] = ledger.verify()
            counters['ledger_events'] = len(ledger.events())
        finally:
            ledger.close()
            verifier.close()
    return {'version':'v1.2', 'scope':'deterministic_transport_fault_simulation',
            'seed':seed, 'link':link.stats, 'metrics':counters,
            'limitations':'No real sockets, OS networking, trusted clock, robotics hardware, or physical safety validation.'}

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--steps',type=int,default=600)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--output',default='transport_report.json')
    args=parser.parse_args()
    report=run(args.steps,args.seed)
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
