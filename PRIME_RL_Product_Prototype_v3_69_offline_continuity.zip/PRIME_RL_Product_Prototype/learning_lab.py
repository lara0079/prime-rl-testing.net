"""Offline-only toy contextual Q-learning experiment, never connected to actuators."""
import argparse
import json
import random
from collections import defaultdict
from dataclasses import dataclass
from core import Runtime, Snapshot
from policy import Proposal

ACTIONS = ('inspect', 'hold', 'return', 'signal')

@dataclass(frozen=True)
class ToyObservation:
    connected: bool
    sensor_good: bool
    energy_good: bool

    def snapshot(self):
        return Snapshot(self.connected, 0.95 if self.connected else 0.0,
                        0.9 if self.sensor_good else 0.15,
                        0.9 if self.energy_good else 0.1, True)


def toy_reward(obs, action, accepted):
    # Synthetic reward is an experiment definition, not a real-world safety model.
    if not accepted:
        return -2.0
    if action == 'inspect':
        return 3.0 if obs.connected and obs.sensor_good and obs.energy_good else -3.0
    if action == 'return':
        return 1.0 if obs.energy_good and obs.sensor_good else -1.0
    if action == 'signal':
        return 0.3
    return 0.2


class TabularAgent:
    """One-step Q-learning / contextual bandit with epsilon-greedy exploration."""
    def __init__(self, seed=1, epsilon=0.2, alpha=0.15):
        self.rng = random.Random(seed)
        self.epsilon = epsilon
        self.alpha = alpha
        self.q = defaultdict(lambda: [0.0] * len(ACTIONS))

    def key(self, obs):
        return (obs.connected, obs.sensor_good, obs.energy_good)

    def propose(self, obs):
        values = self.q[self.key(obs)]
        if self.rng.random() < self.epsilon:
            idx = self.rng.randrange(len(ACTIONS))
        else:
            idx = max(range(len(ACTIONS)), key=lambda i: (values[i], -i))
        return Proposal(ACTIONS[idx], 'toy-tabular-q')

    def learn(self, obs, action, reward):
        i = ACTIONS.index(action)
        row = self.q[self.key(obs)]
        row[i] += self.alpha * (reward - row[i])


def observations(steps, seed):
    rng = random.Random(seed)
    for _ in range(steps):
        yield ToyObservation(rng.random() >= 0.35, rng.random() >= 0.15, rng.random() >= 0.12)


def run(steps=5000, seed=42, governed=True):
    if steps <= 0:
        raise ValueError('steps must be positive')
    agent = TabularAgent(seed=seed)
    runtime = Runtime()
    result = {'steps': steps, 'seed': seed, 'governed': governed,
              'accepted': 0, 'blocked': 0, 'offline_steps': 0,
              'offline_inspect_accepted': 0, 'cumulative_toy_reward': 0.0}
    for obs in observations(steps, seed + 1000):
        proposal = agent.propose(obs)
        snapshot = obs.snapshot()
        accepted = runtime.evaluate(snapshot, proposal.action)['accepted'] if governed else True
        if not obs.connected:
            result['offline_steps'] += 1
            if proposal.action == 'inspect' and accepted:
                result['offline_inspect_accepted'] += 1
        result['accepted' if accepted else 'blocked'] += 1
        reward = toy_reward(obs, proposal.action, accepted)
        result['cumulative_toy_reward'] += reward
        agent.learn(obs, proposal.action, reward)
    result['cumulative_toy_reward'] = round(result['cumulative_toy_reward'], 4)
    return result


def compare(steps=5000, seed=42):
    return {'experiment': 'synthetic contextual Q-learning; illustrative only',
            'ungoverned': run(steps, seed, False),
            'governed': run(steps, seed, True),
            'caveat': 'Different training trajectories; not a causal or physical-safety evaluation.'}

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--steps', type=int, default=5000)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--output', default='learning_report.json')
    args = p.parse_args()
    report = compare(args.steps, args.seed)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))
