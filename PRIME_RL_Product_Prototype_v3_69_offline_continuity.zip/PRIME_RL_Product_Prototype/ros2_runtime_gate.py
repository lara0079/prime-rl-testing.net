"""Fail-closed ROS advisory runtime, prototype only. No ROS imports or actuator output.

No mission token is loaded from telemetry, ROS parameters, or environment variables.
A separately authenticated local control plane must be implemented before mission
operations can be authorized in a deployed ROS node.
"""
import json
import stat
from pathlib import Path
from authority import AuthorityVerifier
from ledger import Ledger
from atomic_ledger import AtomicLedger
from ledger_checkpoint import verify_checkpoint
from session import GovernedSession
from ros2_governed_advisory import GovernedAdvisory


class AdvisoryRuntime:
    def __init__(self, ledger_path, checkpoint_path=None, *, atomic_ledger=False):
        if not ledger_path:
            raise ValueError('durable ledger path required')
        path = Path(ledger_path)
        if not path.parent.is_dir():
            raise ValueError('ledger parent directory must exist')
        # Reject symlink redirection and non-files before opening SQLite.
        if path.is_symlink():
            raise ValueError('symlink ledger path prohibited')
        if path.exists() and not stat.S_ISREG(path.stat().st_mode):
            raise ValueError('ledger must be a regular file')
        self.ledger = (AtomicLedger if atomic_ledger else Ledger)(path)
        # An existing invalid evidence chain must never be silently extended.
        # This is tamper detection only; a privileged attacker can rewrite the DB.
        try:
            if not self.ledger.verify():
                raise ValueError('ledger integrity verification failed')
            if checkpoint_path is not None and not verify_checkpoint(self.ledger, checkpoint_path):
                raise ValueError('ledger checkpoint mismatch or missing')
        except Exception:
            self.ledger.close()
            raise
        # Deliberately no keys: no untrusted ROS telemetry can grant authority.
        self.verifier = AuthorityVerifier({}, 'local', 'robot')
        self.session = GovernedSession(self.verifier, self.ledger)
        self.gate = GovernedAdvisory(self.session)

    def evaluate(self, payload, now_seconds):
        return json.dumps(self.gate.evaluate(payload, now_seconds=now_seconds),
                          sort_keys=True, allow_nan=False)

    def close(self):
        try:
            self.verifier.close()
        finally:
            self.ledger.close()
