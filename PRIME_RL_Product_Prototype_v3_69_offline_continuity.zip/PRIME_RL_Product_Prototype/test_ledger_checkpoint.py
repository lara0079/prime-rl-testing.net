import sqlite3
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from ledger_checkpoint import save_checkpoint, verify_checkpoint

class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'ledger.db'
        self.checkpoint = Path(self.tmp.name) / 'checkpoint.json'
        self.ledger = Ledger(self.path)
        self.addCleanup(self.ledger.close)

    def test_valid_head(self):
        self.ledger.append({'a': 1})
        save_checkpoint(self.ledger, self.checkpoint)
        self.assertTrue(verify_checkpoint(self.ledger, self.checkpoint))

    def test_tail_deletion_detected(self):
        self.ledger.append({'a': 1})
        self.ledger.append({'a': 2})
        save_checkpoint(self.ledger, self.checkpoint)
        with self.ledger.db:
            self.ledger.db.execute('DELETE FROM events WHERE seq=2')
        self.assertTrue(self.ledger.verify())  # limitation of hash chain alone
        self.assertFalse(verify_checkpoint(self.ledger, self.checkpoint))

    def test_checkpoint_missing(self):
        self.assertFalse(verify_checkpoint(self.ledger, self.checkpoint))

    def test_checkpoint_corrupted(self):
        save_checkpoint(self.ledger, self.checkpoint)
        self.checkpoint.write_text('not json')
        self.assertFalse(verify_checkpoint(self.ledger, self.checkpoint))

    def test_checkpoint_symlink_rejected(self):
        target = Path(self.tmp.name) / 'target'
        target.write_text('{}')
        self.checkpoint.symlink_to(target)
        with self.assertRaises(ValueError):
            save_checkpoint(self.ledger, self.checkpoint)
        self.assertFalse(verify_checkpoint(self.ledger, self.checkpoint))

if __name__ == '__main__': unittest.main()
