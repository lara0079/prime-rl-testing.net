"""Static CI evidence guarantees; not a substitute for an actual ROS 2 run."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent


class Ros2CiEvidenceContract(unittest.TestCase):
    def test_dds_logs_uploaded_even_on_failure(self):
        workflow = (ROOT / '.github/workflows/prime-rl-ros2.yml').read_text()
        self.assertIn('if: always()', workflow)
        self.assertIn('actions/upload-artifact@v4', workflow)
        self.assertIn('ros2-dds-smoke.log', workflow)

    def test_pipeline_propagates_failed_smoke_exit(self):
        workflow = (ROOT / '.github/workflows/prime-rl-ros2.yml').read_text()
        self.assertIn('set -o pipefail', workflow)
        self.assertIn('tee ros2-dds-smoke.log', workflow)

    def test_smoke_has_finite_runtime(self):
        script = (ROOT / 'run_ros2_container_smoke.sh').read_text()
        self.assertIn('timeout 90s python3 ros2_live_smoke.py --timeout 15', script)
        self.assertIn('--network none', script)


if __name__ == '__main__':
    unittest.main()
