import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from evidence_keyring import load_evidence_key
from evidence_auth import sign_evidence, verify_evidence
from ros2_repeatability import execute_repetitions


@unittest.skipUnless(os.name == 'posix', 'requires POSIX file permissions')
class EvidenceKeyringTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'secret.key'
        self.path.write_bytes(os.urandom(32))
        self.path.chmod(0o600)

    def test_owner_only_key_sign_and_verify(self):
        report = execute_repetitions(1, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': [1.0]}})
        key = load_evidence_key(self.path)
        self.assertTrue(verify_evidence(report, key, sign_evidence(report, key)))

    def test_reject_permissive_file(self):
        self.path.chmod(0o644)
        with self.assertRaises(ValueError):
            load_evidence_key(self.path)

    def test_reject_symlink(self):
        alias = Path(self.tmp.name) / 'alias.key'
        alias.symlink_to(self.path)
        with self.assertRaises(OSError):
            load_evidence_key(alias)

    def test_reject_short_and_oversized_keys(self):
        for content in (b'x' * 31, b'x' * 4097):
            with self.subTest(size=len(content)):
                self.path.write_bytes(content)
                with self.assertRaises(ValueError):
                    load_evidence_key(self.path)

    def test_reject_directory(self):
        with self.assertRaises(ValueError):
            load_evidence_key(self.tmp.name)

    def test_reject_unowned_key(self):
        with patch('evidence_keyring.os.geteuid', return_value=-1):
            with self.assertRaises(ValueError):
                load_evidence_key(self.path)


if __name__ == '__main__':
    unittest.main()
