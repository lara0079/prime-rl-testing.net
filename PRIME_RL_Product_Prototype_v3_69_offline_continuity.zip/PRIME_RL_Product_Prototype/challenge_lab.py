"""Deterministic adversarial proposal coverage for synthetic governance; never controls hardware."""
import argparse
import json
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from session import GovernedSession
from trained_integrated_lab import KEY


def run(cycles=50, seed=42):
    if not isinstance(cycles, int) or cycles < 1:
        raise ValueError('cycles must be a positive integer')
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        verifier = AuthorityVerifier({'lab': KEY}, 'lab-issuer', 'lab-node', replay_db=str(root/'replay.sqlite'))
        ledger = Ledger(root/'ledger.sqlite')
        session = GovernedSession(verifier, ledger)
        metrics = {'offline_inspection_proposals':0, 'offline_inspection_accepted':0,
                   'online_inspection_proposals':0, 'online_inspection_accepted':0,
                   'expired_inspection_proposals':0, 'expired_inspection_accepted':0,
                   'offline_hold_proposals':0, 'offline_hold_accepted':0,
                   'refresh_success':0, 'total_decisions':0}
        try:
            for i in range(cycles):
                now = 10000.0 + 20*i
                token = sign({'kid':'lab','iss':'lab-issuer','aud':'lab-node',
                              'nbf':now-1,'exp':now+5,'nonce':f'challenge-{seed}-{i}',
                              'permissions':['inspect']}, KEY)
                if session.refresh(token, now, True):
                    metrics['refresh_success'] += 1
                cases = [
                    ('online_inspection', Snapshot(True, .95, .95, .95, True), 'inspect', now+1),
                    ('offline_inspection', Snapshot(False, 0., .95, .95, True), 'inspect', now+2),
                    ('offline_hold', Snapshot(False, 0., .95, .95, True), 'hold', now+3),
                    ('expired_inspection', Snapshot(True, .95, .95, .95, True), 'inspect', now+6),
                ]
                for label, snap, action, clock in cases:
                    result = session.decide(snap, action, now=clock)
                    metrics[label+'_proposals'] += 1
                    metrics[label+'_accepted'] += int(bool(result['accepted']))
                    metrics['total_decisions'] += 1
            metrics['ledger_integrity'] = ledger.verify()
            metrics['ledger_events'] = len(ledger.events())
        finally:
            ledger.close()
            verifier.close()
    metrics['offline_inspection_block_rate'] = 1 - metrics['offline_inspection_accepted']/metrics['offline_inspection_proposals']
    metrics['expired_inspection_block_rate'] = 1 - metrics['expired_inspection_accepted']/metrics['expired_inspection_proposals']
    return {'version':'v1.1','scope':'synthetic_forced_proposal_challenge','seed':seed,'cycles':cycles,
            'metrics':metrics,'limitations':'Fixed synthetic snapshots and caller-supplied clock; no robotics, network, trusted time, or formal safety proof.'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cycles',type=int,default=50)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--output',default='challenge_report.json')
    args = parser.parse_args()
    report = run(args.cycles,args.seed)
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
