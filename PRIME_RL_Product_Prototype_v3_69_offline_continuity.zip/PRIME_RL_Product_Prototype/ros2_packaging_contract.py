"""Offline fail-closed consistency audit of ROS 2 package metadata (not a build)."""
import argparse
import ast
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def _literal_setup(path):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    calls = [n for n in tree.body if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
             and isinstance(n.value.func, ast.Name) and n.value.func.id == 'setup']
    if len(calls) != 1 or calls[0].value.args or any(k.arg is None for k in calls[0].value.keywords):
        raise ValueError('expected one literal setup(...) call')
    return {k.arg: ast.literal_eval(k.value) for k in calls[0].value.keywords}


def audit(root=None):
    root = Path(root) if root else Path(__file__).resolve().parent
    problems = []
    try:
        if (root / 'setup.py').is_symlink() or (root / 'package.xml').is_symlink():
            raise ValueError('symlinked metadata')
        setup = _literal_setup(root / 'setup.py')
        xml = ET.parse(root / 'package.xml').getroot()
        package = xml.findtext('name')
        version = xml.findtext('version')
        if not package or setup.get('name') != package:
            problems.append('package name mismatch')
        if not version or setup.get('version') != version:
            problems.append('package version mismatch')
        if xml.findtext('export/build_type') != 'ament_python':
            problems.append('build type is not ament_python')
        data_files = setup.get('data_files')
        if not isinstance(data_files, (list, tuple)):
            raise ValueError('missing literal data_files')
        installed = set()
        for destination, paths in data_files:
            for path in paths:
                installed.add(path)
        expected = {'package.xml', f'resource/{package}', 'launch/advisory.launch.py',
                    'launch/scenario.launch.py'}
        for rel in sorted(expected):
            path = root / rel
            if rel not in installed:
                problems.append(f'not packaged: {rel}')
            if path.is_symlink() or not path.is_file():
                problems.append(f'missing or symlinked: {rel}')
        modules = setup.get('py_modules')
        if not isinstance(modules, (list, tuple)):
            raise ValueError('missing literal py_modules')
        for module in modules:
            if not isinstance(module, str) or not module.isidentifier():
                problems.append('invalid module declaration')
            elif (root / f'{module}.py').is_symlink() or not (root / f'{module}.py').is_file():
                problems.append(f'missing or symlinked module: {module}')
        scripts = setup.get('entry_points', {}).get('console_scripts', [])
        for script in ('prime-rl-advisory', 'prime-rl-scenario'):
            matches = [s for s in scripts if isinstance(s, str) and s.split('=', 1)[0].strip() == script]
            if len(matches) != 1:
                problems.append(f'missing or duplicate console script: {script}')
                continue
            target = matches[0].split('=', 1)[1].strip().split(':', 1)
            if len(target) != 2 or target[0] not in modules or target[1] != 'main':
                problems.append(f'invalid console script target: {script}')
        for dep in ('rclpy', 'std_msgs'):
            if dep not in [x.text for x in xml.findall('exec_depend')]:
                problems.append(f'missing ROS dependency: {dep}')
    except (OSError, ValueError, SyntaxError, ET.ParseError, TypeError, KeyError) as exc:
        problems.append(f'metadata unreadable or nonliteral: {type(exc).__name__}: {exc}')
    return {'status': 'pass' if not problems else 'fail', 'problems': problems,
            'ros2_build_executed': False, 'dds_test_executed': False,
            'note': 'Static metadata consistency only; no ROS 2 build or execution.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args(argv)
    result = audit(args.root)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result['status'] == 'pass' else 2


if __name__ == '__main__':
    raise SystemExit(main())
