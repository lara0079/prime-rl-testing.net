# PRIME-RL: first actual ROS 2 DDS validation

This workflow is **prepared but has not been executed** in GitHub Actions. It is opt-in (`workflow_dispatch`) and should only be used in a **private repository**. It runs the full Python unittest suite and separately builds an isolated ROS 2 Jazzy Docker image, starts the advisory node, and runs the existing correlated DDS smoke probe.

## Use

1. Verify the GitHub repository is Private. Do not upload confidential material to a public repository.
2. Add the project files **at repository root** (including `.github/workflows/prime-rl-ros2.yml`, `Dockerfile.ros2`, and `run_ros2_container_smoke.sh`).
3. In GitHub Actions, select `PRIME-RL isolated ROS 2 smoke` and `Run workflow`.
4. Read the two job logs. Success of `ros2-dds-smoke` is evidence of a real ROS 2 DDS exchange inside the isolated container, not Gazebo or physical robot safety validation.

GitHub-hosted Actions may consume included usage minutes; verify account billing limits first. Docker image downloads require network access. No credentials are required by this workflow. The job intentionally does not connect to a physical robot.
