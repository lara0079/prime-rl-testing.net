"""Deterministic hostile-input evaluation of the ROS-independent advisory boundary.

No ROS 2 middleware, DDS, robot or physical actuation is exercised.
"""
import json
import random
from collections import Counter
from ros2_advisory_node import evaluate_payload

BASE = {'stamp_seconds': 100.0, 'gnss_quality': .9, 'odometry_quality': .9,
        'imu_quality': .9, 'map_freshness': 1.0, 'battery_fraction': .9,
        'connected': True}
FIELDS = tuple(BASE)
BAD_VALUES = [None, True, False, 'not-a-number', [], {}, -1, 2, float('nan'), float('inf')]


def run(seed=42, cases=1000):
    if not isinstance(cases, int) or isinstance(cases, bool) or cases < 1:
        raise ValueError('cases must be a positive integer')
    rng = random.Random(seed)
    outcomes = Counter()
    for index in range(cases):
        payload = BASE.copy()
        field = rng.choice(FIELDS)
        payload[field] = rng.choice(BAD_VALUES)
        # A bad value can accidentally be valid for an optional sensor field;
        # count its result rather than assuming every mutation is invalid.
        result = json.loads(evaluate_payload(json.dumps(payload), now_seconds=100.0))
        assert result['advisory_only'] is True
        assert isinstance(result['accepted'], bool)
        outcomes['accepted' if result['accepted'] else 'rejected'] += 1
        if result.get('reason') == 'invalid_telemetry':
            outcomes['schema_or_value_rejected'] += 1
    return {'seed': seed, 'cases': cases, 'outcomes': dict(sorted(outcomes.items())),
            'scope': 'pure Python JSON advisory boundary; not ROS 2/DDS or physical safety'}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2, sort_keys=True))
