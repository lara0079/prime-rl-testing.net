import json
import tempfile
import unittest
from pathlib import Path
from authority import AuthorityVerifier, sign
from ledger import Ledger
from session import GovernedSession
from ros2_governed_advisory import GovernedAdvisory
from ros2_contract_lab import BASE

class GovernedBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.verifier = AuthorityVerifier({'demo': b'k'*32}, 'local', 'robot', replay_db=str(Path(self.temp.name)/'replay.db'))
        self.addCleanup(self.verifier.close)
        self.ledger = Ledger(str(Path(self.temp.name)/'ledger.db'))
        self.addCleanup(self.ledger.close)
        self.session = GovernedSession(self.verifier, self.ledger)
        self.gate = GovernedAdvisory(self.session)
    def token(self, nonce='one', expiry=110):
        return sign({'kid':'demo','iss':'local','aud':'robot','nbf':90,'exp':expiry,'nonce':nonce,'permissions':['inspect']}, b'k'*32)
    def call(self, stamp=100, now=100, **changes):
        return self.gate.evaluate(json.dumps({**BASE, 'stamp_seconds':stamp, **changes}), now_seconds=now)
    def test_without_authority_denied(self):
        self.assertFalse(self.call()['accepted'])
    def test_valid_authority_allows_nominal(self):
        self.assertTrue(self.session.refresh(self.token(), 100, True))
        self.assertTrue(self.call()['accepted'])
        self.assertTrue(self.ledger.verify())
    def test_expiry_denies(self):
        self.session.refresh(self.token(expiry=101), 100, True)
        self.assertFalse(self.call(101,101)['accepted'])
    def test_offline_reconnect_requires_refresh(self):
        self.session.refresh(self.token(), 100, True)
        self.assertTrue(self.call()['accepted'])
        self.assertFalse(self.call(101,101,connected=False)['accepted'])
        self.assertFalse(self.call(102,102)['accepted'])
        self.assertTrue(self.session.refresh(self.token('two'),102,True))
        self.assertTrue(self.call(103,103)['accepted'])
    def test_duplicate_telemetry_denied(self):
        self.session.refresh(self.token(),100,True)
        self.assertTrue(self.call()['accepted'])
        self.assertEqual(self.call()['reason'],'replayed_or_out_of_order_telemetry')
    def test_stale_denied(self):
        self.session.refresh(self.token(),100,True)
        self.assertEqual(self.call(90,100)['reason'],'stale_or_future_telemetry')
    def test_clock_regression_requires_revalidation(self):
        self.session.refresh(self.token(),100,True)
        self.call(100,100)
        self.assertEqual(self.call(101,99)['reason'],'clock_regression')
        self.assertFalse(self.call(102,102)['accepted'])
    def test_duplicate_json_key_denied(self):
        self.session.refresh(self.token(),100,True)
        payload=json.dumps(BASE)[:-1]+', "connected": false}'
        self.assertEqual(self.gate.evaluate(payload,now_seconds=100)['reason'],'invalid_telemetry')
    def test_no_actuation_fields(self):
        self.session.refresh(self.token(),100,True)
        self.assertEqual(self.call(cmd_vel={'linear':2})['reason'],'invalid_telemetry')
    def test_bad_authority_rejected(self):
        self.assertFalse(self.session.refresh(self.token()+'x',100,True))
        self.assertFalse(self.call()['accepted'])
    def test_ledger_valid_after_denials(self):
        self.call()
        self.session.refresh(self.token(),100,True)
        self.call(100,100)
        self.call(100,100)
        self.assertTrue(self.ledger.verify())

if __name__ == '__main__': unittest.main()
