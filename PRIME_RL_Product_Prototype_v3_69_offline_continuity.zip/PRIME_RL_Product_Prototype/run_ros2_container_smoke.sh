#!/usr/bin/env bash
# Explicit opt-in. Requires Docker and permission to fetch ROS image; no physical actuators.
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then
  echo 'BLOCKED: Docker is not installed' >&2
  exit 2
fi
if [[ "${PRIME_RL_ALLOW_DOCKER:-}" != "YES" ]]; then
  echo 'BLOCKED: set PRIME_RL_ALLOW_DOCKER=YES to explicitly authorize Docker build/run' >&2
  exit 2
fi
docker build -f Dockerfile.ros2 -t prime-rl-jazzy-smoke:local .
# DDS loopback in a private container; not a Gazebo test and no actuator connection.
docker run --rm --network none --cap-drop ALL --security-opt no-new-privileges \
  --pids-limit 256 --memory 4g --cpus 2 \
  prime-rl-jazzy-smoke:local bash -lc '
  set -euo pipefail
  source /opt/ros/jazzy/setup.bash
  source /opt/prime_ws/install/setup.bash
  cd /opt/prime_ws/src/prime_rl_advisory
  python3 ros2_integration_preflight.py
  python3 ros2_advisory_node.py &
  node_pid=$!
  trap "kill $node_pid 2>/dev/null || true" EXIT
  sleep 3
  timeout 90s python3 ros2_live_smoke.py --timeout 15
  '
