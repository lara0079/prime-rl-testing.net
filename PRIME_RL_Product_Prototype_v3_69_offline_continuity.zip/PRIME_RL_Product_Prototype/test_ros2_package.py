"""Static packaging and safety-boundary checks; NOT ROS 2 runtime tests."""
import ast
import pathlib
import unittest
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parent


class TestROS2Packaging(unittest.TestCase):
    def test_package_metadata(self):
        package = ET.parse(ROOT / 'package.xml').getroot()
        self.assertEqual(package.findtext('name'), 'prime_rl_advisory')
        self.assertEqual(package.findtext('export/build_type'), 'ament_python')

    def test_resource_marker(self):
        self.assertTrue((ROOT / 'resource/prime_rl_advisory').is_file())

    def test_launch_is_parseable(self):
        ast.parse((ROOT / 'launch/advisory.launch.py').read_text())

    def test_entrypoint_matches_node(self):
        source = (ROOT / 'setup.py').read_text()
        self.assertIn('prime-rl-advisory = ros2_advisory_node:main', source)

    def test_no_actuator_topics(self):
        source = (ROOT / 'ros2_advisory_node.py').read_text()
        self.assertNotIn('/cmd_vel', source)
        self.assertNotIn('/joint_commands', source)
        self.assertIn("OUTPUT_TOPIC = '/prime_rl/advisory_json'", source)

    def test_required_dependencies(self):
        deps = [node.text for node in ET.parse(ROOT / 'package.xml').getroot().findall('exec_depend')]
        self.assertIn('rclpy', deps)
        self.assertIn('std_msgs', deps)


if __name__ == '__main__':
    unittest.main()
