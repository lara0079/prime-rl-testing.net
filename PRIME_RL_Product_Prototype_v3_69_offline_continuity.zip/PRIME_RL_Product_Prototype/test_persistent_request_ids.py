"""Durable advisory deduplication tests; do not require ROS 2."""
import json
import os
import tempfile
import unittest
import uuid
from persistent_request_ids import PersistentRequestIds
from ros2_advisory_node import evaluate_correlated


class Runtime:
    def __init__(self): self.calls = 0
    def evaluate(self, payload, *, now_seconds):
        self.calls += 1
        return json.dumps({'accepted': False, 'advisory_only': True, 'reason': 'invalid_telemetry'})


class PersistentReplayTests(unittest.TestCase):
    def test_survives_reopen(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'replay.sqlite')
            rid = str(uuid.uuid4())
            runtime = Runtime()
            payload = json.dumps({'request_id': rid, 'telemetry': 'invalid'})
            store = PersistentRequestIds(path)
            try:
                self.assertIn('request_id', json.loads(evaluate_correlated(runtime, payload, now_seconds=1, replay_cache=store)))
            finally: store.close()
            store = PersistentRequestIds(path)
            try:
                response = json.loads(evaluate_correlated(runtime, payload, now_seconds=2, replay_cache=store))
                self.assertEqual(response['reason'], 'duplicate_request_id')
                self.assertEqual(runtime.calls, 1)
            finally: store.close()

    def test_distinct_ids_and_no_eviction(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PersistentRequestIds(os.path.join(tmp, 'replay.sqlite'))
            try:
                first = str(uuid.uuid4())
                self.assertTrue(store.claim(first))
                for _ in range(4100): self.assertTrue(store.claim(str(uuid.uuid4())))
                self.assertFalse(store.claim(first))
            finally: store.close()

    def test_storage_failure_fails_closed(self):
        class Broken:
            def claim(self, rid): raise OSError('disk failure')
        runtime = Runtime()
        payload = json.dumps({'request_id': str(uuid.uuid4()), 'telemetry': '{}'})
        result = json.loads(evaluate_correlated(runtime, payload, now_seconds=1, replay_cache=Broken()))
        self.assertEqual(result['reason'], 'replay_store_unavailable')
        self.assertEqual(runtime.calls, 0)

    def test_memory_database_rejected(self):
        with self.assertRaises(ValueError): PersistentRequestIds(':memory:')
