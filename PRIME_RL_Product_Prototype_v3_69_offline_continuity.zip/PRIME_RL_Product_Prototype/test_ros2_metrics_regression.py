import tempfile
import unittest
from pathlib import Path
from ros2_metrics_regression import compare
from ros2_repeatability import execute_repetitions, write_evidence_pair


class RegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name) / 'base'
        self.next = Path(self.temp.name) / 'next'
        self.base.mkdir()
        self.next.mkdir()

    def evidence(self, directory, samples):
        report = execute_repetitions(1, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': samples}})
        write_evidence_pair(report, directory / 'run.evidence.json',
                            directory / 'run.manifest.json')

    def test_regression_pass(self):
        self.evidence(self.base, [10, 20, 30])
        self.evidence(self.next, [10, 20, 31])
        self.assertEqual(compare(self.base, self.next, max_p95_increase_pct=5,
                                 min_samples=3)['status'], 'pass')

    def test_regression_rejected(self):
        self.evidence(self.base, [10, 20, 30])
        self.evidence(self.next, [20, 40, 60])
        self.assertEqual(compare(self.base, self.next, max_p95_increase_pct=5,
                                 min_samples=3)['reason'], 'p95_regression')

    def test_missing_evidence_rejected(self):
        self.assertEqual(compare(self.base, self.next, max_p95_increase_pct=5,
                                 min_samples=1)['reason'], 'invalid_evidence')

    def test_insufficient_samples_rejected(self):
        self.evidence(self.base, [10])
        self.evidence(self.next, [10])
        self.assertEqual(compare(self.base, self.next, max_p95_increase_pct=5,
                                 min_samples=2)['reason'], 'insufficient_samples')

    def test_same_directory_rejected(self):
        self.evidence(self.base, [10, 20])
        with self.assertRaisesRegex(ValueError, 'different evidence directories'):
            compare(self.base, self.base, max_p95_increase_pct=5, min_samples=1)

    def test_overlapping_run_ids_rejected(self):
        import shutil
        self.evidence(self.base, [10, 20])
        for path in self.base.iterdir():
            shutil.copy2(path, self.next / path.name)
        result = compare(self.base, self.next, max_p95_increase_pct=5, min_samples=1)
        self.assertEqual(result['reason'], 'overlapping_run_ids')

    def test_independent_runs_allowed(self):
        self.evidence(self.base, [10, 20])
        self.evidence(self.next, [10, 20])
        self.assertEqual(compare(self.base, self.next, max_p95_increase_pct=0,
                                 min_samples=2)['status'], 'pass')

    def test_invalid_limits_rejected(self):
        for bad in (float('nan'), float('inf'), -1, True):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                compare(self.base, self.next, max_p95_increase_pct=bad, min_samples=1)
        with self.assertRaises(ValueError):
            compare(self.base, self.next, max_p95_increase_pct=0, min_samples=0)
