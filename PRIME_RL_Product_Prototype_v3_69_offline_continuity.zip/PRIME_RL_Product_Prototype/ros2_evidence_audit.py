"""Read-only batch audit of named ROS 2 evidence pairs; no DDS attestation.

Expected filenames: <stem>.evidence.json and <stem>.manifest.json.
No automatic deletion or repair is performed.
"""
import argparse
import json
from pathlib import Path

from ros2_evidence_pair_verify import verify_pair


def audit_directory(directory):
    root = Path(directory)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('audit target must be a real directory')
    groups = {}
    for path in root.iterdir():
        name = path.name
        if name.endswith('.evidence.json'):
            stem, role = name[:-len('.evidence.json')], 'evidence'
        elif name.endswith('.manifest.json'):
            stem, role = name[:-len('.manifest.json')], 'manifest'
        else:
            continue
        if not stem:
            groups.setdefault('', {})[role] = path
        else:
            groups.setdefault(stem, {})[role] = path
    records = []
    seen_ids = set()
    for stem, paths in sorted(groups.items()):
        evidence = paths.get('evidence', root / (stem + '.evidence.json'))
        manifest = paths.get('manifest', root / (stem + '.manifest.json'))
        valid, reason = verify_pair(evidence, manifest)
        if valid:
            try:
                record = json.loads(manifest.read_text(encoding='utf-8'))
                identifier = record['run_id']
                if identifier in seen_ids:
                    valid, reason = False, 'duplicate_run_id'
                else:
                    seen_ids.add(identifier)
            except (OSError, UnicodeError, ValueError, KeyError, TypeError):
                valid, reason = False, 'invalid_pair'
        records.append({'stem': stem, 'valid': valid, 'reason': reason})
    passed = sum(item['valid'] for item in records)
    return {'status': 'pass' if records and passed == len(records) else 'fail',
            'total': len(records), 'valid': passed, 'invalid': len(records) - passed,
            'pairs': records, 'live_dds_attested': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    try:
        report = audit_directory(args.directory)
    except ValueError as exc:
        report = {'status': 'fail', 'error': str(exc)}
    print(json.dumps(report, indent=2, sort_keys=True))
    if report['status'] != 'pass':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
