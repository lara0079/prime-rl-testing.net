import copy
import unittest
from ros2_run_manifest import create_manifest, verify_manifest


class ManifestTests(unittest.TestCase):
    def setUp(self):
        self.report = {'status': 'pass', 'requested_repetitions': 1, 'completed_repetitions': 1,
                       'runs': [{'iteration': 1, 'started_utc': '2026-10-19T00:00:00+00:00',
                                 'status': 'pass', 'round_trip_ms': [1.0]}],
                       'max_round_trip_ms': 1.0, 'live_dds_verified': False}

    def test_valid_manifest(self):
        self.assertTrue(verify_manifest(self.report, create_manifest(self.report)))

    def test_report_tamper_detected(self):
        manifest = create_manifest(self.report)
        changed = copy.deepcopy(self.report)
        changed['runs'][0]['round_trip_ms'] = [2.0]
        changed['max_round_trip_ms'] = 2.0
        self.assertFalse(verify_manifest(changed, manifest))

    def test_manifest_tamper_detected(self):
        manifest = create_manifest(self.report)
        manifest['live_dds_verified'] = True
        self.assertFalse(verify_manifest(self.report, manifest))

    def test_invalid_identity_rejected(self):
        with self.assertRaises(ValueError):
            create_manifest(self.report, run_id='not-a-uuid')

    def test_invalid_timestamp_rejected(self):
        with self.assertRaises(ValueError):
            create_manifest(self.report, created_utc='2026-10-19T00:00:00')


if __name__ == '__main__':
    unittest.main()
