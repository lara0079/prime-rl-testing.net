import fcntl
import os
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from ledger_migration import migrate_legacy_ledger
from migration_lock import migration_lock


class MigrationLockTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / 'events.db'
        self.backup = Path(self.tmp.name) / 'events.backup'
        db = Ledger(self.db)
        db.append({'test': 1})
        db.close()

    def test_lock_exclusion(self):
        with migration_lock(self.db):
            with self.assertRaisesRegex(RuntimeError, 'already held'):
                migrate_legacy_ledger(self.db, self.backup)
        self.assertFalse(self.backup.exists())

    def test_migration_succeeds_after_release(self):
        with migration_lock(self.db):
            pass
        self.assertEqual(migrate_legacy_ledger(self.db, self.backup)['events'], 1)

    def test_reject_symlink_lock(self):
        target = Path(self.tmp.name) / 'target'
        target.write_text('untouched')
        Path(str(self.db) + '.migration.lock').symlink_to(target)
        with self.assertRaises(ValueError):
            migrate_legacy_ledger(self.db, self.backup)
        self.assertEqual(target.read_text(), 'untouched')

    def test_external_lock_holder(self):
        path = str(self.db) + '.migration.lock'
        fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaises(RuntimeError):
                migrate_legacy_ledger(self.db, self.backup)
        finally:
            os.close(fd)

if __name__ == '__main__':
    unittest.main()
