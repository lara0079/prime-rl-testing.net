"""Deterministic, simulation-only fault-injection harness; never actuates hardware."""
import json
import math
import random
import statistics
import tempfile
import time
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from session import GovernedSession

DEMO_KEY = b'prime-rl-simulation-key-not-for-production'

def run_fault_campaign(seed=42, steps=1000, output=None):
    if not isinstance(steps, int) or steps < 10:
        raise ValueError('steps must be an integer >= 10')
    rng = random.Random(seed)
    with tempfile.TemporaryDirectory() as temp:
        verifier = AuthorityVerifier({'lab': DEMO_KEY}, 'lab', 'simulation', replay_db=str(Path(temp)/'nonces.sqlite'))
        ledger = Ledger(str(Path(temp)/'evidence.sqlite'))
        session = GovernedSession(verifier, ledger)
        now = 1000.0
        token_number = 0
        counts = {'accepted':0, 'rejected':0, 'offline_steps':0, 'offline_recovery_accepted':0,
                  'unauthorized_mission_acceptances':0, 'reconnect_events':0, 'refresh_successes':0,
                  'refresh_failures':0, 'expired_mission_acceptances':0}
        latency_ms = []
        previous_link = None
        for index in range(steps):
            # Deterministic bursts of packet loss/disconnection plus sensor and power degradation.
            phase = index % 100
            connected = phase < 30 or phase >= 70
            if rng.random() < .04:
                connected = False
            quality = (0.8 + rng.random()*.2) if connected else 0.0
            sensor = 0.15 if phase in range(40, 45) else 0.85
            energy = 0.12 if phase in range(55, 60) else 0.85
            if not connected:
                counts['offline_steps'] += 1
            if previous_link is False and connected:
                counts['reconnect_events'] += 1
            previous_link = connected
            # Refresh only at the beginning of some online windows; explicit, never automatic on reconnect.
            if connected and phase in (0, 72):
                token_number += 1
                payload = {'kid':'lab','iss':'lab','aud':'simulation','nbf':now-1,'exp':now+12,
                           'nonce':f'{seed}-{token_number}','permissions':['inspect']}
                ok = session.refresh(sign(payload, DEMO_KEY), now, connected=True)
                counts['refresh_successes' if ok else 'refresh_failures'] += 1
            action = 'inspect' if index % 3 == 0 else ('hold' if index % 3 == 1 else 'signal')
            snapshot = Snapshot(connected, quality, sensor, energy, True)
            started = time.perf_counter_ns()
            result = session.decide(snapshot, action, now=now)
            latency_ms.append((time.perf_counter_ns()-started)/1e6)
            counts['accepted' if result['accepted'] else 'rejected'] += 1
            if not connected and action in ('hold','signal') and result['accepted']:
                counts['offline_recovery_accepted'] += 1
            if action == 'inspect' and result['accepted'] and (not connected or session.revalidation_required or not (now < session.expires_at)):
                counts['unauthorized_mission_acceptances'] += 1
            if action == 'inspect' and result['accepted'] and session.expires_at is not None and now >= session.expires_at:
                counts['expired_mission_acceptances'] += 1
            now += 1
        valid = ledger.verify()
        events = len(ledger.events())
        ledger.close()
        verifier.close()
    ordered = sorted(latency_ms)
    def percentile(p):
        return round(ordered[math.ceil(p*(len(ordered)-1))], 6)
    report = {'release':'v0.5', 'mode':'deterministic_software_simulation_only', 'seed':seed,
              'steps':steps, **counts, 'ledger_valid':valid, 'ledger_events':events,
              'latency_ms':{'p50':percentile(.5),'p95':percentile(.95),'p99':percentile(.99),
                            'mean':round(statistics.mean(latency_ms),6)},
              'limitations':['simulated link and sensors, not real network or hardware',
                             'caller-supplied clock is not trusted time',
                             'illustrative action policy is not safety-certified',
                             'HMAC demonstration key is not production key management']}
    if output is not None:
        Path(output).write_text(json.dumps(report,indent=2), encoding='utf-8')
    return report

if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--steps',type=int,default=1000)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--output',default='fault_report.json')
    args=parser.parse_args()
    print(json.dumps(run_fault_campaign(args.seed,args.steps,args.output),indent=2))
