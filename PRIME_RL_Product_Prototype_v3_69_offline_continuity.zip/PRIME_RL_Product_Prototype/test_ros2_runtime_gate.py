"""ROS-independent integration tests for the actual node's advisory runtime."""
import json
from contextlib import closing
import sqlite3
import tempfile
import unittest
from pathlib import Path
from ros2_contract_lab import BASE
from ros2_runtime_gate import AdvisoryRuntime


class RuntimeGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'ledger.sqlite3'
        self.runtime = AdvisoryRuntime(self.path)
        self.addCleanup(self.runtime.close)

    def test_nominal_telemetry_cannot_grant_mission_authority(self):
        result = json.loads(self.runtime.evaluate(json.dumps(BASE), 100))
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'revalidation_required_or_not_permitted')

    def test_payload_cannot_supply_authority_token(self):
        result = json.loads(self.runtime.evaluate(json.dumps({**BASE, 'token':'forged'}), 100))
        self.assertEqual(result['reason'], 'invalid_telemetry')

    def test_local_ledger_persists_and_verifies(self):
        self.runtime.evaluate(json.dumps(BASE), 100)
        self.assertTrue(self.runtime.ledger.verify())
        self.assertGreater(len(self.runtime.ledger.events()), 0)

    def test_duplicate_telemetry_denied(self):
        self.runtime.evaluate(json.dumps(BASE), 100)
        result = json.loads(self.runtime.evaluate(json.dumps(BASE), 100))
        self.assertEqual(result['reason'], 'replayed_or_out_of_order_telemetry')

    def test_corrupted_ledger_refuses_restart(self):
        self.runtime.evaluate(json.dumps(BASE), 100)
        self.runtime.close()
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("UPDATE events SET payload=? WHERE seq=1", ('{"forged":true}',))
        with self.assertRaisesRegex(ValueError, 'ledger integrity'):
            AdvisoryRuntime(self.path)

    def test_missing_ledger_record_refuses_restart(self):
        self.runtime.evaluate(json.dumps(BASE), 100)
        newer = {**BASE, 'stamp_seconds': BASE['stamp_seconds'] + 1}
        self.runtime.evaluate(json.dumps(newer), 101)
        self.runtime.close()
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('DELETE FROM events WHERE seq=1')
        with self.assertRaisesRegex(ValueError, 'ledger integrity'):
            AdvisoryRuntime(self.path)

    def test_valid_ledger_allows_restart(self):
        self.runtime.evaluate(json.dumps(BASE), 100)
        self.runtime.close()
        reopened = AdvisoryRuntime(self.path)
        try:
            self.assertTrue(reopened.ledger.verify())
        finally:
            reopened.close()

    def test_no_ledger_path_rejected(self):
        with self.assertRaises(ValueError):
            AdvisoryRuntime('')

if __name__ == '__main__': unittest.main()
