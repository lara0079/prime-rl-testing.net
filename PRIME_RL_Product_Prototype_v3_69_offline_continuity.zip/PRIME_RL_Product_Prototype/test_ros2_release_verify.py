import tempfile
import unittest
from pathlib import Path
from ros2_release_verify import REQUIRED, verify_release_manifest
from ros2_validation_evidence import build_manifest


class ReleaseManifestTests(unittest.TestCase):
    def make_manifest(self, root):
        for name in REQUIRED:
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(name, encoding='utf-8')
        return build_manifest(root, readiness={'ros2_execution_ready': False}, timestamp='2026-01-01T00:00:00+00:00')

    def test_complete_manifest_passes(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.assertTrue(verify_release_manifest(self.make_manifest(root), root)['verified'])

    def test_missing_required_entry_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            m = self.make_manifest(root)
            del m['artifacts']['package.xml']
            self.assertFalse(verify_release_manifest(m, root)['verified'])

    def test_unexpected_artifact_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            m = self.make_manifest(root)
            m['artifacts']['extra.txt'] = {'present': True, 'sha256': '0'*64}
            self.assertFalse(verify_release_manifest(m, root)['verified'])

    def test_mutated_required_file_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            m = self.make_manifest(root)
            (root / 'setup.py').write_text('tampered', encoding='utf-8')
            self.assertFalse(verify_release_manifest(m, root)['verified'])
