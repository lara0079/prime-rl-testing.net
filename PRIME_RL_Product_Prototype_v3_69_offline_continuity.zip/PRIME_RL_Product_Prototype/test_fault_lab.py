import tempfile
import unittest
from pathlib import Path
from fault_lab import run_fault_campaign

class FaultLabTests(unittest.TestCase):
    def test_campaign_evidence_and_invariants(self):
        result=run_fault_campaign(42,1000)
        self.assertTrue(result['ledger_valid'])
        self.assertEqual(result['unauthorized_mission_acceptances'],0)
        self.assertEqual(result['expired_mission_acceptances'],0)
        self.assertGreater(result['offline_steps'],0)
        self.assertGreater(result['offline_recovery_accepted'],0)
        self.assertGreater(result['reconnect_events'],0)
    def test_reproducible_counts(self):
        a=run_fault_campaign(8,120)
        b=run_fault_campaign(8,120)
        for key in ('accepted','rejected','offline_steps','refresh_successes','ledger_events'):
            self.assertEqual(a[key],b[key])
    def test_json_output(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'report.json'
            self.assertEqual(run_fault_campaign(1,100,path)['steps'],100)
            self.assertTrue(path.exists())
    def test_invalid_steps(self):
        for n in (0,9,-1,3.5):
            with self.assertRaises(ValueError):run_fault_campaign(steps=n)
