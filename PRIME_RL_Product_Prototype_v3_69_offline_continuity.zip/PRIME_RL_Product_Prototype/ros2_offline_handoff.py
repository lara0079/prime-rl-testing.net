"""Produce an offline, truthful handoff manifest for future ROS 2 validation."""
import argparse
import hashlib
import json
from pathlib import Path

REQUIRED = ('package.xml', 'setup.py', 'ros2_advisory_node.py',
            'ros2_live_smoke.py', 'ros2_integration_preflight.py',
            'ros2_workspace_prepare.py', 'ROS2_VALIDATION_RUNBOOK.md')


def build_manifest(root):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('root must be a directory')
    missing = [name for name in REQUIRED if not (root / name).is_file() or (root / name).is_symlink()]
    if missing:
        raise ValueError('required files missing or symlinked: ' + ', '.join(missing))
    digests = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in REQUIRED}
    return {'schema_version': 1, 'purpose': 'offline ROS 2 handoff',
            'required_file_sha256': digests, 'static_files_verified': True,
            'ros2_runtime_verified': False, 'dds_messages_exchanged': False,
            'gazebo_simulation_verified': False, 'actuator_safety_verified': False,
            'next_action': 'Run ROS 2 preflight and isolated DDS smoke on a compatible host; record evidence.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    try:
        result = build_manifest(args.root)
        payload = json.dumps(result, indent=2, sort_keys=True) + '\n'
        if args.output:
            target = args.output.resolve()
            if target.exists() or target.is_symlink():
                raise FileExistsError('refusing to overwrite existing manifest')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('x', encoding='utf-8') as handle:
                handle.write(payload)
        else:
            print(payload, end='')
    except (OSError, ValueError) as exc:
        print(json.dumps({'status': 'blocked', 'reason': str(exc)}))
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
