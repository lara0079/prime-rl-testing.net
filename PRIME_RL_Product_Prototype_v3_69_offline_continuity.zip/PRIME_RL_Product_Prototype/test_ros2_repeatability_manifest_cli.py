"""Offline integration tests for evidence/manifest CLI pairing."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import ros2_repeatability
from ros2_run_manifest import verify_manifest


def fake_probe(**kwargs):
    return {'status': 'pass', 'timing': {'round_trip_ms': [2.0]}}


class RepeatabilityManifestCliTests(unittest.TestCase):
    def invoke(self, args):
        original = ros2_repeatability.execute_repetitions
        with patch.object(sys, 'argv', ['ros2_repeatability.py', *args]), \
             patch.object(ros2_repeatability, 'execute_repetitions') as execute:
            # Passing an explicit fake probe avoids pretending the test is live DDS.
            execute.side_effect = lambda *a, **kw: original(*a, **{**kw, 'probe': fake_probe})
            ros2_repeatability.main()

    def test_generates_matching_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            evidence, manifest = Path(d) / 'evidence.json', Path(d) / 'manifest.json'
            self.invoke(['--repetitions', '2', '--output', str(evidence), '--manifest-output', str(manifest)])
            report = json.loads(evidence.read_text())
            self.assertTrue(verify_manifest(report, json.loads(manifest.read_text())))
            self.assertFalse(report['live_dds_verified'])

    def test_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            evidence, manifest = Path(d) / 'evidence.json', Path(d) / 'manifest.json'
            manifest.write_text('keep')
            with self.assertRaises(SystemExit):
                self.invoke(['--output', str(evidence), '--manifest-output', str(manifest)])
            self.assertEqual(manifest.read_text(), 'keep')
            self.assertFalse(evidence.exists())

    def test_rejects_same_path(self):
        with tempfile.TemporaryDirectory() as d:
            path = str(Path(d) / 'both.json')
            with self.assertRaises(SystemExit):
                self.invoke(['--output', path, '--manifest-output', path])
            self.assertFalse(Path(path).exists())


class EvidencePairFailureTests(unittest.TestCase):
    def report(self):
        return ros2_repeatability.execute_repetitions(1, probe=fake_probe)

    def test_second_file_write_failure_rolls_back_first(self):
        import os
        with tempfile.TemporaryDirectory() as d:
            evidence, manifest = Path(d) / 'evidence.json', Path(d) / 'manifest.json'
            original_open = os.open
            def fail_manifest(path, flags, mode=0o777):
                if Path(path) == manifest:
                    raise OSError('simulated disk failure')
                return original_open(path, flags, mode)
            with patch.object(os, 'open', side_effect=fail_manifest):
                with self.assertRaises(OSError):
                    ros2_repeatability.write_evidence_pair(self.report(), evidence, manifest)
            self.assertFalse(evidence.exists())
            self.assertFalse(manifest.exists())

    def test_exclusive_creation_preserves_racing_manifest(self):
        import os
        with tempfile.TemporaryDirectory() as d:
            evidence, manifest = Path(d) / 'evidence.json', Path(d) / 'manifest.json'
            original_open = os.open
            def race_manifest(path, flags, mode=0o777):
                if Path(path) == manifest:
                    manifest.write_text('other process')
                return original_open(path, flags, mode)
            with patch.object(os, 'open', side_effect=race_manifest):
                with self.assertRaises(FileExistsError):
                    ros2_repeatability.write_evidence_pair(self.report(), evidence, manifest)
            self.assertFalse(evidence.exists())
            self.assertEqual(manifest.read_text(), 'other process')

    def test_successful_pair_is_private_and_verifiable(self):
        import os
        with tempfile.TemporaryDirectory() as d:
            evidence, manifest = Path(d) / 'evidence.json', Path(d) / 'manifest.json'
            ros2_repeatability.write_evidence_pair(self.report(), evidence, manifest)
            self.assertTrue(verify_manifest(json.loads(evidence.read_text()), json.loads(manifest.read_text())))
            if os.name == 'posix':
                self.assertEqual(evidence.stat().st_mode & 0o777, 0o600)
                self.assertEqual(manifest.stat().st_mode & 0o777, 0o600)
