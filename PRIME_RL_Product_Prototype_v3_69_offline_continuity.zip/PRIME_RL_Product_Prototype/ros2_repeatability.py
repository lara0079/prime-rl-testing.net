"""Repeated advisory-only ROS 2 smoke runs with machine-readable evidence.

Requires live ROS 2 for actual measurements. Never controls actuators.
"""
import argparse
import json
import math
from datetime import datetime, timezone

from ros2_live_smoke import run


def validate_evidence_report(report):
    """Validate structural and arithmetic consistency, not evidence authenticity."""
    if not isinstance(report, dict) or report.get('status') not in ('pass', 'fail'):
        raise ValueError('invalid evidence status')
    requested = report.get('requested_repetitions')
    completed = report.get('completed_repetitions')
    runs = report.get('runs')
    if (type(requested) is not int or not 1 <= requested <= 100
            or type(completed) is not int or not 1 <= completed <= requested
            or not isinstance(runs, list) or len(runs) != completed):
        raise ValueError('invalid evidence repetition counts')
    samples = []
    for index, item in enumerate(runs, 1):
        if (not isinstance(item, dict) or item.get('iteration') != index
                or not isinstance(item.get('started_utc'), str)):
            raise ValueError('invalid evidence run identity')
        try:
            timestamp = datetime.fromisoformat(item['started_utc'])
            if timestamp.utcoffset() is None:
                raise ValueError('timezone missing')
        except (ValueError, TypeError) as exc:
            raise ValueError('invalid evidence timestamp') from exc
        if item.get('status') == 'pass':
            values = item.get('round_trip_ms')
            if (not isinstance(values, list) or not values or any(
                type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in values
            )):
                raise ValueError('invalid evidence latency values')
            samples.extend(values)
        elif item.get('status') != 'fail' or index != completed:
            raise ValueError('invalid evidence run status')
    expected_pass = completed == requested and all(r['status'] == 'pass' for r in runs)
    if (report['status'] == 'pass') != expected_pass:
        raise ValueError('inconsistent evidence summary status')
    maximum = report.get('max_round_trip_ms')
    if (type(maximum) not in (int, float) and maximum is not None) or (
        maximum != (max(samples) if samples else None)
    ):
        raise ValueError('inconsistent evidence maximum latency')
    if type(report.get('live_dds_verified')) is not bool:
        raise ValueError('invalid live DDS verification flag')
    if report['live_dds_verified'] and not expected_pass:
        raise ValueError('failed evidence cannot claim live DDS verification')
    return True


def execute_repetitions(count=3, *, timeout=10.0, max_latency_ms=5000.0, probe=run):
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= 100:
        raise ValueError('repetitions must be an integer from 1 to 100')
    if (type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0
            or type(max_latency_ms) not in (int, float) or not math.isfinite(max_latency_ms)
            or max_latency_ms <= 0):
        raise ValueError('timeout and latency budget must be positive finite numbers')
    records = []
    for index in range(1, count + 1):
        started = datetime.now(timezone.utc).isoformat()
        try:
            outcome = probe(timeout=timeout, max_latency_ms=max_latency_ms)
            if not isinstance(outcome, dict) or outcome.get('status') != 'pass':
                raise ValueError('probe did not return a passing result')
            timing = outcome.get('timing')
            samples = timing.get('round_trip_ms') if isinstance(timing, dict) else None
            if not isinstance(samples, list) or not samples or any(
                isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                or v < 0 or v > max_latency_ms for v in samples
            ):
                raise ValueError('probe reported invalid or over-budget timing')
            records.append({'iteration': index, 'started_utc': started, 'status': 'pass',
                            'round_trip_ms': samples})
        except (ImportError, RuntimeError, TimeoutError, ValueError) as exc:
            records.append({'iteration': index, 'started_utc': started, 'status': 'fail',
                            'error_type': type(exc).__name__, 'error': str(exc)})
            break  # Fail closed: do not continue after a broken DDS run.
    all_samples = [v for item in records for v in item.get('round_trip_ms', [])]
    report = {'status': 'pass' if len(records) == count and all(r['status'] == 'pass' for r in records) else 'fail',
            'requested_repetitions': count, 'completed_repetitions': len(records),
            'max_round_trip_ms': max(all_samples) if all_samples else None,
            'metric': 'local publish-to-correlated-advisory elapsed time; not one-way DDS latency',
            'live_dds_verified': probe is run and len(records) == count and all(r['status'] == 'pass' for r in records),
            'runs': records}
    validate_evidence_report(report)
    return report


def write_evidence_pair(report, evidence_path, manifest_path):
    """Create a non-overwriting evidence pair; roll back on handled I/O failures.

    Two independent files cannot be made crash-atomic with ordinary filesystem
    operations. Consumers must reject missing or non-matching pairs.
    """
    import os
    from pathlib import Path
    from ros2_run_manifest import create_manifest
    evidence, manifest = Path(evidence_path), Path(manifest_path)
    if evidence.resolve() == manifest.resolve():
        raise ValueError('evidence and manifest paths must differ')
    if evidence.exists() or manifest.exists() or evidence.is_symlink() or manifest.is_symlink():
        raise FileExistsError('refusing to overwrite existing evidence or manifest')
    payloads = (
        (evidence, json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n'),
        (manifest, json.dumps(create_manifest(report), indent=2, sort_keys=True, allow_nan=False) + '\n'),
    )
    created = []
    try:
        for path, content in payloads:
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            if hasattr(os, 'O_NOFOLLOW'):
                flags |= os.O_NOFOLLOW
            fd = os.open(path, flags, 0o600)
            created.append(path)
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
    except BaseException:
        for path in reversed(created):
            path.unlink(missing_ok=True)
        raise
    return evidence, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repetitions', type=int, default=3)
    parser.add_argument('--timeout', type=float, default=10.0)
    parser.add_argument('--max-latency-ms', type=float, default=5000.0)
    parser.add_argument('--output', help='optional JSON evidence output path')
    parser.add_argument('--manifest-output', help='optional separate run manifest path (requires --output)')
    args = parser.parse_args()
    if args.manifest_output and not args.output:
        parser.error('--manifest-output requires --output')
    if args.manifest_output:
        from pathlib import Path
        if Path(args.output).resolve() == Path(args.manifest_output).resolve():
            parser.error('evidence and manifest paths must differ')
        if Path(args.output).exists() or Path(args.manifest_output).exists():
            parser.error('refusing to overwrite existing evidence or manifest')
    try:
        result = execute_repetitions(args.repetitions, timeout=args.timeout, max_latency_ms=args.max_latency_ms)
    except ValueError as exc:
        result = {'status': 'fail', 'error_type': 'ValueError', 'error': str(exc)}
    payload = json.dumps(result, indent=2, sort_keys=True, allow_nan=False)
    if args.output:
        from pathlib import Path
        if args.manifest_output:
            if not set(('requested_repetitions', 'runs')).issubset(result):
                raise ValueError('cannot create manifest for structurally invalid report')
            write_evidence_pair(result, args.output, args.manifest_output)
        else:
            Path(args.output).write_text(payload + '\n', encoding='utf-8')
    print(payload)
    if result['status'] != 'pass':
        raise SystemExit(2)


if __name__ == '__main__':
    main()


def evidence_sha256(report):
    """Deterministic integrity digest; not a digital signature or proof of origin."""
    import hashlib
    validate_evidence_report(report)
    canonical = json.dumps(report, sort_keys=True, separators=(',', ':'),
                           ensure_ascii=False, allow_nan=False).encode('utf-8')
    return hashlib.sha256(canonical).hexdigest()


def verify_evidence_digest(report, expected_digest):
    """Compare an externally retained digest against a report, fail closed."""
    import hmac
    if not isinstance(expected_digest, str) or len(expected_digest) != 64 or any(
            c not in '0123456789abcdef' for c in expected_digest):
        raise ValueError('invalid SHA-256 digest')
    return hmac.compare_digest(evidence_sha256(report), expected_digest)
