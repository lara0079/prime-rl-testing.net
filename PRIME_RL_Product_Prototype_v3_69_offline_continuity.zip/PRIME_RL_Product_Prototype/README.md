# PRIME-RL Persistent Autonomy: simulation prototype v0.2

**Status:** local software simulation. Not validated for real robots, autonomous actuation, critical infrastructure, or safety-critical use. No cryptographic mission authority verification, no trained RL model, no hardware integration, no remote service, and no production security claims.

This package extends the existing v0.1 `core.py` rather than replacing it. The thresholds and action masks in `core.py` are *illustrative demonstration values*, not original/proprietary decision logic. The source remains local and private unless its owner chooses to share it.

## Run

Requires Python 3.10+; standard library only.

```bash
python -m unittest discover -v
python demo.py --db prime_rl_demo.sqlite3 --iterations 10000
```

## What's implemented

- Existing v0.1 simulation-only deterministic runtime and action filtering.
- SQLite local durable event ledger, sequential hash-chain verification, and tamper detection for simple edits/deletions. This is **tamper-evident, not tamper-proof**; a privileged adversary can rewrite the entire database and hashes.
- Repeatable simulated connection loss, expiry, recovery/hold, and stale-authority rejection demo.
- Scenario accuracy and decision latency p50/p95/p99 benchmark, based on Python's local timing.
- Automated tests for persistence, tampering, metrics, and v0.1 behavior.

## Product gaps (not implemented)

- Signed, replay-resistant mission envelopes with trusted clock and key rotation.
- Complete authority decomposition, confidence fusion, and survival constraint formalization.
- Explicit revalidation handshake after reconnection.
- Integration with ROS 2/Gazebo, RL policy, sensors, real networking and hardware.
- Realistic fault-injection workloads, adversarial security assessment, and physical safety validation.
- Operator dashboard, installer, service lifecycle, secure sync, release engineering, licensing.

## Metric interpretation

The metric `unexpected_acceptances` counts deviations from **the 8 hard-coded demo scenario expectations**. Zero here does not prove zero unsafe decisions in the real world. Performance varies by computer and load.

## v0.3 experimental additions (2026-10-18)

- `authority.py`: illustrative HMAC-SHA256 signed authority tokens, scoped claims, validity windows, and in-memory nonce replay checks. This is **not** production PKI, hardware trust, trusted time, or restart-resistant replay protection.
- `session.py`: simulated permission gating and explicit refresh after link transitions. The existing `core.py` remains unchanged.
- `test_authority.py`: six additional tests for signature, scope, expiry-at-verification, replay, permission claims, and reconnect behavior.
- **Known limitation:** the session does not continuously re-check authority expiration at every action. It therefore MUST NOT be used for physical actuation or security decisions. A production version needs a trusted clock, continuous expiry enforcement, durable replay protection, crash-safe lifecycle, key rotation, and independent safety verification.
- No network connections, cloud dependencies, robotic actuators, or external disclosures are made.

Run: `python -m unittest discover -v`

## v0.4 hardening (2026-10-18)

- Optional SQLite-backed atomic replay nonce consumption (`AuthorityVerifier(..., replay_db=...)`) survives process restarts. For durable replay defense, applications **must** configure a persistent replay database.
- `GovernedSession.decide(..., now=...)` requires an explicit finite clock reading for mission decisions and checks expiration **at every decision**. Missing clock fails closed. This is caller-provided time, **not a trusted hardware clock**.
- Expiry causes revalidation to remain required; rollback of caller-provided time does not restore authorization in the same session. Restart-safe session persistence and trusted monotonic time remain open product gaps.
- The local recovery actions are still subject to the demonstration safety core.
- This is a software simulation only; do not connect to physical actuators.

## v0.5 deterministic fault campaign (2026-10-18)

- `fault_lab.py` runs reproducible, seeded simulations of burst disconnections, intermittent loss, reconnects, degraded sensors and low energy.
- `test_fault_lab.py` adds four regression tests (25 total), checking audit continuity, no unauthorized mission approvals under simulated faults, offline recovery and reproducibility.
- Run `python fault_lab.py --steps 10000 --seed 42 --output fault_report.json` to regenerate a locally measured JSON report. Timing measurements are machine-specific; counts are scenario-specific.
- **Important:** This does not implement real packet transport, sensor hardware, ROS 2, trusted clock, session crash recovery, hardware actuation or trained RL. Never treat zero violations in this simulation as a safety guarantee.

## v0.6 crash/restart and policy interface (2026-10-18)

- `lifecycle.py` adds SQLite WAL/FULL-synchronous session epoch tracking. Every fresh process opening a lifecycle store increments its epoch and **requires a new authorization refresh**. It does not restore live permissions from disk.
- `session.py` accepts optional `lifecycle=LifecycleStore(path)`; this is **opt-in** for existing callers. For crash/restart hardening configure this alongside the persistent replay DB. Existing callers without it retain the earlier behavior.
- `policy.py` defines a minimal `Proposal` and `GovernedPolicy` wrapper. A policy proposes an action but the existing governance gate decides whether to accept it. `FixedPolicy` is illustrative, **not a trained RL model**.
- `test_lifecycle.py` adds three tests; 28 tests pass in the local simulation environment.
- Caveats: no trusted clock, hardware-backed trust, formal safety proof, network transport, real RL training, ROS2 or actuation. The lifecycle store is not resistant to privileged disk tampering, and concurrent processes require additional coordination. Never use this prototype to drive real hardware.

## v0.7 synthetic learning laboratory (2026-10-18)

- `learning_lab.py`: reproducible offline contextual one-step Q-learning toy experiment; compares unconstrained policy proposals with proposals filtered through the **existing** illustrative `Runtime` gate. No new proprietary policy rules have been introduced.
- `test_learning_lab.py`: five additional regression checks, including reproducibility and prevention of offline `inspect` acceptance by the simulated gate.
- `learning_report.json`: seed-42 experiment results for 5,000 simulated decisions per arm. The learning trajectories differ between arms, so this is **not** a controlled causal evaluation, real robotics benchmark, or proof of safety.
- Run `python learning_lab.py --steps 5000 --seed 42 --output learning_report.json` and `python -m unittest discover -v`.
- The existing `GovernedSession` and token verification path are **not** exercised by this toy learning experiment; it uses `core.Runtime` directly. Real agent integration with mission-authority lifecycle, trusted clocks, hardware and ROS2 remains outstanding.

## v0.8 paired synthetic evaluation (2026-10-18)

- `paired_evaluation.py` fixes the observation/proposal sequence for the governed and ungoverned counterfactual arms, avoiding the unequal-training-trajectory problem of v0.7. The proposal source is uniformly random, not a trained RL policy.
- `paired_evaluation_report.json` contains per-seed results for 30 seeds x 1,000 synthetic decisions, with Wilson intervals for the toy blocked-action and observed-offline-inspection fractions.
- `test_paired_evaluation.py` adds five tests; the full local suite passes 38 tests.
- This experiment does **not** establish production safety, RL efficacy, causal field performance, or certification. The ungoverned baseline is an intentionally permissive simulated counterfactual, not a realistic robot controller.
- Run `python paired_evaluation.py --seeds 30 --steps 1000 --output paired_evaluation_report.json` and `python -m unittest discover -q`.

## v0.9 integrated synthetic authority lab (2026-10-18)

- `integrated_lab.py` connects the existing signed-envelope verifier, durable replay database, `GovernedSession`, original deterministic action gate, and persistent ledger in a single reproducible scenario. It simulates repeated disconnections, reconnections, sensor confidence drops, and energy constraints.
- `test_integrated_lab.py` adds five integration tests, bringing the local test suite to 43 tests.
- `integrated_report.json` is the seed-42, 3,000-step synthetic result. Metrics describe only this laboratory model; they do not represent deployed reliability, real RL, hardware actuation, or cryptographic production assurance.
- This experiment uses random action proposals, **not a trained RL model**, and it is not a real network fault emulator.
- Run `python integrated_lab.py --steps 3000 --seed 42 --output integrated_report.json` and `python -m unittest discover -q`.

## v1.0 trained toy-policy integrated evaluation (2026-10-18)

- `trained_integrated_lab.py` trains a tabular toy policy on synthetic observations, then evaluates its proposed actions through the existing signed-token `GovernedSession` and persistent audit ledger.
- `test_trained_integrated_lab.py` adds six tests; 49 local unit tests pass.
- `trained_integrated_report.json` records a seeded 8,000-step training and 3,000-step evaluation run.
- Important evaluation limitation: the trained policy generated **zero offline inspection proposals**, so the `offline_mission_accepted=0` metric is vacuous in this run and is **not** evidence of successful blocking of offline mission proposals. Earlier randomized integrated tests provide separate coverage of that case.
- The agent is a small tabular contextual learner, not a deep RL agent. This is not a robotics deployment, validated safety controller, or commercially ready product.

Run: `python trained_integrated_lab.py --output trained_integrated_report.json` and `python -m unittest discover -q`.

## v1.1 forced-proposal challenge (2026-10-18)

- `challenge_lab.py` explicitly injects mission proposals during simulated disconnection and after token expiry. This closes the **test coverage gap** in v1.0, where the trained toy policy happened to make no offline inspection proposals.
- It also verifies that online authorized inspection and offline recovery hold are possible in the toy environment, to distinguish selective gating from blanket rejection.
- `test_challenge_lab.py` adds six regression tests. Total: 55 passing locally.
- `challenge_report.json` contains 100 cycles (400 decisions), including 100 forced offline inspection proposals and 100 expired inspection proposals, both with zero accepted in this **fixed synthetic scenario**. The report is not a safety certification.
- Run `python challenge_lab.py --cycles 100 --output challenge_report.json` and `python -m unittest discover -q`.
- Remaining blockers: trusted time, physical robotics simulation, actual networking, ROS 2, independently assessed safety, threat modeling, secure deployment and field validation.

## v1.2 deterministic transport fault emulator (2026-10-18)

- `transport_lab.py` adds seeded message delivery with packet loss, partitions, latency, reordering and duplicate deliveries; exercises the **existing** token verifier, session gate and SQLite evidence ledger.
- `test_transport_lab.py` adds six regression tests; total 61 local tests pass.
- `transport_report.json` records the seeded 600-tick campaign. Offline inspection proposals: 240, accepted: 0; expired inspection proposals: 120, accepted: 0; offline hold accepted: 240; ledger verified.
- `python transport_lab.py --steps 600 --seed 42 --output transport_report.json` reproduces the deterministic counts.
- This is **message-transport emulation**, not real OS sockets, network hardware, ROS 2/Gazebo, trusted time, or physical robotics validation. Packet delivery is modeled by an in-memory event queue. Results are synthetic and do not establish operational safety.

## v1.3 synthetic localization degradation laboratory (2026-10-18)

- `navigation_lab.py` adds a deterministic, **synthetic** GNSS/odometry/IMU availability and map-freshness degradation campaign, reusing the existing `core.Runtime` decision gate without modifying its illustrative rules.
- `test_navigation_lab.py` adds six tests; 67 tests pass locally.
- `navigation_report.json` records 1,000 synthetic steps (seed 42). There were 204 low-confidence return proposals, zero accepted; 160 offline hold proposals, all accepted. These numbers are only about the toy scenario.
- Confidence is deliberately conservative but **not calibrated**. A numeric confidence score is not evidence of localization correctness. The experiment does not implement sensor fusion, ROS 2, Gazebo, SLAM, a trusted clock, real hardware, or safety certification. Never connect this prototype to actuators.
- Run `python navigation_lab.py --steps 1000 --seed 42 --output navigation_report.json` and `python -m unittest discover -q`.

## v1.4 ROS 2 boundary preparation (2026-10-18)

- `ros_bridge.py` adds a **read-only, ROS-like telemetry adapter** with an advisory decision output, explicit stale/future timestamp rejection, finite-value validation and conservative missing-sensor handling.
- `test_ros_bridge.py` adds eight tests; total 75 tests pass locally.
- The adapter deliberately has **no actuator publisher, command topic, ROS node or physical robot connection**. ROS 2 / Gazebo are not installed in this environment; this is preparation for a future integration, not a claim of ROS/Gazebo execution.
- Timestamps are untrusted caller inputs and the illustrative decision core is not safety certified. An actual deployment requires validated clock synchronization, message schemas, ROS 2 node integration, simulated robot and physical safety review.

## v1.5 optional ROS 2 advisory node (2026-10-18)

- `ros2_advisory_node.py` provides a real `rclpy` node **implementation** with a `std_msgs/String` JSON telemetry subscriber (`/prime_rl/telemetry_json`) and a separate **advisory-only** publisher (`/prime_rl/advisory_json`). It does not publish motor or navigation commands.
- `evaluate_payload` is ROS-independent and fail-closed on malformed JSON, schema drift, invalid telemetry, and stale/future samples. Eight new unit tests exercise this boundary.
- With ROS 2 installed, launch from this source directory with `python ros2_advisory_node.py`; the sender must supply all `RobotTelemetry` fields in JSON and ROS-clock-compatible `stamp_seconds`. **Do not connect advisory output to any actuator or motion control node.**
- The node was **not executed in ROS 2/Gazebo here**, because those dependencies and a simulated robot are not available. Unit tests verify only the pure adapter and import path, not DDS, ROS clock, QoS, or integration behavior.
- The JSON String protocol and clock assumptions are demonstrator-only; production requires typed messages, trust-boundary validation, real transport testing and robotics safety assessment.

## v1.6 ROS 2 ament_python packaging (2026-10-18)

- Added `package.xml`, `setup.py`, `setup.cfg`, `resource/prime_rl_advisory` and `launch/advisory.launch.py` for optional `colcon build --packages-select prime_rl_advisory` and `ros2 launch prime_rl_advisory advisory.launch.py` when installed into a ROS 2 workspace `src/prime_rl_advisory`.
- ROS 2 node remains advisory-only and never publishes actuator commands. JSON transport, clock trust, and QoS require real ROS 2 integration tests before use.
- Added six static packaging/safety regression tests; these **do not** prove that `colcon build`, DDS messaging, or Gazebo works. ROS 2 is not installed here.

## v1.7 synthetic ROS 2 scenario node (2026-10-18)

- `ros2_scenario.py` publishes a deterministic five-phase **synthetic telemetry** cycle: nominal, GNSS loss, disconnected, stale timestamp, recovery. The output is consumed by the existing advisory-only node, never by motion controllers.
- `launch/scenario.launch.py` launches both optional nodes in a ROS 2 environment. `setup.py` installs the new console entry point and launch file.
- Seven new pure-Python tests exercise phase generation and the advisory boundary; **96 tests pass locally**. No ROS 2 installation, DDS integration, Gazebo simulation or physical robot test was performed here.
- In a compatible ROS 2 workspace: `colcon build --packages-select prime_rl_advisory`, source `install/setup.bash`, then `ros2 launch prime_rl_advisory scenario.launch.py`. Observe `/prime_rl/advisory_json` only. The scenario does not move a robot and cannot demonstrate navigation performance or hardware safety.

### v1.8: scripted 2D robot trace laboratory
`python robot_trace_lab.py` produces `robot_trace_report.json` with deterministic scripted 2D position and synthetic localization error under five fault phases. Each observation passes through the read-only `ros_bridge.assess` boundary. **Important integration gap:** this advisory adapter supplies `authority_valid=False` to the illustrative core; consequently even nominal return proposals fail closed. This is not evidence of successful authorized navigation. A future adapter must integrate a validated mission authority and its lifecycle, without bypassing safety gates. No Gazebo, robot dynamics, or real-world validation was run.

## v1.9: Signed-authority synthetic robot advisory

`authorized_robot_lab.py` combines deterministic robot-like localization telemetry,
illustrative signed mission authorization, reconnection revalidation, fail-closed
stale telemetry rejection, and the persistent local event ledger. Run with
`python authorized_robot_lab.py`; see `authorized_robot_report.json`.
The 500-step default scenario admits nominal/recovery inspection when authorized,
rejects GNSS-degraded inspection, and permits offline safe hold. This is not a
ROS 2/Gazebo run and does not actuate hardware. Demo HMAC key and time source
are unsuitable for deployment. All results are synthetic and non-certifying.

### v2.0 authority continuity stress lab
`python continuity_lab.py` runs repeatable, synthetic authority-continuity cycles
covering replay rejection, offline denial, safe hold, reconnect revalidation,
expiry and process restart. `test_continuity_lab.py` adds regression tests.
This is not a hardware, ROS/Gazebo or real-time security validation.

### v2.1 — Compound-fault regression campaign
`compound_fault_lab.py` runs deterministic multi-fault scenarios combining disconnection, sensor/energy degradation, integrity failure, authority expiry, reconnection and process restart. Run `python compound_fault_lab.py` to generate `compound_fault_report.json`; run `python -m unittest discover -q` for regression tests. This is synthetic software-only evaluation. It does not run ROS 2/Gazebo, actuate a robot, validate a trusted clock or certify safety. Demo keys and illustrative policies must never be deployed.

### v2.2 — ROS advisory contract robustness campaign
`ros2_contract_lab.py` runs a deterministic 1,000-case value-mutated telemetry campaign against the pure-Python JSON advisory boundary. `test_ros2_contract_lab.py` adds six regression tests; 117 tests pass locally. Some mutations are valid by schema; accepted decisions are counted rather than incorrectly labelled failures. This is not ROS 2 middleware execution, DDS, Gazebo, robot control, production security validation, or safety certification.

### v2.3 — strict ROS advisory JSON intake
The ROS advisory node now routes incoming JSON through `strict_advisory`, rejecting duplicate keys, oversized messages, non-standard NaN/Infinity, non-object inputs and unexpected command fields. Eight new regression tests; 125 Python tests pass. This is a read-only advisory boundary, not an authority-bearing execution gate. ROS 2/Gazebo integration and real-robot validation have not been run.

### v2.4 — Governed ROS-independent advisory boundary
`ros2_governed_advisory.py` connects strict telemetry validation to a signed,
replay-checked mission authorization session and persistent decision ledger.
Ten new regression tests cover valid and absent authority, expiry, reconnect,
telemetry replay, stale input, clock regression, duplicate JSON fields, command
injection fields, invalid signatures, and ledger integrity. Full suite: 136 tests.
The token must be provisioned on a separate trusted local control path; the
telemetry channel cannot grant authority. The example uses HMAC and an
illustrative policy, not production credentials or certified safety logic.
This is a pure-Python test boundary, not an executed ROS 2 middleware/Gazebo
integration. No actuator output is implemented.

### v2.5: ROS node uses fail-closed governed advisory boundary
The actual optional ROS 2 subscriber now invokes `AdvisoryRuntime`, which uses
`GovernedAdvisory` and a SQLite event ledger rather than the earlier sensor-only
`strict_advisory` path. No trusted authorization control plane exists yet; the
node deliberately starts with no verification keys, and therefore cannot authorize
mission inspection. `PRIME_RL_LEDGER_PATH` can select a ledger location; the default
`/tmp` path is **not** suitable for a persistent production audit trail. Five
new integration tests cover default denial, token injection rejection, persistent
logging, replayed telemetry and invalid paths. 141 Python tests pass. No ROS 2,
DDS, Gazebo or hardware execution was performed; no actuator interface exists.

### v2.6 — Advisory ledger path checks
Reject symlink and non-regular ledger paths before SQLite open, including dangling symlinks. Added five regression tests; 146 Python unit tests passed. This is not race-free filesystem hardening, authenticated provisioning, ROS 2/Gazebo execution, or safety certification.

## v2.7 — fail-closed evidence-chain startup (2026-10-18)
- ROS advisory runtime verifies existing SQLite hash chain on startup and refuses to run with altered or missing event records.
- Three new regression tests: altered payload, missing event, valid restart. 149 Python tests pass.
- Hash chains are tamper-evident only, not tamper-proof against privileged attackers. No ROS 2/Gazebo runtime test.

## v2.8: Local ledger-head checkpoint experiment

Added `ledger_checkpoint.py` and five regression tests. The checkpoint detects deletion of a trailing ledger event that would otherwise leave a locally valid hash chain. The checkpoint is a separate local file and is **not** a trusted external anchor; an attacker with write access to both files can rewrite both. Crash consistency between a ledger append and a checkpoint update remains an integration issue. This experimental checkpoint is not yet wired into the ROS runtime. Python unittest: 154 tests passed. No ROS 2/Gazebo runtime testing.

## v2.9 — checkpoint-verified restart
AdvisoryRuntime supports optional checkpoint_path and refuses startup on missing, corrupted or inconsistent checkpoints. Four additional tests cover valid restart, tail deletion, missing checkpoint and corruption; 158 tests pass. Checkpoint enforcement is opt-in and writes are not yet atomic with event insertion. No ROS 2/Gazebo execution was performed.

## v3.0 — SQLite-atomic ledger head (experimental)

`atomic_ledger.py` implements an opt-in SQLite ledger variant where event append and
head update share one transaction. It fails closed on mismatched heads, refuses
implicit migration from a nonempty legacy ledger, and supports an injected
pre-commit failure for regression tests. `test_atomic_ledger.py` adds four tests.
All 162 local Python unit tests pass. This module is not yet wired into the
ROS advisory runtime. It is not an independent anti-rollback trust anchor,
not a hardware power-cut test, and not a ROS 2/Gazebo validation.

### v3.1 — Optional atomic ledger in advisory runtime
The ROS advisory runtime can now select the SQLite transactional `AtomicLedger` using `atomic_ledger=True` (default remains legacy `Ledger` for compatibility). Startup fails closed for tampered atomic history or an existing legacy ledger without an explicit migration. Four new tests cover restart, tail deletion, migration refusal and injected transaction failure. This remains a pure-Python integration; no ROS 2/Gazebo execution or independent anti-rollback anchor.

### v3.2 — Explicit offline legacy ledger migration
Added `ledger_migration.py` and four tests. Migration requires a separate unused backup path, checks the legacy chain, snapshots SQLite with its backup API, writes the atomic head transactionally and verifies the result. Stop all writers first: no exclusive migration lock is implemented. This does not provide independent anti-rollback security or ROS 2/Gazebo validation. 170 Python tests passed (ResourceWarnings remain).

### v3.3 — Cooperative migration exclusion

Introduced a POSIX advisory file lock for the explicit legacy-ledger migration,
with tests for lock contention, release, external holder, and symlink refusal.
174 Python unittest cases passed locally. **Limitation:** advisory locking is
cooperative: non-participating SQLite writers can still modify the database.
Migration must still run with all writers stopped. This is not a live-migration
solution, anti-rollback security, power-loss certification, or ROS 2/Gazebo test.

### v3.4 — Verified migration snapshot and SQLite write reservation
The offline legacy migration now validates the backup's hash chain and compares its
head with the source under `BEGIN IMMEDIATE` before writing the atomic head.
This rejects a source changed after the backup snapshot and preserves the backup
for recovery. Two new tests verify populated and empty migrations; 176 Python
unit tests pass. SQLite's write reservation covers the final migration phase,
not the earlier snapshot; all external writers must still be stopped. No ROS 2
or Gazebo execution was performed. Some ResourceWarnings remain.

### v3.5 — explicit ledger resource ownership
Both legacy and atomic ledgers now support Python context managers to close SQLite connections on normal exit and exceptions. Three regression tests added; 179/179 tests pass. Existing tests still emit ResourceWarnings from other unclosed connections: full cleanup remains open. No ROS 2/Gazebo execution or hardware validation.

### v3.6 — SQLite test cleanup and lifecycle regression
- Fixed two regression tests that previously used SQLite's transaction context manager without closing the connection; now explicitly close via `contextlib.closing`.
- Added three resource-ownership regression tests for legacy ledger, atomic ledger, and advisory runtime shutdown.
- Verified `python -W error::ResourceWarning -m unittest discover -q`: **182 tests pass**, no unclosed-connection warnings in that run.
- No ROS 2 middleware or Gazebo execution was performed; runtime authorization remains fail-closed and no actuator control is provided.

### v3.7: ROS 2 node lifecycle contract tests
Added dependency-injected tests for advisory publication, malformed JSON rejection, and cleanup after simulated middleware failure. Full Python suite: 185 tests pass. No installed ROS 2 middleware, DDS transport, Gazebo, or physical robot was exercised. The node remains advisory-only and starts without mission authorization.

### v3.8 — ROS 2 environment preflight
Run `python ros2_readiness.py` to check CLI availability, Python ROS packages and local package metadata. Exit code 2 indicates missing prerequisites. This is an environment diagnostic only, not a ROS 2 or Gazebo integration test. Three additional tests bring the suite to 188 passing tests. On the development host, ROS 2, colcon, rclpy and std_msgs were unavailable.

### v3.9 — ROS 2 release metadata and validation runbook
Aligned ROS 2 `setup.py` and `package.xml` versions to 3.9.0, added a reproducible external middleware validation runbook, and added four static contract tests. The runbook is **not** a completed ROS 2 or Gazebo test. The ROS 2 advisory node has no actuator control.

### v3.10: reproducible ROS 2 preflight evidence
Added `ros2_validation_evidence.py`, a read-only, timestamped JSON manifest of prerequisite checks and SHA-256 hashes for launch/package artifacts, plus three tests. It never starts ROS 2/Gazebo or publishes actuator commands; validation remains pending.

### v3.11 — offline ROS 2 evidence verification
Added `ros2_evidence_verify.py` for independent SHA-256 consistency checks of
preflight manifests against source files. It rejects changed/missing artifacts,
path escapes and unsupported validation status. Four new tests; 199/199 pass
with ResourceWarning treated as error. This verifies source consistency only,
not ROS 2, Gazebo, DDS, or physical robot behavior.

### v3.12 — strict ROS 2 release evidence completeness
Added `ros2_release_verify.py`, a strict wrapper over the offline evidence hash verifier.
Requires all six expected source/package artifacts, rejects unlisted extras and
modified source content. Four regression tests added; 203 tests pass with
ResourceWarning promoted to error. This is not a digital signature, independent
provenance proof, ROS 2 middleware execution, Gazebo validation, or robot safety certification.

### v3.13: ROS 2 source-manifest symlink hardening
Offline manifest verification now rejects symbolic links in source paths, including
links that resolve within the source tree and symlinked parent directories.
Three regression tests added. Full suite: 206 tests passed with ResourceWarnings
escalated to errors. No ROS 2 middleware or Gazebo execution is claimed.

### v3.14 — fail-closed evidence creation
ROS 2 preflight manifest generation now refuses symlinked source files and symlinked parent directories before reading or hashing content. Existing verifier tests updated to assert rejection at creation, plus three new creation tests. Full Python suite: 209 passing tests with ResourceWarnings escalated. No ROS 2/Gazebo execution or robot safety validation.

### v3.15 — ROS node partial-initialization cleanup
The ROS advisory node now closes its ledger and destroys its node if subscription/publisher initialization fails, and calls rclpy.shutdown even if node destruction raises. Two dependency-injected regression tests added. These are not ROS middleware or Gazebo integration tests.

### v3.16: advisory ROS node boundary regression
Added dependency-injected node tests for duplicate JSON keys, oversized payloads,
and replayed telemetry. Tests exercise the node callback/publisher boundary with a
fake ROS API, not real DDS or Gazebo. The full Python unittest discovery run passed
224 tests with ResourceWarning treated as an error. These are not robot safety claims.

### v3.17 — concurrent SQLite writers
- AtomicLedger.append uses BEGIN IMMEDIATE before reading the ledger head, serializing independent SQLite writer connections.
- Explicit rollback covers failures before and after the head update.
- Added three regression tests for concurrent writers, rollback after head update, and recovery on the next append.
- Python suite: 227 tests pass with ResourceWarning treated as errors.
- No real ROS 2/DDS/Gazebo or physical robot execution has been performed.

### v3.18: process termination recovery tests
Added subprocess crash-recovery regression tests for SQLite WAL: uncommitted
ledger/event-head updates roll back on abrupt process exit, committed events
remain readable, and a new chain survives an interrupted first write.
These tests simulate process termination via os._exit, **not** power loss,
storage-device failure, filesystem corruption, or robot safety. ROS 2 and
Gazebo remain untested in a live middleware/simulation environment.

### v3.19 — restart replay and audit-before-authority
- Regression test: previously consumed mission token remains rejected after restarting both lifecycle and replay stores; fresh authorization is required.
- Refresh now appends the authorization audit record before activating permissions or clearing the persistent revalidation flag. An audit-write failure cannot activate authority.
- 232 Python unit tests passed with ResourceWarning promoted to error. No real ROS 2/Gazebo or hardware test was performed.

### v3.20: Fail-closed refresh interruption
A refresh now revokes prior authority before verification or audit I/O. Tests cover verification failure, audit failure and offline refresh. Simulation only; no ROS 2/Gazebo validation.

### v3.21 — lifecycle write-failure fail-closed ordering
The session refresh now commits lifecycle clearance before publishing in-memory mission permissions. Two fault-injection tests cover lifecycle clearance and revocation exceptions. The full Python suite passes 237 tests with ResourceWarning treated as an error. This remains a simulation-only research prototype; ROS 2/Gazebo integration has not been executed.

### v3.22 — persistent restart boundary regression
Added three integration tests using real, separate SQLite lifecycle, replay and
ledger databases: restart invalidates a previously granted mission authority,
a consumed token cannot be reused after an audit failure, and each new lifecycle
instance increments the persisted epoch while requiring revalidation. 240/240
Python tests pass with ResourceWarning treated as error. These tests do not
make audit, nonce consumption and lifecycle state a single cross-database atomic
transaction. A crash between writes can leave partial evidence; the startup
fail-closed epoch prevents automatic reactivation, but full forensic atomicity
would require a coordinated durable state machine. ROS 2/Gazebo not executed.

### v3.23: refresh audit/lifecycle failure consistency
- Accepted refresh events are appended only after lifecycle clearance has been persisted.
- Audit append exceptions trigger a compensating durable revalidation-required write; no in-memory grant is published.
- Three real SQLite / injected-failure tests cover ordering and fail-closed behavior (243 tests total).
- LIMITATION: compensation is not an atomic commit across independent SQLite databases. Abrupt process death between lifecycle clearance and audit append can still leave mismatched evidence. Startup lifecycle epochs require revalidation; this is not a replacement for unified transaction storage.
- ROS 2/Gazebo and hardware were not executed.

### v3.24 experimental unified authority journal
`unified_authority_store.py` demonstrates a *single SQLite transaction* for nonce consumption, lifecycle clearance, and hash-linked audit append. Four new tests cover atomic commit, injected rollback at three stages, replay rejection, and restart revalidation. Total: 247 Python tests passed with ResourceWarnings treated as errors. This is an isolated experimental component, **not integrated into GovernedSession or the ROS 2 node**; caller-side token signature, expiry and permission checks remain required. No ROS 2/Gazebo or physical robot validation was performed. Existing multi-database runtime behavior is unchanged.

### v3.25: Opt-in unified governed session
Adds `UnifiedGovernedSession`, which verifies signed authority tokens without external nonce consumption, then atomically commits nonce consumption, lifecycle clearance and audit evidence in `UnifiedAuthorityStore`. Durable revocation is performed before refresh; duplicate nonces fail closed. The legacy session and ROS 2 integration remain unchanged. This is simulation-only and not a physical robot safety validation. Python suite: 251 tests passed with ResourceWarnings treated as errors.

### v3.26: opt-in unified advisory adapter

`ros2_unified_runtime.py` provides a ROS-independent advisory adapter for
`UnifiedGovernedSession`. Credentials are only accepted through an explicit
trusted-local-control method, never through telemetry, ROS parameters, or
environment variables. The default verifier has no keys and denies mission
refresh. The unified authority journal and the decision ledger are still
separate databases; only the authority journal's token/state/audit writes are
atomic. No actuator interface or real ROS 2 integration has been validated.

Validation: `python -W error::ResourceWarning -m unittest discover -q`
(255 tests passing in the development environment).

### v3.27: opt-in unified ROS 2 advisory node
Explicit PRIME_RL_STORAGE_MODE=unified selects UnifiedAdvisoryRuntime with two required durable database paths. No ROS credentials or actuator output. Default remains legacy. Mock middleware tests only; ROS 2/Gazebo not executed.

### v3.28 — executable live DDS smoke harness
Adds `ros2_live_smoke.py` with an actual ROS 2 pub/sub test for use on a
prepared external ROS 2 host, and offline contract tests. It checks a
fail-closed advisory for malformed telemetry and never publishes actuator
commands. The live ROS 2 test has **not** been executed in this environment.

### v3.29 live DDS smoke hardening
The live smoke test now requires two distinct invalid telemetry cases and matching rejection error types. This mitigates accidental acceptance of unrelated advisories but does not prove request correlation or ROS 2/Gazebo validation.

### v3.30: ROS advisory correlation (offline contract)
Optional `request_id` UUID and string `telemetry` envelope is accepted by the
ROS advisory node; the ID is echoed in the advisory result. Legacy raw telemetry
is unchanged. The live smoke test checks exact UUID matching for both malformed
telemetry scenarios. This is correlation only, not authentication or replay
protection. Five new offline tests pass; 267 total. ROS 2 DDS/Gazebo not executed.

### v3.31: Bounded process-local ROS 2 request replay detection
The advisory node rejects a repeated correlated `request_id` without evaluating the payload again. The OrderedDict cache holds at most 4096 identifiers. This is a nonpersistent, process-local duplicate filter, **not** durable anti-replay or authentication. Offline Python tests: 270 passed; no live ROS 2/DDS/Gazebo execution.

### v3.32: optional durable ROS advisory request-ID deduplication
Set `PRIME_RL_REPLAY_DB` to a writable, file-backed SQLite database to enable persistent request-ID claims. A previously claimed ID is rejected after node restart. Claims are made before runtime evaluation and storage errors reject the request. This is **not** authentication, does not guarantee exactly-once processing after crashes, and is not a robot safety certification. Without the setting, legacy bounded process-local deduplication remains in effect. ROS 2/DDS/Gazebo execution is still unverified.

### v3.33: durable request-ID concurrency and crash checks
Added three independent regression tests for simultaneous claims from separate SQLite
connections, retention of distinct IDs after reopening, and a committed claim
surviving a forced Python subprocess exit. All 277 Python tests pass with
ResourceWarning treated as an error. These tests do not simulate a power loss,
prove exactly-once processing, or validate live ROS 2/DDS/Gazebo behavior.

### v3.34 - Correlated telemetry freshness regression
Four additional dependency-free contract tests cover stale, future, exact-boundary,
and non-finite timestamps through the correlated advisory envelope. The advisory
boundary already rejects stale/future samples; this release verifies that the
request_id remains correlated on rejection. Python suite: 281 tests pass with
ResourceWarning treated as an error. This does not establish ROS 2/DDS or Gazebo
runtime validation; no physical actuator integration is included.

### v3.35: correlated DDS round-trip timing contract
The optional ROS 2 live smoke tool now measures local elapsed time from publish to matching correlated advisory, enforces a configurable `--max-latency-ms` budget, and includes timing evidence. This is not one-way DDS latency or robot safety validation. ROS 2 runtime remains unavailable here.

### v3.36: strict smoke timing evidence
The optional live DDS smoke harness rejects NaN/infinite timing budgets and samples,
uses an independent timeout for each correlated telemetry scenario after discovery,
and explicitly reports that one-way DDS latency has not been measured. Three
new offline tests pass (288 total, ResourceWarning strict). No ROS 2/DDS/Gazebo
runtime validation has been performed.

### v3.37: bidirectional DDS discovery and guaranteed middleware shutdown
The live smoke harness now waits for both a telemetry subscriber and an advisory publisher before sending probes. It fails closed when either side is missing. Shutdown runs even when node destruction raises an exception. Three offline fake-middleware regression tests added. All 291 Python tests pass with ResourceWarning treated as error. Actual ROS 2/DDS and Gazebo remain untested.

### v3.38: finite DDS smoke timeout validation
The ROS 2 smoke harness now rejects nonfinite, boolean, zero, negative, and
out-of-range discovery/scenario timeouts before importing middleware. Its
correlation comment now reflects the existing unique request-ID matching
without claiming authentication. Two additional offline regression tests;
293 Python tests pass with ResourceWarning treated as error. Live ROS 2/DDS
and Gazebo have not been executed.

### v3.39: offline full DDS smoke-harness contract tests
Added fake-middleware integration tests covering two correlated malformed telemetry
probes, round-trip evidence, distinct request IDs, mandatory middleware cleanup,
and fail-closed behavior on mismatched response correlation. These tests exercise
the harness code only: fake DDS is **not** real ROS 2/DDS or Gazebo validation.

### v3.40 offline verification
- Added a regression test injecting stale correlated advisory messages before the matching response in the fake ROS 2 transport; stale messages must not satisfy the smoke test.
- Full offline Python suite: 296 tests passed (2026-10-18).
- Local `ros2_readiness.py` reports ROS 2 CLI, colcon, rclpy and std_msgs unavailable. No live DDS or Gazebo execution was performed.

### v3.41 offline ROS 2 smoke-harness negative-response filtering
- Added fake-transport regression test injecting malformed JSON, a non-object
  JSON payload, and an `accepted=true` advisory with the expected request ID.
  None may satisfy a required fail-closed rejection; the valid correlated
  rejection must still be observed for both probes.
- Offline Python suite: 297 tests passed (2026-10-18), with ResourceWarning
  treated as error. This is not live DDS/Gazebo validation.

### v3.42: DDS graph recheck before each advisory probe
- The ROS 2 smoke harness checks both DDS endpoints again before each telemetry probe, rejecting a graph that loses its publisher or subscriber after initial discovery.
- Added offline fake-transport regression test for disconnection between probes, including middleware cleanup.
- Offline Python suite: 298 tests passed with ResourceWarning treated as error (2026-10-18).
- ROS 2/DDS and Gazebo are not installed or validated in this environment. Discovery counts are not authenticated peer identity and cannot guarantee delivery.

### v3.43: DDS disconnection while awaiting advisory (offline harness)
The ROS 2 smoke harness now fails closed immediately if either endpoint disappears while a correlated advisory is pending, rather than waiting for the full response timeout. Synthetic tests cover mid-flight disconnection and a clean subsequent run after a disconnected run. This is not live ROS 2/DDS validation and does not provide motor actuation.

### v3.44: repeatable live ROS 2/DDS evidence runner
- Added `ros2_repeatability.py` for sequential live smoke-test repetitions, UTC timestamps, per-run timing evidence, and JSON export (`--output evidence.json`).
- Fail-closed on a failed or invalid run; synthetic tests verify aggregation and failure behavior.
- Example on a **prepared ROS 2 host** with the advisory node already running: `python ros2_repeatability.py --repetitions 10 --output evidence.json`.
- A passing offline mock test **does not** establish live ROS 2/DDS, Gazebo, or hardware validation. Advisory-only; no actuator topics.

### v3.45: repeatability evidence consistency validation
- Added `validate_evidence_report()` for UTC timestamp, sequential run ID, pass/fail summary, finite timing, and maximum latency consistency checks.
- Repetition runner now rejects nonpositive/nonfinite timeout and latency budgets before probing.
- Three new synthetic tests; full offline Python suite: 307 passed (2026-10-18).
- Structural validation is **not** cryptographic provenance verification. Live ROS 2/DDS and Gazebo remain untested in this environment.

### v3.46 - report integrity digest
`ros2_repeatability.evidence_sha256(report)` calculates a deterministic SHA-256
fingerprint for a structurally valid repeatability report;
`verify_evidence_digest(report, digest)` compares it to an independently retained
fingerprint. This detects modifications only if the reference digest is held
separately and trusted. **It does not authenticate the producer, establish
hardware provenance, or prove live DDS execution.** ROS 2/Gazebo still untested.

### v3.47 - optional keyed report authentication
- Added `evidence_auth.py` with domain-separated HMAC-SHA256 authentication for
  structurally validated repeatability reports and constant-time tag comparison.
- Keep the 32+ byte secret **outside** reports, ZIP packages, and source control;
  distribute it only through a trusted channel. A shared key establishes only
  possession of that key, not independent hardware provenance, DDS execution,
  or non-repudiation. Compromised keys invalidate this assurance.
- Four offline unit tests cover matching/wrong keys, consistent tampering,
  malformed tags, and structurally invalid reports. No ROS 2/Gazebo validation.

### v3.48 - local evidence HMAC key-file hardening
- Added `evidence_keyring.load_evidence_key(path)` for raw HMAC keys stored in
  owner-only POSIX regular files (mode `0600`, 32-4096 bytes). Rejects symlinks,
  group/other access, mismatched ownership, and invalid lengths; never embeds
  key material in reports or package defaults.
- Provision the key independently of this source tree and its ZIP archive;
  rotate/revoke keys using an external controlled process. This loader does not
  provide a secure enclave, key rotation protocol, or hardware attestation.
- ROS 2/DDS and Gazebo have not been executed in this environment.

### v3.49 - local ROS 2 evidence run manifests
`ros2_run_manifest.py` creates a UUID4 run manifest binding an existing evidence JSON
report to a SHA-256 digest and a timestamp; `--verify` checks consistency. Example:
`python ros2_run_manifest.py evidence.json manifest.json` followed by
`python ros2_run_manifest.py --verify evidence.json manifest.json`.
The tool refuses to overwrite an existing manifest. Store manifests separately
from reports to detect changes. This is **not** cryptographic authentication,
remote attestation, or proof of actual ROS 2/DDS execution; use the optional
HMAC verification tool and separately managed keys where origin authentication
is required. No actuator access is introduced.

### v3.50 - paired repeatability evidence and run manifest
`ros2_repeatability.py --output evidence.json --manifest-output manifest.json`
creates separate evidence and UUID4 digest-bound manifest files. Existing output
files and identical output paths are rejected. The manifest binds the report
content, but neither artifact alone proves live DDS execution or provenance.
Offline CLI tests use injected probes and do not claim ROS 2 validation.

### v3.51 - Evidence pair failure handling
Evidence and manifest are created exclusively with private permissions and flushed to disk. Handled write failures roll back newly created files without overwriting pre-existing files. **Two-file publication is not power-loss atomic**: a crash can leave an incomplete pair. Consumers must verify both files and the manifest digest before trusting a result. ROS 2/DDS and Gazebo remain unverified on a live installation.

### v3.52 - Fail-closed evidence-pair recovery checks
`python ros2_evidence_pair_verify.py evidence.json manifest.json` checks that both
artifacts exist, rejects symlinks and malformed/duplicate-key JSON, and verifies
manifest-to-evidence consistency. Missing or modified halves are rejected with
exit status 2. This is an offline integrity check, not proof of live DDS execution,
identity, or crash-atomic publication. ROS 2/Gazebo remain untested here.

### v3.53 - read-only batch audit of evidence pairs
`python ros2_evidence_audit.py /path/to/evidence-directory` audits files named
`<stem>.evidence.json` and `<stem>.manifest.json`. It fails closed for empty
collections, missing halves, malformed or altered pairs, duplicate run IDs,
and symlinked audit directories. It never repairs or deletes evidence.
This checks local file consistency only, not genuine DDS execution or provenance.

### v3.54 offline evidence metrics
`python ros2_metrics_summary.py <evidence-directory>` computes min, mean, p50,
p95 and max publish-to-correlated-advisory elapsed milliseconds across fully
verified, passing evidence pairs. It fails closed on incomplete, altered or
failed evidence and explicitly does not attest to live DDS or one-way latency.

### v3.55 - explicit offline metrics acceptance gate
`python ros2_metrics_gate.py <evidence-directory> --max-p95-ms <positive-number> --min-samples <positive-integer> [--max-mean-ms <positive-number>]`
checks verified local evidence against caller-provided thresholds. No default
performance target is invented. Incomplete evidence, insufficient samples and
exceeded limits fail closed (exit status 2). A pass is **not** live ROS 2/DDS
attestation or a safety certification; physical actuation remains out of scope.

### v3.56 - offline baseline-versus-candidate latency regression gate
`python ros2_metrics_regression.py <baseline-evidence-dir> <candidate-evidence-dir> --max-p95-increase-pct <nonnegative-percent> --min-samples <positive-integer>`
compares independently verified local evidence collections, requiring enough
samples in both. It fails closed on invalid evidence, inadequate samples or a
p95 increase exceeding the caller-specified tolerance (exit status 2). This
is an offline comparative gate, not proof of live ROS 2/DDS execution, robot
safety, or causality. No physical actuation is enabled.

### v3.57 - independent baseline/candidate evidence
The regression gate rejects the same evidence directory (including resolved
path aliases) and rejects overlapping run IDs across baseline and candidate
sets. Distinct verified runs remain eligible. This guards against accidental
reuse, not forged provenance; ROS 2/DDS and Gazebo are not validated here.

## v3.58 — Isolated ROS 2 integration preflight

Run `python3 ros2_integration_preflight.py` on the ROS 2 host before launching the advisory smoke test. Exit 2 blocks execution when dependencies or package files are missing. Exit 0 only establishes static prerequisites; it does **not** prove DDS delivery, Gazebo integration, actuator isolation, or safety. Independently inspect the live ROS graph and physically disconnect actuators. No real ROS 2 or Gazebo execution was performed in this build environment.

### v3.59: offline ROS 2 topic declaration contract

`python3 ros2_topic_contract.py` statically audits the prototype advisory and
scenario Python sources. It fails closed when declared publishers/subscribers
change, when topic expressions are dynamic, or when source files cannot be
parsed. This audit does **not** inspect a running ROS graph, other nodes,
launch-time remappings, middleware behavior, or actuator connections. The
static contract passing is **not** a safety certification. Actual ROS 2/DDS
and Gazebo integration remain untested in this environment.

### v3.60 metrics coverage gates
The offline latency acceptance CLI additionally supports `--min-runs` and `--min-evidence-pairs` (defaults 1). These guard against treating many samples from one run as independent replication. The gates do not establish statistical independence, hardware safety, or live DDS provenance. ROS 2/Gazebo execution remains unverified.

## v3.61: offline ROS 2 workspace preparation

`python3 ros2_workspace_prepare.py --workspace /path/to/new/workspace` previews the
workspace layout and future commands without modifying files, downloading packages,
starting ROS 2 or incurring cloud costs. On a compatible, user-controlled host,
`--copy` explicitly stages the existing source into a new workspace. The command
refuses to overwrite an existing package and rejects symlinks in source. This is
not an installer: ROS 2 Jazzy and dependencies must already be installed before
any build or DDS smoke test. No ROS 2/Gazebo execution has been performed here.

## v3.63: offline ROS 2 packaging consistency audit

`python3 ros2_packaging_contract.py` checks literal `setup.py` metadata against
`package.xml`, required installed launch/resource files, Python modules, console
entry points, and declared ROS runtime dependencies. It fails closed on unreadable,
nonliteral or inconsistent metadata. This is **not** a `colcon build`, live DDS
verification, Gazebo test, or evidence of actuator isolation.

### v3.65 offline ROS 2 container handoff manifest
Run `python3 ros2_container_plan.py` to print deterministic SHA-256 hashes of the
ROS 2 container recipe and integration entry points. This operation is offline,
read-only, and never starts Docker, ROS 2, DDS, Gazebo, or physical actuators.
A `ready_for_external_runtime` status only means the listed files are present;
it is **not** a runtime validation result. Real ROS 2/Gazebo execution remains pending.
