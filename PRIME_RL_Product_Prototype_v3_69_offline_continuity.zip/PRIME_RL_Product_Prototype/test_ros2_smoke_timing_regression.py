"""Regression tests for strict latency evidence validation."""
import math
import unittest
from ros2_live_smoke import validate_timings, run


class TestSmokeTimingRegression(unittest.TestCase):
    def test_rejects_nan_infinite_latency_budget(self):
        for budget in (math.nan, math.inf, -math.inf):
            with self.subTest(budget=budget), self.assertRaises(ValueError):
                validate_timings([1.0], max_latency_ms=budget)

    def test_rejects_nonfinite_samples(self):
        for sample in (math.nan, math.inf, -math.inf):
            with self.subTest(sample=sample), self.assertRaises(ValueError):
                validate_timings([sample], max_latency_ms=100.0)

    def test_rejects_invalid_timeout_before_middleware_import(self):
        for timeout in (math.nan, math.inf, -math.inf, True, False, 0, -1, 121):
            with self.subTest(timeout=timeout), self.assertRaises(ValueError):
                run(timeout=timeout)

    def test_accepts_finite_timeout_then_attempts_middleware_import(self):
        from unittest.mock import patch
        with patch.dict('sys.modules', {'rclpy': None}):
            with self.assertRaises(ModuleNotFoundError):
                run(timeout=0.01)

    def test_valid_roundtrip_metrics(self):
        result = validate_timings([2.12345, 3.5], max_latency_ms=10.0)
        self.assertEqual(result['round_trip_ms'], [2.123, 3.5])
        self.assertEqual(result['max_round_trip_ms'], 3.5)


if __name__ == '__main__':
    unittest.main()
