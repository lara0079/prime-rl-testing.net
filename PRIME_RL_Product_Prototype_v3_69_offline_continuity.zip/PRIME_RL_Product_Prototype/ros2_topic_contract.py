"""Static advisory topic contract audit; not a live ROS graph safety assertion."""
import ast
import json
from pathlib import Path

EXPECTED = {
    'ros2_advisory_node.py': {'create_publisher': ['OUTPUT_TOPIC'], 'create_subscription': ['INPUT_TOPIC']},
    'ros2_scenario.py': {'create_publisher': ['INPUT_TOPIC'], 'create_subscription': []},
}


def audit_topics(root=None):
    root = Path(root) if root is not None else Path(__file__).resolve().parent
    problems = []
    observed = {}
    for filename, expected in EXPECTED.items():
        path = root / filename
        try:
            tree = ast.parse(path.read_text(encoding='utf-8'), filename=filename)
        except (OSError, SyntaxError, UnicodeError) as exc:
            problems.append(f'{filename}: unreadable_or_invalid_python: {type(exc).__name__}')
            continue
        calls = {'create_publisher': [], 'create_subscription': []}
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                continue
            name = node.func.attr
            if name not in calls:
                continue
            # Dynamic topic expressions fail closed; only explicit symbolic names accepted.
            if len(node.args) < 2 or not isinstance(node.args[1], ast.Name):
                problems.append(f'{filename}: dynamic_or_missing_topic_in_{name}')
            else:
                calls[name].append(node.args[1].id)
        observed[filename] = calls
        for method, expected_topics in expected.items():
            if sorted(calls[method]) != sorted(expected_topics):
                problems.append(f'{filename}: unexpected_{method}_declarations')
    return {'status': 'static_contract_pass' if not problems else 'blocked',
            'problems': problems, 'observed': observed,
            'live_ros_graph_verified': False, 'actuator_absence_verified': False}


def main():
    result = audit_topics()
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0 if result['status'] == 'static_contract_pass' else 2


if __name__ == '__main__':
    raise SystemExit(main())
