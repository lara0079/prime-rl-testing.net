import tempfile
import unittest
from pathlib import Path
from ros2_topic_contract import audit_topics


class TopicContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'ros2_advisory_node.py').write_text(
            'self.create_publisher(String, OUTPUT_TOPIC, 10)\n'
            'self.create_subscription(String, INPUT_TOPIC, callback, 10)\n')
        (self.root / 'ros2_scenario.py').write_text('self.create_publisher(String, INPUT_TOPIC, 10)\n')

    def test_expected_declarations_pass_without_claiming_live_safety(self):
        result = audit_topics(self.root)
        self.assertEqual(result['status'], 'static_contract_pass')
        self.assertFalse(result['live_ros_graph_verified'])
        self.assertFalse(result['actuator_absence_verified'])

    def test_extra_actuator_publisher_blocks(self):
        with (self.root / 'ros2_advisory_node.py').open('a') as stream:
            stream.write('self.create_publisher(String, MOTOR_TOPIC, 10)\n')
        self.assertEqual(audit_topics(self.root)['status'], 'blocked')

    def test_dynamic_topic_blocks(self):
        (self.root / 'ros2_scenario.py').write_text('self.create_publisher(String, topic_from_config(), 10)\n')
        self.assertEqual(audit_topics(self.root)['status'], 'blocked')

    def test_missing_file_blocks(self):
        (self.root / 'ros2_scenario.py').unlink()
        self.assertEqual(audit_topics(self.root)['status'], 'blocked')
