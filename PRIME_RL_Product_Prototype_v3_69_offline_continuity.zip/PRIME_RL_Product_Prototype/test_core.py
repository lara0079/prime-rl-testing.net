import unittest
from core import Runtime,Snapshot
class Tests(unittest.TestCase):
    def setUp(self): self.r=Runtime()
    def s(self,**kw):
        d=dict(connected=True,link_quality=1.,sensor_confidence=1.,energy_fraction=1.,authority_valid=True)
        d.update(kw);return Snapshot(**d)
    def test_online(self):self.assertTrue(self.r.evaluate(self.s(),'inspect')['accepted'])
    def test_disconnected(self):self.assertFalse(self.r.evaluate(self.s(connected=False),'inspect')['accepted'])
    def test_expired(self):self.assertFalse(self.r.evaluate(self.s(authority_valid=False),'return')['accepted'])
    def test_low_energy(self):self.assertFalse(self.r.evaluate(self.s(energy_fraction=.1),'return')['accepted'])
    def test_low_sensor(self):self.assertFalse(self.r.evaluate(self.s(sensor_confidence=.1),'return')['accepted'])
    def test_audit(self):
        self.r.evaluate(self.s(),'hold');a=self.r.last_hash
        self.r.evaluate(self.s(),'hold');self.assertNotEqual(a,self.r.last_hash)
if __name__=='__main__':unittest.main()
