"""Offline metrics from verified evidence pairs; never attests to live DDS."""
import argparse
import json
import math
from pathlib import Path

from ros2_evidence_audit import audit_directory


def _percentile(values, fraction):
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def summarize(directory):
    root = Path(directory)
    audit = audit_directory(root)
    if audit['status'] != 'pass':
        return {'status': 'fail', 'reason': 'evidence_audit_failed',
                'audit': audit, 'live_dds_attested': False}
    samples = []
    successful_runs = 0
    live_claims = 0
    for item in audit['pairs']:
        report = json.loads((root / (item['stem'] + '.evidence.json')).read_text(encoding='utf-8'))
        if report['status'] != 'pass':
            return {'status': 'fail', 'reason': 'failed_evidence_present',
                    'audit': audit, 'live_dds_attested': False}
        successful_runs += len(report['runs'])
        live_claims += int(report['live_dds_verified'])
        for run in report['runs']:
            samples.extend(run['round_trip_ms'])
    if not samples:
        return {'status': 'fail', 'reason': 'no_latency_samples',
                'audit': audit, 'live_dds_attested': False}
    return {'status': 'pass', 'evidence_pairs': audit['total'],
            'completed_runs': successful_runs, 'sample_count': len(samples),
            'latency_ms': {'min': min(samples), 'mean': sum(samples) / len(samples),
                           'p50': _percentile(samples, 0.50),
                           'p95': _percentile(samples, 0.95), 'max': max(samples)},
            'reports_claiming_live_dds': live_claims,
            'live_dds_attested': False,
            'metric': 'local publish-to-correlated-advisory elapsed time; not one-way DDS latency'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    result = summarize(args.directory)
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    if result['status'] != 'pass':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
