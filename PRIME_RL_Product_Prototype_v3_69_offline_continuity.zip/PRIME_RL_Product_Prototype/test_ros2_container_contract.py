import tempfile
import unittest
from pathlib import Path
from ros2_container_contract import audit, REQUIRED

class ContainerContractTests(unittest.TestCase):
    def test_shipped_recipe_passes_static_audit(self):
        result = audit()
        self.assertEqual(result['status'], 'pass', result['problems'])
        self.assertFalse(result['docker_executed'])
        self.assertFalse(result['dds_test_executed'])

    def test_missing_recipe_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = audit(tmp)
            self.assertEqual(result['status'], 'fail')
            self.assertEqual(len(result['problems']), len(REQUIRED))

    def test_network_host_or_privileged_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = Path(__file__).resolve().parent
            for name in REQUIRED:
                (root / name).write_text((source / name).read_text())
            runner = root / 'run_ros2_container_smoke.sh'
            runner.write_text(runner.read_text() + '\ndocker run --privileged --network host test\n')
            self.assertEqual(audit(root)['status'], 'fail')

    def test_symlink_recipe_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = Path(__file__).resolve().parent
            for name in REQUIRED:
                (root / name).write_text((source / name).read_text())
            (root / '.dockerignore').unlink()
            (root / '.dockerignore').symlink_to(source / '.dockerignore')
            self.assertEqual(audit(root)['status'], 'fail')

if __name__ == '__main__':
    unittest.main()
