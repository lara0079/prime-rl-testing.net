"""Synthetic authority-continuity stress test; no hardware control."""
import json
import tempfile
from pathlib import Path
from authority import AuthorityVerifier, sign
from core import Snapshot
from ledger import Ledger
from lifecycle import LifecycleStore
from session import GovernedSession

KEY = b'illustrative-prime-rl-continuity-key-2026'


def run(cycles=40):
    if type(cycles) is not int or cycles < 1:
        raise ValueError('cycles must be a positive integer')
    totals = {'version': 'v2.0', 'cycles': cycles, 'checks': 0, 'failures': [], 'ledger_valid': False}
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory)
        verifier = AuthorityVerifier({'demo': KEY}, 'continuity', 'robot', path/'replay.sqlite')
        ledger = Ledger(path/'ledger.sqlite')
        lifecycle = LifecycleStore(path/'lifecycle.sqlite')
        session = GovernedSession(verifier, ledger, lifecycle)
        online = Snapshot(True, 1., 1., .8, True)
        offline = Snapshot(False, 0., .9, .8, True)
        nonce = 0

        def check(label, condition):
            totals['checks'] += 1
            if not condition:
                totals['failures'].append(label)

        def token(now, expiry=1.0):
            nonlocal nonce
            nonce += 1
            return sign({'kid':'demo','iss':'continuity','aud':'robot',
                         'nbf':now-1.,'exp':now+expiry,'nonce':f'cycle-{nonce}',
                         'permissions':['inspect']}, KEY)

        for cycle in range(cycles):
            now = 1000. + cycle*10.
            check('initial_gate', not session.decide(online, 'inspect', now)['accepted'])
            fresh = token(now)
            check('fresh_authority', session.refresh(fresh, now, True))
            check('online_authorized', session.decide(online, 'inspect', now+.1)['accepted'])
            check('replay_rejected', not session.refresh(fresh, now+.2, True))
            check('replay_fail_closed', not session.decide(online, 'inspect', now+.3)['accepted'])
            check('reissue_authority', session.refresh(token(now+.4), now+.4, True))
            check('offline_mission_denied', not session.decide(offline, 'inspect', now+.5)['accepted'])
            check('offline_hold', session.decide(offline, 'hold', now+.6)['accepted'])
            check('reconnect_requires_validation', not session.decide(online, 'inspect', now+.7)['accepted'])
            check('refresh_on_reconnect', session.refresh(token(now+.8), now+.8, True))
            check('post_reconnect_authorized', session.decide(online, 'inspect', now+.9)['accepted'])
            check('expired_denied', not session.decide(online, 'inspect', now+2.)['accepted'])
            # A process restart must invalidate previously authorized mission operations.
            lifecycle.close()
            lifecycle = LifecycleStore(path/'lifecycle.sqlite')
            session = GovernedSession(verifier, ledger, lifecycle)
            check('restart_denied', not session.decide(online, 'inspect', now+2.1)['accepted'])
        totals['ledger_valid'] = ledger.verify()
        totals['ledger_events'] = len(ledger.events())
        totals['passed'] = not totals['failures'] and totals['ledger_valid']
        lifecycle.close()
        verifier.close()
        ledger.close()
    totals['limitations'] = 'Illustrative signed tokens and synthetic clock; not a ROS/Gazebo, hardware or security certification test.'
    return totals

if __name__ == '__main__':
    Path(__file__).with_name('continuity_report.json').write_text(json.dumps(run(), indent=2), encoding='utf-8')
