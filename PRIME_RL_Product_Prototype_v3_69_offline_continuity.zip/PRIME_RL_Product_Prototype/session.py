"""Simulation-only fail-closed reconnection gate; no physical actuation."""
from core import Runtime, Snapshot

class GovernedSession:
    def __init__(self, verifier, ledger, lifecycle=None):
        self.verifier = verifier
        self.lifecycle = lifecycle
        self.ledger = ledger
        self.runtime = Runtime()
        self.permissions = frozenset()
        self.expires_at = None
        self.revalidation_required = True
        self.previous_connected = None

    def refresh(self, token, now, connected):
        # Revoke prior authority before any fallible verification or audit I/O.
        # A failed refresh must never leave the previous mission grant active.
        self.permissions = frozenset()
        self.expires_at = None
        self.revalidation_required = True
        if self.lifecycle:
            self.lifecycle.mark_revalidation_required()
        if not connected:
            self.revalidation_required = True
            if self.lifecycle: self.lifecycle.mark_revalidation_required()
            self.ledger.append({'kind':'refresh','accepted':False,'reason':'offline'})
            return False
        result = self.verifier.verify(token, now, consume=True)
        # An accepted audit record is only written after durable lifecycle
        # clearance. Separate databases still cannot commit atomically.
        if not result.valid:
            self.ledger.append({'kind':'refresh','accepted':False,'reason':result.reason})
            return False
        try:
            if self.lifecycle:
                self.lifecycle.mark_refreshed()
            self.ledger.append({'kind':'refresh','accepted':True,'reason':result.reason})
        except BaseException:
            # A successful lifecycle write followed by a failed audit append
            # must not leave durable clearance on disk.
            if self.lifecycle:
                self.lifecycle.mark_revalidation_required()
            raise
        self.permissions = result.permissions
        self.expires_at = result.expires_at
        self.revalidation_required = False
        return True

    def decide(self, snapshot: Snapshot, action: str, now=None):
        # Loss and restoration both demand explicit revalidation for mission actions.
        if self.previous_connected is not None and snapshot.connected != self.previous_connected:
            self.revalidation_required = True
            if self.lifecycle: self.lifecycle.mark_revalidation_required()
        self.previous_connected = snapshot.connected
        # Fail closed for mission operations if no current clock reading is supplied.
        if now is None or not isinstance(now, (int, float)) or not __import__('math').isfinite(now) or (self.expires_at is not None and now >= self.expires_at):
            self.revalidation_required = True
            if self.lifecycle: self.lifecycle.mark_revalidation_required()
        if self.lifecycle and self.lifecycle.required():
            self.revalidation_required = True
        # Local recovery-only actions are still checked by original safety core.
        mission_action = action == 'inspect'
        authorized = not self.revalidation_required and action in self.permissions
        effective = Snapshot(snapshot.connected, snapshot.link_quality, snapshot.sensor_confidence,
                             snapshot.energy_fraction, snapshot.authority_valid and (authorized if mission_action else True),
                             snapshot.integrity_ok)
        result = self.runtime.evaluate(effective, action)
        if mission_action and not authorized:
            result['accepted'] = False
            result['reason'] = 'revalidation_required_or_not_permitted'
        else:
            result['reason'] = 'illustrative_core_policy'
        self.ledger.append({'kind':'decision','action':action,'state':result['state'],
                            'accepted':result['accepted'],'reason':result['reason']})
        return result
