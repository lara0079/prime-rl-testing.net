"""Real SQLite restart boundary tests; simulation-only, not hardware safety evidence."""
import os
import tempfile
import unittest
from pathlib import Path
from authority import AuthorityVerifier, sign
from lifecycle import LifecycleStore
from ledger import Ledger
from session import GovernedSession

KEY = b'R' * 32

def token(nonce):
    return sign({'kid':'k','iss':'test','aud':'robot','nbf':0,'exp':500,
                 'nonce':nonce,'permissions':['inspect']}, KEY)

class RefreshRestartConsistencyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.life_path = str(self.base/'lifecycle.db')
        self.replay_path = str(self.base/'replay.db')
        self.audit_path = str(self.base/'audit.db')
    def open_stack(self):
        life = LifecycleStore(self.life_path)
        verifier = AuthorityVerifier({'k':KEY},'test','robot',self.replay_path)
        ledger = Ledger(self.audit_path)
        self.addCleanup(life.close)
        self.addCleanup(verifier.close)
        self.addCleanup(ledger.close)
        return GovernedSession(verifier,ledger,life),life
    def test_restart_revokes_successful_refresh_and_consumed_token(self):
        first, life = self.open_stack()
        self.assertTrue(first.refresh(token('first'),10,True))
        self.assertFalse(life.required())
        second, restarted = self.open_stack()
        self.assertTrue(restarted.required())
        self.assertFalse(second.refresh(token('first'),11,True))
        self.assertTrue(restarted.required())
        self.assertEqual(second.permissions,frozenset())
        self.assertTrue(second.refresh(token('second'),12,True))
    def test_audit_failure_after_token_consumption_never_grants(self):
        first, life = self.open_stack()
        class FailedAudit:
            def append(self,event): raise OSError('audit unavailable')
        first.ledger = FailedAudit()
        with self.assertRaises(OSError):
            first.refresh(token('lost'),10,True)
        self.assertTrue(life.required())
        self.assertEqual(first.permissions,frozenset())
        second, restarted = self.open_stack()
        self.assertFalse(second.refresh(token('lost'),11,True))
        self.assertTrue(restarted.required())
    def test_restart_epoch_increases_after_persisted_clearance(self):
        first, life = self.open_stack()
        epoch = life.epoch()
        self.assertTrue(first.refresh(token('initial'),10,True))
        _, restarted = self.open_stack()
        self.assertEqual(restarted.epoch(),epoch+1)
        self.assertTrue(restarted.required())

if __name__ == '__main__': unittest.main()
