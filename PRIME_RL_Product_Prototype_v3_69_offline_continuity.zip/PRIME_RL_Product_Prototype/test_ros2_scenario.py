import json
import unittest
from ros2_scenario import SCENARIO, scenario_payload
from ros2_advisory_node import evaluate_payload


class ScenarioTests(unittest.TestCase):
    def test_all_phases_evaluable(self):
        for phase in SCENARIO:
            with self.subTest(phase=phase):
                payload = scenario_payload(phase, now_seconds=100.)
                result = json.loads(evaluate_payload(payload, now_seconds=100.))
                self.assertTrue(result['advisory_only'])
                self.assertIn('accepted', result)

    def test_stale_rejected(self):
        result = json.loads(evaluate_payload(scenario_payload('stale', now_seconds=100.), now_seconds=100.))
        self.assertFalse(result['accepted'])
        self.assertEqual(result['reason'], 'stale_or_future_telemetry')

    def test_recovery_valid(self):
        result = json.loads(evaluate_payload(scenario_payload('recovery', now_seconds=100.), now_seconds=100.))
        self.assertNotEqual(result['reason'], 'invalid_telemetry')

    def test_disconnected(self):
        payload = json.loads(scenario_payload('disconnected', now_seconds=100.))
        self.assertFalse(payload['connected'])

    def test_unknown_phase_rejected(self):
        with self.assertRaises(ValueError):
            scenario_payload('actuate', now_seconds=100.)

    def test_nonfinite_time_rejected(self):
        with self.assertRaises(ValueError):
            scenario_payload('nominal', now_seconds=float('nan'))

    def test_scenario_has_no_motion_publishers(self):
        import inspect, ros2_scenario
        src = inspect.getsource(ros2_scenario)
        self.assertNotIn('cmd_vel', src)
        self.assertNotIn('Twist(', src)


if __name__ == '__main__':
    unittest.main()
