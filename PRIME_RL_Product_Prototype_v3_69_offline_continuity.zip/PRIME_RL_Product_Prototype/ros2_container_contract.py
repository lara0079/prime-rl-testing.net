"""Static contract for an opt-in isolated ROS 2 container recipe; never runs Docker."""
from pathlib import Path
import json

REQUIRED = ('Dockerfile.ros2', 'run_ros2_container_smoke.sh', '.dockerignore')

def audit(root=None):
    root = Path(root) if root else Path(__file__).resolve().parent
    problems = []
    for name in REQUIRED:
        path = root / name
        if path.is_symlink() or not path.is_file():
            problems.append('missing or symlinked: ' + name)
    if not problems:
        docker = (root / 'Dockerfile.ros2').read_text(encoding='utf-8')
        runner = (root / 'run_ros2_container_smoke.sh').read_text(encoding='utf-8')
        ignore = (root / '.dockerignore').read_text(encoding='utf-8')
        if 'FROM ros:jazzy-ros-base' not in docker:
            problems.append('ROS 2 Jazzy base image not pinned to distribution')
        if 'colcon build --packages-select prime_rl_advisory' not in docker:
            problems.append('package build step absent')
        if 'ros2_integration_preflight.py' not in runner or 'ros2_live_smoke.py' not in runner:
            problems.append('preflight or smoke missing')
        if '--network none' not in runner:
            problems.append('no explicit container network isolation')
        if '--device' in runner or '--privileged' in runner or '--network host' in runner:
            problems.append('unsafe Docker runtime flag')
        if '--cap-drop ALL' not in runner or '--security-opt no-new-privileges' not in runner:
            problems.append('container privilege reduction absent')
        if '.git' not in ignore or '__pycache__' not in ignore:
            problems.append('inadequate Docker context exclusions')
    return {'status': 'pass' if not problems else 'fail', 'problems': problems,
            'docker_executed': False, 'dds_test_executed': False,
            'note': 'Recipe audit only; no claim of container or DDS runtime validation.'}

if __name__ == '__main__':
    result = audit()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['status'] == 'pass' else 2)
