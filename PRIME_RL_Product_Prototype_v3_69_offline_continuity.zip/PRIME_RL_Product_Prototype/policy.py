"""Simulation policy proposal interface; never directly drives actuators."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Proposal:
    action: str
    policy_id: str = 'untrained-demo'

class FixedPolicy:
    def __init__(self, action='inspect'):
        self.action = action

    def propose(self, observation):
        return Proposal(self.action)

class GovernedPolicy:
    def __init__(self, session, policy):
        self.session = session
        self.policy = policy

    def evaluate(self, snapshot, now):
        proposal = self.policy.propose(snapshot)
        if not isinstance(proposal, Proposal) or not isinstance(proposal.action, str):
            raise TypeError('policy must return Proposal with string action')
        outcome = self.session.decide(snapshot, proposal.action, now=now)
        return {'proposal':proposal.action, 'policy_id':proposal.policy_id, **outcome}
