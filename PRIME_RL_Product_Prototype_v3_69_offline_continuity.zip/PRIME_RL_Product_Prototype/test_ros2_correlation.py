"""Offline contract checks for opt-in ROS advisory correlation."""
import json
import unittest
import uuid
from ros2_advisory_node import evaluate_correlated
from ros2_live_smoke import check_advisory


class StubRuntime:
    def evaluate(self, payload, now_seconds):
        if payload == '{broken-json':
            error = 'JSONDecodeError'
        else:
            error = 'ValueError'
        return json.dumps({'advisory_only': True, 'accepted': False,
                           'reason': 'invalid_telemetry', 'error_type': error})


class CorrelationTests(unittest.TestCase):
    def setUp(self):
        self.runtime = StubRuntime()
        self.rid = str(uuid.uuid4())

    def test_matching_response_echoes_id(self):
        payload = json.dumps({'request_id': self.rid, 'telemetry': '{broken-json'})
        result = evaluate_correlated(self.runtime, payload, now_seconds=10)
        self.assertEqual(check_advisory(result, expected_error_type='JSONDecodeError',
                                        expected_request_id=self.rid)['request_id'], self.rid)

    def test_wrong_id_cannot_satisfy_smoke_test(self):
        payload = json.dumps({'request_id': self.rid, 'telemetry': '{}'})
        result = evaluate_correlated(self.runtime, payload, now_seconds=10)
        with self.assertRaises(ValueError):
            check_advisory(result, expected_request_id=str(uuid.uuid4()))

    def test_malformed_id_fails_closed_without_echo(self):
        payload = json.dumps({'request_id': 'invalid', 'telemetry': '{}'})
        result = json.loads(evaluate_correlated(self.runtime, payload, now_seconds=10))
        self.assertFalse(result['accepted'])
        self.assertNotIn('request_id', result)

    def test_envelope_rejects_extra_authority_fields(self):
        payload = json.dumps({'request_id': self.rid, 'telemetry': '{}', 'token': 'x'})
        result = json.loads(evaluate_correlated(self.runtime, payload, now_seconds=10))
        self.assertFalse(result['accepted'])
        self.assertNotIn('request_id', result)

    def test_legacy_payload_unchanged(self):
        self.assertEqual(json.loads(evaluate_correlated(self.runtime, '{}', now_seconds=10))['reason'],
                         'invalid_telemetry')


if __name__ == '__main__':
    unittest.main()
