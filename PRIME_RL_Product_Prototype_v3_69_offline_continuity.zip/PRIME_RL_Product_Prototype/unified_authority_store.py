"""Experimental single-DB authority journal. Simulation only; no actuator authority."""
import hashlib
import sqlite3
from ledger import ZERO, canonical


class UnifiedAuthorityStore:
    """Commit nonce consumption, lifecycle clearance and audit event atomically."""
    def __init__(self, path):
        self.db = sqlite3.connect(str(path), isolation_level=None, timeout=10)
        try:
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), epoch INTEGER NOT NULL, revalidation INTEGER NOT NULL CHECK(revalidation IN (0,1)))')
            self.db.execute('CREATE TABLE IF NOT EXISTS nonces (issuer TEXT NOT NULL, audience TEXT NOT NULL, nonce TEXT NOT NULL, PRIMARY KEY(issuer,audience,nonce))')
            self.db.execute('CREATE TABLE IF NOT EXISTS audit (seq INTEGER PRIMARY KEY, payload TEXT NOT NULL, previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL)')
            self.db.execute('BEGIN IMMEDIATE')
            try:
                self.db.execute('INSERT OR IGNORE INTO state VALUES (1,0,1)')
                self.db.execute('UPDATE state SET epoch=epoch+1,revalidation=1 WHERE id=1')
                self.db.execute('COMMIT')
            except BaseException:
                self.db.execute('ROLLBACK')
                raise
        except BaseException:
            self.close()
            raise

    def authorize(self, issuer, audience, nonce, *, inject_failure=None):
        """Caller must verify signed token and validity *before* invoking this method."""
        if not all(isinstance(v, str) and v for v in (issuer, audience, nonce)):
            raise ValueError('nonempty authority identifiers required')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT INTO nonces VALUES (?,?,?)', (issuer, audience, nonce))
            if inject_failure == 'nonce':
                raise RuntimeError('injected after nonce')
            self.db.execute('UPDATE state SET revalidation=0 WHERE id=1')
            if inject_failure == 'state':
                raise RuntimeError('injected after state')
            payload = canonical({'kind':'authority_accepted','issuer':issuer,'audience':audience,'nonce':nonce})
            row = self.db.execute('SELECT seq,event_hash FROM audit ORDER BY seq DESC LIMIT 1').fetchone()
            seq, previous = (row[0]+1,row[1]) if row else (1,ZERO)
            digest = hashlib.sha256(f'{seq}:{previous}:{payload}'.encode()).hexdigest()
            self.db.execute('INSERT INTO audit VALUES (?,?,?,?)', (seq,payload,previous,digest))
            if inject_failure == 'audit':
                raise RuntimeError('injected after audit')
            self.db.execute('COMMIT')
            return digest
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def require_revalidation(self):
        """Persist revocation before subsequent mission decisions."""
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('UPDATE state SET revalidation=1 WHERE id=1')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def status(self):
        epoch, required = self.db.execute('SELECT epoch,revalidation FROM state WHERE id=1').fetchone()
        count = self.db.execute('SELECT COUNT(*) FROM audit').fetchone()[0]
        return {'epoch':epoch,'revalidation_required':bool(required),'audit_count':count}

    def nonce_consumed(self, issuer, audience, nonce):
        return self.db.execute('SELECT 1 FROM nonces WHERE issuer=? AND audience=? AND nonce=?',(issuer,audience,nonce)).fetchone() is not None

    def verify_audit(self):
        previous = ZERO
        for expected, (seq,payload,prev,digest) in enumerate(self.db.execute('SELECT * FROM audit ORDER BY seq'),1):
            if seq != expected or prev != previous or digest != hashlib.sha256(f'{seq}:{prev}:{payload}'.encode()).hexdigest():
                return False
            previous = digest
        return True

    def close(self):
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
