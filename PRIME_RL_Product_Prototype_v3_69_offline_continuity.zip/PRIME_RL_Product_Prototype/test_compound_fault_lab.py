import unittest
from compound_fault_lab import run

class CompoundFaultTests(unittest.TestCase):
    def test_campaign(self):
        report = run(8)
        self.assertTrue(report['passed'], report['failures'])
        self.assertEqual(report['checks'], 88)
        self.assertEqual(report['ledger_events'], 88)
    def test_invalid_cycles(self):
        for n in (0,-1,True,1.5,'10'):
            with self.subTest(n=n), self.assertRaises(ValueError):
                run(n)

if __name__ == '__main__':
    unittest.main()
