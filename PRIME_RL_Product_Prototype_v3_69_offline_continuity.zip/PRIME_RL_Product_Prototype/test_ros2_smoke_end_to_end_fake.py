"""Offline harness contract checks. Fake ROS is not live DDS validation."""
import json
import sys
import types
import unittest
from unittest.mock import patch
from ros2_live_smoke import run


class TestFakeDDSRoundTrip(unittest.TestCase):
    def _run(self, corrupt_second=False, inject_stale=False, inject_malformed=False, disconnect_after_first=False, disconnect_during_reply=False):
        state = {'sent': 0, 'pending': [], 'destroyed': False, 'shutdown': False, 'spins': 0}

        class Endpoint:
            def get_subscription_count(self): return 0 if ((disconnect_after_first and state['sent'] >= 1) or (disconnect_during_reply and state['spins'] >= 1)) else 1
            def get_publisher_count(self): return 0 if ((disconnect_after_first and state['sent'] >= 1) or (disconnect_during_reply and state['spins'] >= 1)) else 1

        class Publisher(Endpoint):
            def publish(self, msg):
                state['sent'] += 1
                envelope = json.loads(msg.data)
                raw = envelope['telemetry']
                response = {'advisory_only': True, 'accepted': False,
                            'reason': 'invalid_telemetry',
                            'error_type': 'JSONDecodeError' if raw.startswith('{broken') else 'ValueError',
                            'request_id': envelope['request_id']}
                if corrupt_second and state['sent'] == 2:
                    response['request_id'] = 'wrong-id'
                if inject_malformed:
                    state['pending'].extend(['not-json', '[]', json.dumps({'request_id': envelope['request_id'], 'accepted': True, 'advisory_only': True})])
                if inject_stale:
                    stale = dict(response, request_id='stale-previous-request')
                    state['pending'].append(json.dumps(stale))
                state['pending'].append(json.dumps(response))

        class Node:
            def __init__(self, name): self.callback = None
            def create_subscription(self, _typ, _topic, callback, _qos):
                self.callback = callback
                return Endpoint()
            def create_publisher(self, *_args): return Publisher()
            def destroy_node(self): state['destroyed'] = True

        fake = types.ModuleType('rclpy')
        fake.init = lambda: None
        fake.shutdown = lambda: state.__setitem__('shutdown', True)
        def spin_once(node, timeout_sec):
            state['spins'] += 1
            if state['pending'] and not disconnect_during_reply:
                msg = types.SimpleNamespace(data=state['pending'].pop(0))
                node.callback(msg)
        fake.spin_once = spin_once
        node_module = types.ModuleType('rclpy.node')
        node_module.Node = Node
        std = types.ModuleType('std_msgs')
        std_msg = types.ModuleType('std_msgs.msg')
        std_msg.String = type('String', (), {})
        with patch.dict(sys.modules, {'rclpy': fake, 'rclpy.node': node_module,
                                      'std_msgs': std, 'std_msgs.msg': std_msg}):
            try:
                return run(timeout=0.02, max_latency_ms=5000), state
            finally:
                self.assertTrue(state['destroyed'])
                self.assertTrue(state['shutdown'])

    def test_two_correlated_scenarios_and_timing(self):
        result, state = self._run()
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(state['sent'], 2)
        self.assertEqual(len(result['timing']['round_trip_ms']), 2)
        self.assertFalse(result['one_way_dds_latency_measured'])
        self.assertNotEqual(result['advisories'][0]['request_id'], result['advisories'][1]['request_id'])

    def test_stale_advisories_ignored_before_matching_reply(self):
        result, state = self._run(inject_stale=True)
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(state['sent'], 2)
        self.assertTrue(all(item['request_id'] != 'stale-previous-request'
                            for item in result['advisories']))

    def test_malformed_and_non_rejection_messages_cannot_satisfy_probe(self):
        result, state = self._run(inject_malformed=True)
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(state['sent'], 2)
        self.assertEqual(len(result['advisories']), 2)

    def test_disconnected_dds_graph_blocks_second_probe(self):
        with self.assertRaisesRegex(TimeoutError, 'endpoint disappeared'):
            self._run(disconnect_after_first=True)

    def test_disconnect_during_reply_fails_fast(self):
        with self.assertRaisesRegex(TimeoutError, 'while awaiting advisory'):
            self._run(disconnect_during_reply=True)

    def test_recovery_after_disconnected_run(self):
        with self.assertRaisesRegex(TimeoutError, 'endpoint disappeared'):
            self._run(disconnect_after_first=True)
        result, state = self._run()
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(state['sent'], 2)

    def test_wrong_correlation_fails_closed(self):
        with self.assertRaises(TimeoutError):
            self._run(corrupt_second=True)


if __name__ == '__main__':
    unittest.main()
