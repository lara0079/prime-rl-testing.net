"""Repeatable local demo; does not control any device."""
import argparse
import json
from core import Runtime, Snapshot
from ledger import Ledger
from metrics import benchmark

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--db',default='prime_rl_demo.sqlite3')
    parser.add_argument('--iterations',type=int,default=1000)
    args=parser.parse_args()
    ledger=Ledger(args.db)
    runtime=Runtime()
    samples=[('online',Snapshot(True,1,1,1,True),'inspect'),
             ('network_lost',Snapshot(False,0,1,1,True),'inspect'),
             ('offline_hold',Snapshot(False,0,1,1,True),'hold'),
             ('authority_expired',Snapshot(False,0,1,1,False),'inspect'),
             ('reconnected_but_stale',Snapshot(True,1,1,1,False),'inspect')]
    for name, snapshot, action in samples:
        result=runtime.evaluate(snapshot,action)
        ledger.append({'scenario':name,**result})
    report={'demo_events':ledger.events()[-len(samples):], 'ledger_valid':ledger.verify(), 'metrics':benchmark(args.iterations)}
    print(json.dumps(report,indent=2))
    ledger.close()
if __name__=='__main__': main()
