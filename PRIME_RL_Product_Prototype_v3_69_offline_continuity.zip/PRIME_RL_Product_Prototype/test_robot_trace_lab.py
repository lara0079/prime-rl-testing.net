import unittest
from robot_trace_lab import run

class RobotTraceTests(unittest.TestCase):
    def test_reproducible(self):
        self.assertEqual(run(steps=101), run(steps=101))

    def test_stale_is_denied(self):
        report = run(steps=100)
        self.assertEqual(report['phase_counts']['stale'], 20)
        self.assertTrue(all(not p['advisory']['accepted'] for p in report['trace'] if p['phase'] == 'stale'))

    def test_nominal_without_authority_fails_closed(self):
        report = run(steps=100)
        self.assertTrue(all(not p['advisory']['accepted'] for p in report['trace'] if p['phase'] == 'nominal'))

    def test_no_actuator_outputs(self):
        report = run(steps=100)
        for point in report['trace']:
            self.assertNotIn('cmd_vel', point['advisory'])
            self.assertTrue(point['advisory']['advisory_only'])

    def test_invalid_steps(self):
        for steps in (0, -1, True):
            with self.assertRaises(ValueError):
                run(steps=steps)

    def test_invalid_dt(self):
        for dt in (0, -1, float('nan'), float('inf'), True):
            with self.assertRaises(ValueError):
                run(dt=dt)

if __name__ == '__main__':
    unittest.main()
