import tempfile
import unittest
from pathlib import Path
from atomic_ledger import AtomicLedger
from ledger import Ledger

class AtomicLedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'events.db'

    def test_append_and_restart(self):
        a = AtomicLedger(self.path)
        a.append({'event':'first'})
        a.close()
        b = AtomicLedger(self.path)
        self.assertTrue(b.verify())
        b.close()

    def test_injected_failure_rolls_back_both_writes(self):
        a = AtomicLedger(self.path)
        with self.assertRaises(RuntimeError):
            a.append({'event':'not committed'}, inject_failure=True)
        self.assertEqual(a.events(), [])
        self.assertTrue(a.verify())
        a.close()

    def test_deleted_tail_detected(self):
        a = AtomicLedger(self.path)
        a.append({'event':'first'})
        a.append({'event':'second'})
        with a.db:
            a.db.execute('DELETE FROM events WHERE seq=2')
        self.assertFalse(a.verify())
        a.close()
        with self.assertRaisesRegex(ValueError, 'integrity'):
            AtomicLedger(self.path)

    def test_legacy_history_requires_migration(self):
        old = Ledger(self.path)
        old.append({'event':'legacy'})
        old.close()
        with self.assertRaisesRegex(ValueError, 'migration'):
            AtomicLedger(self.path)

if __name__ == '__main__':
    unittest.main()
