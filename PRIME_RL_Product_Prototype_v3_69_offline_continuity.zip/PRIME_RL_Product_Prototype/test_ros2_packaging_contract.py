"""Offline tests of ROS 2 packaging metadata consistency."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from ros2_packaging_contract import audit

ROOT = Path(__file__).resolve().parent


class PackagingContractTests(unittest.TestCase):
    def test_current_package_passes(self):
        result = audit(ROOT)
        self.assertEqual(result['status'], 'pass', result['problems'])
        self.assertFalse(result['dds_test_executed'])

    def test_missing_metadata_fails_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            self.assertEqual(audit(temp)['status'], 'fail')

    def test_version_mismatch_fails(self):
        original = (ROOT / 'package.xml').read_text()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)
            (target / 'package.xml').write_text(original.replace('<version>3.9.0</version>', '<version>0.0.0</version>'))
            (target / 'setup.py').write_text((ROOT / 'setup.py').read_text())
            self.assertIn('package version mismatch', audit(target)['problems'])

    def test_nonliteral_setup_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)
            (target / 'package.xml').write_text((ROOT / 'package.xml').read_text())
            (target / 'setup.py').write_text('from setuptools import setup\nsetup(name=get_name())\n')
            self.assertEqual(audit(target)['status'], 'fail')


if __name__ == '__main__':
    unittest.main()
