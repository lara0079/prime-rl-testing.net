"""Static release contract checks; does not imply middleware execution."""
import ast
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent

class ReleaseContractTests(unittest.TestCase):
    def test_versions_match(self):
        source = ast.parse((ROOT / 'setup.py').read_text())
        setup_call = next(node.value for node in source.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and getattr(node.value.func, 'id', '') == 'setup')
        version = next(ast.literal_eval(k.value) for k in setup_call.keywords if k.arg == 'version')
        self.assertEqual(version, ET.parse(ROOT / 'package.xml').getroot().findtext('version'))

    def test_entry_points_are_local_modules(self):
        source = ast.parse((ROOT / 'setup.py').read_text())
        setup_call = next(node.value for node in source.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and getattr(node.value.func, 'id', '') == 'setup')
        entry_points = next(ast.literal_eval(k.value) for k in setup_call.keywords if k.arg == 'entry_points')
        for entry in entry_points['console_scripts']:
            module = entry.split('=', 1)[1].strip().split(':', 1)[0]
            self.assertTrue((ROOT / (module + '.py')).is_file())

    def test_launch_files_exist(self):
        self.assertTrue((ROOT / 'launch' / 'scenario.launch.py').is_file())
        self.assertTrue((ROOT / 'launch' / 'advisory.launch.py').is_file())

    def test_runbook_declares_no_actuation_and_external_validation(self):
        runbook = (ROOT / 'ROS2_VALIDATION_RUNBOOK.md').read_text()
        self.assertIn('advisory-only', runbook)
        self.assertIn('Gazebo', runbook)
        self.assertIn('no actuator', runbook)

if __name__ == '__main__':
    unittest.main()
