import tempfile
import unittest
from pathlib import Path

from ros2_evidence_audit import audit_directory
from ros2_repeatability import execute_repetitions, write_evidence_pair


class EvidenceAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.report = execute_repetitions(1, probe=lambda **kwargs: {
            'status': 'pass', 'timing': {'round_trip_ms': [1.25]}})

    def pair(self, stem):
        evidence = self.root / (stem + '.evidence.json')
        manifest = self.root / (stem + '.manifest.json')
        write_evidence_pair(self.report, evidence, manifest)
        return evidence, manifest

    def test_empty_directory_fails_closed(self):
        self.assertEqual(audit_directory(self.root)['status'], 'fail')

    def test_two_valid_pairs(self):
        self.pair('first')
        self.pair('second')
        result = audit_directory(self.root)
        self.assertEqual((result['status'], result['valid']), ('pass', 2))
        self.assertFalse(result['live_dds_attested'])

    def test_orphan_manifest_fails(self):
        evidence, _ = self.pair('orphan')
        evidence.unlink()
        result = audit_directory(self.root)
        self.assertEqual(result['pairs'][0]['reason'], 'evidence_missing')
        self.assertEqual(result['status'], 'fail')

    def test_tamper_fails(self):
        evidence, _ = self.pair('modified')
        evidence.write_text('{}')
        self.assertEqual(audit_directory(self.root)['status'], 'fail')

    def test_duplicate_run_identifier_fails(self):
        _, manifest_a = self.pair('a')
        _, manifest_b = self.pair('b')
        manifest_b.write_bytes(manifest_a.read_bytes())
        result = audit_directory(self.root)
        self.assertEqual(result['pairs'][1]['reason'], 'duplicate_run_id')

    def test_symlinked_directory_rejected(self):
        linked = self.root.parent / (self.root.name + '-link')
        linked.symlink_to(self.root, target_is_directory=True)
        self.addCleanup(linked.unlink)
        with self.assertRaises(ValueError):
            audit_directory(linked)
