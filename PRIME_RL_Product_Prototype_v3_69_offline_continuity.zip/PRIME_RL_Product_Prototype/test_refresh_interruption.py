"""Fail-closed refresh interruption tests (simulation-only)."""
import unittest
from session import GovernedSession
from authority import AuthorityResult

class StubVerifier:
    def __init__(self): self.fail = False
    def verify(self, token, now, consume=False):
        if self.fail: raise OSError('simulated verification storage failure')
        return AuthorityResult(True, 'verified', frozenset({'inspect'}), token, 200)

class StubLedger:
    def __init__(self): self.fail = False; self.events = []
    def append(self, event):
        if self.fail: raise OSError('simulated audit failure')
        self.events.append(event)

class RefreshInterruptionTests(unittest.TestCase):
    def setUp(self):
        self.verifier, self.ledger = StubVerifier(), StubLedger()
        self.session = GovernedSession(self.verifier, self.ledger)
        self.assertTrue(self.session.refresh('old', 100, True))
    def assert_revoked(self):
        self.assertTrue(self.session.revalidation_required)
        self.assertEqual(self.session.permissions, frozenset())
        self.assertIsNone(self.session.expires_at)
    def test_verification_exception_revokes_previous_grant(self):
        self.verifier.fail = True
        with self.assertRaises(OSError): self.session.refresh('new', 101, True)
        self.assert_revoked()
    def test_audit_exception_revokes_previous_grant(self):
        self.ledger.fail = True
        with self.assertRaises(OSError): self.session.refresh('new', 101, True)
        self.assert_revoked()
    def test_offline_refresh_revokes_previous_grant(self):
        self.assertFalse(self.session.refresh('new', 101, False))
        self.assert_revoked()

class StubLifecycle:
    def __init__(self):
        self.fail_refresh = False
        self.fail_revoke = False
        self.revoked = True
    def mark_revalidation_required(self):
        if self.fail_revoke: raise OSError('simulated lifecycle revoke failure')
        self.revoked = True
    def mark_refreshed(self):
        if self.fail_refresh: raise OSError('simulated lifecycle refresh failure')
        self.revoked = False
    def required(self): return self.revoked

class LifecycleInterruptionTests(unittest.TestCase):
    def setUp(self):
        self.verifier, self.ledger, self.lifecycle = StubVerifier(), StubLedger(), StubLifecycle()
        self.session = GovernedSession(self.verifier, self.ledger, self.lifecycle)
        self.assertTrue(self.session.refresh('old', 100, True))
    def test_lifecycle_clearance_failure_keeps_grant_revoked(self):
        self.lifecycle.fail_refresh = True
        with self.assertRaises(OSError): self.session.refresh('new', 101, True)
        self.assertTrue(self.session.revalidation_required)
        self.assertEqual(self.session.permissions, frozenset())
        self.assertIsNone(self.session.expires_at)
    def test_lifecycle_revoke_failure_clears_in_memory_grant(self):
        self.lifecycle.fail_revoke = True
        with self.assertRaises(OSError): self.session.refresh('new', 101, True)
        self.assertTrue(self.session.revalidation_required)
        self.assertEqual(self.session.permissions, frozenset())
        self.assertIsNone(self.session.expires_at)

if __name__ == '__main__': unittest.main()
