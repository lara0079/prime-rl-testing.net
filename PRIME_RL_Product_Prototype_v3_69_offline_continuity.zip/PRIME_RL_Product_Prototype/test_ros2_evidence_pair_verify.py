import json
import tempfile
import unittest
from pathlib import Path

from ros2_evidence_pair_verify import verify_pair
from ros2_repeatability import execute_repetitions, write_evidence_pair


class TestEvidencePairVerify(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.evidence = Path(self.tmp.name) / 'evidence.json'
        self.manifest = Path(self.tmp.name) / 'manifest.json'
        report = execute_repetitions(1, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': [2.0]}})
        write_evidence_pair(report, self.evidence, self.manifest)

    def test_valid_pair(self):
        self.assertEqual(verify_pair(self.evidence, self.manifest), (True, 'valid'))

    def test_missing_manifest_rejected(self):
        self.manifest.unlink()
        self.assertEqual(verify_pair(self.evidence, self.manifest), (False, 'manifest_missing'))

    def test_tampered_evidence_rejected(self):
        report = json.loads(self.evidence.read_text())
        report['runs'][0]['round_trip_ms'][0] = 3.0
        report['max_round_trip_ms'] = 3.0
        self.evidence.write_text(json.dumps(report))
        self.assertEqual(verify_pair(self.evidence, self.manifest), (False, 'manifest_mismatch'))

    def test_duplicate_json_keys_rejected(self):
        self.evidence.write_text('{"status":"pass","status":"pass"}')
        self.assertEqual(verify_pair(self.evidence, self.manifest), (False, 'invalid_pair'))

    def test_symlink_rejected(self):
        linked = Path(self.tmp.name) / 'linked.json'
        linked.symlink_to(self.evidence)
        self.assertEqual(verify_pair(linked, self.manifest), (False, 'evidence_symlink'))

    def test_same_path_rejected(self):
        self.assertEqual(verify_pair(self.evidence, self.evidence), (False, 'same_path'))
