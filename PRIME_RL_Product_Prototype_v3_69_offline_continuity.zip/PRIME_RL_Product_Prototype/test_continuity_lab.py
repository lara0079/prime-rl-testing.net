import unittest
from continuity_lab import run

class ContinuityTests(unittest.TestCase):
    def test_repeated_cycles(self):
        result = run(12)
        self.assertTrue(result['passed'], result['failures'])
        self.assertEqual(result['checks'], 156)
    def test_reject_bad_cycles(self):
        for value in (0, -1, True, 1.2):
            with self.subTest(value=value), self.assertRaises(ValueError):
                run(value)

if __name__ == '__main__':
    unittest.main()
