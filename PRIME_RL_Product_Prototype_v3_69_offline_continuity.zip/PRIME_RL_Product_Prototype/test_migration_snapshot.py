"""Migration snapshot verification regression tests."""
import sqlite3
import tempfile
import unittest
from pathlib import Path
from ledger import Ledger
from ledger_migration import migrate_legacy_ledger
from atomic_ledger import AtomicLedger

class MigrationSnapshotTests(unittest.TestCase):
    def test_backup_is_valid_and_matches_atomic_head(self):
        with tempfile.TemporaryDirectory() as d:
            source, backup = Path(d)/'source.sqlite', Path(d)/'backup.sqlite'
            ledger=Ledger(source)
            for i in range(12):
                ledger.append({'sequence':i})
            ledger.close()
            result=migrate_legacy_ledger(source,backup)
            self.assertEqual(result['events'],12)
            saved=Ledger(backup)
            migrated=AtomicLedger(source)
            try:
                self.assertTrue(saved.verify())
                self.assertTrue(migrated.verify())
                self.assertEqual(saved.db.execute('SELECT seq,event_hash FROM events ORDER BY seq DESC LIMIT 1').fetchone(),migrated.db.execute('SELECT seq,event_hash FROM ledger_head').fetchone())
            finally:
                saved.close(); migrated.close()

    def test_empty_ledger_migrates_with_verified_backup(self):
        with tempfile.TemporaryDirectory() as d:
            source, backup=Path(d)/'source.sqlite',Path(d)/'backup.sqlite'
            Ledger(source).close()
            self.assertEqual(migrate_legacy_ledger(source,backup)['events'],0)
            saved=Ledger(backup)
            atomic=AtomicLedger(source)
            try:
                self.assertTrue(saved.verify())
                self.assertTrue(atomic.verify())
            finally:
                saved.close(); atomic.close()

if __name__=='__main__': unittest.main()
