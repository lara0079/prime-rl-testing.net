import tempfile
import unittest
from pathlib import Path

from ros2_metrics_summary import summarize
from ros2_repeatability import execute_repetitions, write_evidence_pair


class MetricsSummaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def pair(self, stem, samples, *, passed=True):
        report = execute_repetitions(1, probe=lambda **kw: {
            'status': 'pass' if passed else 'fail', 'timing': {'round_trip_ms': samples}})
        evidence = self.root / (stem + '.evidence.json')
        manifest = self.root / (stem + '.manifest.json')
        write_evidence_pair(report, evidence, manifest)
        return evidence, manifest

    def test_verified_aggregation(self):
        self.pair('a', [1, 3])
        self.pair('b', [5, 7])
        result = summarize(self.root)
        self.assertEqual(result['status'], 'pass')
        self.assertEqual(result['sample_count'], 4)
        self.assertEqual(result['latency_ms']['mean'], 4)
        self.assertEqual(result['latency_ms']['p50'], 4)
        self.assertAlmostEqual(result['latency_ms']['p95'], 6.7)
        self.assertFalse(result['live_dds_attested'])

    def test_empty_fails_closed(self):
        self.assertEqual(summarize(self.root)['reason'], 'evidence_audit_failed')

    def test_corrupted_pair_fails_closed(self):
        evidence, _ = self.pair('a', [1])
        evidence.write_text('{}', encoding='utf-8')
        self.assertEqual(summarize(self.root)['reason'], 'evidence_audit_failed')

    def test_failed_probe_not_counted_as_success(self):
        self.pair('a', [1], passed=False)
        self.assertEqual(summarize(self.root)['reason'], 'failed_evidence_present')

    def test_missing_manifest_fails_closed(self):
        _, manifest = self.pair('a', [1])
        manifest.unlink()
        self.assertEqual(summarize(self.root)['reason'], 'evidence_audit_failed')
