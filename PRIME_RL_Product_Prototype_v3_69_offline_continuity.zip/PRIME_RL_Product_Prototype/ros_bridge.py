"""ROS 2 boundary adapter, deliberately read-only and simulation-only.

Accepts ROS-like plain message values so it can be unit-tested without rclpy.
Does not publish commands or access actuators. Requires a separate ROS 2 integration.
"""
from dataclasses import dataclass
from math import isfinite
from navigation_lab import LocalizationSample, estimate_confidence
from core import Runtime, Snapshot


@dataclass(frozen=True)
class RobotTelemetry:
    stamp_seconds: float
    gnss_quality: float | None
    odometry_quality: float | None
    imu_quality: float | None
    map_freshness: float
    battery_fraction: float
    connected: bool


def assess(telemetry: RobotTelemetry, action: str = 'return', *, now_seconds: float, max_age_seconds: float = 2.0):
    """Produce an advisory decision only. Fail closed on stale/future telemetry."""
    if not isinstance(telemetry, RobotTelemetry):
        raise TypeError('RobotTelemetry required')
    for value in (now_seconds, telemetry.stamp_seconds, max_age_seconds):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
            raise ValueError('nonfinite or invalid time')
    if max_age_seconds <= 0:
        raise ValueError('max_age_seconds must be positive')
    if not isinstance(telemetry.connected, bool):
        raise ValueError('connected must be bool')
    sample = LocalizationSample(telemetry.gnss_quality, telemetry.odometry_quality,
                                telemetry.imu_quality, telemetry.map_freshness,
                                telemetry.battery_fraction, telemetry.connected)
    sample.validate()
    if now_seconds < telemetry.stamp_seconds or now_seconds - telemetry.stamp_seconds > max_age_seconds:
        return {'accepted': False, 'reason': 'stale_or_future_telemetry',
                'advisory_only': True, 'confidence': None}
    confidence = estimate_confidence(sample)
    snapshot = Snapshot(telemetry.connected, 1.0 if telemetry.connected else 0.0,
                        confidence, telemetry.battery_fraction, False)
    decision = Runtime().evaluate(snapshot, action)
    return {'accepted': bool(decision['accepted']), 'reason': 'illustrative_core_policy',
            'state': decision['state'], 'confidence': confidence, 'advisory_only': True}
