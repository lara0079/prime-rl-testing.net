"""Coverage gates prevent treating a single large run as independent replication."""
import tempfile
import unittest
from pathlib import Path
from ros2_metrics_gate import assess
from ros2_repeatability import execute_repetitions, write_evidence_pair


class MetricsCoverageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def add_pair(self, stem, repetitions=1):
        report = execute_repetitions(repetitions, probe=lambda **kw: {
            'status': 'pass', 'timing': {'round_trip_ms': [1.0, 2.0, 3.0]}})
        write_evidence_pair(report, self.root / (stem + '.evidence.json'),
                            self.root / (stem + '.manifest.json'))

    def gate(self, **kwargs):
        return assess(self.root, max_p95_ms=10, min_samples=3, **kwargs)

    def test_single_run_with_many_samples_does_not_meet_run_coverage(self):
        self.add_pair('a')
        result = self.gate(min_runs=2)
        self.assertEqual(result['status'], 'fail')
        self.assertIn('insufficient_independent_runs', result['failures'])

    def test_multiple_runs_in_one_pair_do_not_meet_pair_coverage(self):
        self.add_pair('a', repetitions=2)
        result = self.gate(min_runs=2, min_evidence_pairs=2)
        self.assertEqual(result['status'], 'fail')
        self.assertIn('insufficient_evidence_pairs', result['failures'])

    def test_distinct_pairs_meet_coverage(self):
        self.add_pair('a')
        self.add_pair('b')
        self.assertEqual(self.gate(min_runs=2, min_evidence_pairs=2)['status'], 'pass')

    def test_invalid_coverage_rejected(self):
        self.add_pair('a')
        for value in (0, -1, True, 1.5):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    self.gate(min_runs=value)
                with self.assertRaises(ValueError):
                    self.gate(min_evidence_pairs=value)
