"""Offline ROS discovery and cleanup regression tests using fake middleware."""
import sys
import types
import unittest
from unittest.mock import patch
from ros2_live_smoke import run


class FakeEndpoint:
    def __init__(self, count):
        self.count = count
    def get_subscription_count(self):
        return self.count
    def get_publisher_count(self):
        return self.count


class TestDDSDiscovery(unittest.TestCase):
    def _exercise(self, input_count, output_count, destroy_raises=False):
        events = []
        class Node:
            def __init__(self, name):
                pass
            def create_subscription(self, *args):
                return FakeEndpoint(output_count)
            def create_publisher(self, *args):
                return FakeEndpoint(input_count)
            def destroy_node(self):
                events.append('destroy')
                if destroy_raises:
                    raise RuntimeError('destroy failed')
        fake = types.ModuleType('rclpy')
        fake.init = lambda: events.append('init')
        fake.spin_once = lambda *args, **kwargs: None
        fake.shutdown = lambda: events.append('shutdown')
        fake_node = types.ModuleType('rclpy.node')
        fake_node.Node = Node
        fake_std = types.ModuleType('std_msgs')
        fake_std_msg = types.ModuleType('std_msgs.msg')
        fake_std_msg.String = type('String', (), {})
        with patch.dict(sys.modules, {'rclpy': fake, 'rclpy.node': fake_node,
                                      'std_msgs': fake_std, 'std_msgs.msg': fake_std_msg}):
            with self.assertRaises((TimeoutError, RuntimeError)):
                run(timeout=0.001)
        return events

    def test_missing_advisory_publisher_fails_closed(self):
        self.assertEqual(self._exercise(1, 0), ['init', 'destroy', 'shutdown'])

    def test_missing_telemetry_subscriber_fails_closed(self):
        self.assertEqual(self._exercise(0, 1), ['init', 'destroy', 'shutdown'])

    def test_shutdown_even_if_node_destruction_raises(self):
        self.assertEqual(self._exercise(1, 0, destroy_raises=True), ['init', 'destroy', 'shutdown'])
