"""Read-only evidence manifest for a future ROS 2 validation host.

Never launches ROS nodes or Gazebo. Does not claim middleware validation.
"""
import argparse
import datetime
import hashlib
import json
import platform
from pathlib import Path

from ros2_readiness import check_environment


def build_manifest(root=None, *, readiness=None, timestamp=None):
    root = Path(root) if root else Path(__file__).resolve().parent
    readiness = readiness if readiness is not None else check_environment(package_root=root)
    files = ('package.xml', 'setup.py', 'launch/scenario.launch.py',
             'launch/advisory.launch.py', 'ros2_advisory_node.py',
             'ROS2_VALIDATION_RUNBOOK.md')
    artifacts = {}
    resolved_root = root.resolve()
    for relative in files:
        path = root / relative
        # Fail closed at evidence creation: do not hash through symlinks.
        if any(part.is_symlink() for part in (path, *path.parents)
               if part != root and part.is_relative_to(root)):
            raise ValueError(f'symlinked evidence source: {relative}')
        if not path.resolve().is_relative_to(resolved_root):
            raise ValueError(f'evidence source escapes package root: {relative}')
        artifacts[relative] = {'present': path.is_file(),
                               'sha256': hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None}
    return {
        'schema_version': 1,
        'captured_at_utc': timestamp or datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'platform': platform.platform(),
        'python_version': platform.python_version(),
        'readiness': readiness,
        'artifacts': artifacts,
        'validation_status': 'NOT_EXECUTED',
        'scope': 'read-only host preflight and source artifact hashes; no ROS 2/Gazebo execution',
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Write evidence JSON to this path')
    args = parser.parse_args(argv)
    report = build_manifest()
    encoded = json.dumps(report, indent=2, sort_keys=True) + '\n'
    if args.output:
        args.output.write_text(encoded, encoding='utf-8')
    else:
        print(encoded, end='')
    return 0 if report['readiness']['ros2_execution_ready'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
