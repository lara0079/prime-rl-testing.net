import unittest
from learning_lab import TabularAgent, ToyObservation, run, compare, ACTIONS

class LearningLabTests(unittest.TestCase):
    def test_reproducible(self):
        self.assertEqual(compare(500, 17), compare(500, 17))

    def test_gate_blocks_offline_inspection(self):
        result = run(1000, 19, True)
        self.assertEqual(result['offline_inspect_accepted'], 0)
        self.assertGreater(result['offline_steps'], 0)

    def test_unrestricted_agent_can_inspect_offline(self):
        self.assertGreater(run(1000, 19, False)['offline_inspect_accepted'], 0)

    def test_agent_learns_from_reward(self):
        agent = TabularAgent(seed=1, epsilon=0)
        obs = ToyObservation(True, True, True)
        agent.learn(obs, 'signal', 5.0)
        self.assertEqual(agent.propose(obs).action, 'signal')

    def test_accounting(self):
        for governed in (True, False):
            report = run(200, 11, governed)
            self.assertEqual(report['accepted'] + report['blocked'], 200)

if __name__ == '__main__': unittest.main()
